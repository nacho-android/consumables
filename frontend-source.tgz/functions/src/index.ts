import { initializeApp } from "firebase-admin/app";
import { getAuth, type UpdateRequest } from "firebase-admin/auth";
import {
  FieldValue,
  Timestamp,
  getFirestore,
  type DocumentData,
  type Query
} from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { onDocumentWritten } from "firebase-functions/v2/firestore";
import { randomUUID } from "node:crypto";

initializeApp();

const db = getFirestore();
const auth = getAuth();
const AUDITED_COLLECTIONS = new Set(["profiles", "projects", "items", "itemCosts", "projectMemberships"]);
const ALLOWED_UNITS = new Set(["each", "box", "daily"]);

type Role = "admin" | "standard";

type CreateUserInput = {
  email: string;
  displayName: string;
  role: Role;
  projectIds?: string[];
};

type UpdateUserInput = {
  uid: string;
  email?: string;
  displayName?: string;
  role?: Role;
  active?: boolean;
  projectIds?: string[];
};

type TransactionPatch = {
  transactionDate?: string;
  projectId?: string;
  itemId?: string;
  amount?: number;
  unitOfMeasure?: string;
  comments?: string;
  projectCode?: string;
  projectName?: string;
  databaseCode?: string;
  itemCode?: string;
  itemType?: string;
  itemName?: string;
};

type PurgeTransactionsInput = {
  projectId?: unknown;
  startDate?: unknown;
  endDate?: unknown;
  confirm?: unknown;
};

type ListTransactionsInput = {
  projectId?: unknown;
  startDate?: unknown;
  endDate?: unknown;
};

function cleanString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function requireAuthUid(authUid: string | undefined): string {
  if (!authUid) {
    throw new HttpsError("unauthenticated", "Sign in before performing this action.");
  }
  return authUid;
}

async function requireAdmin(authUid: string | undefined): Promise<string> {
  const uid = requireAuthUid(authUid);
  const profile = await db.collection("profiles").doc(uid).get();
  if (!profile.exists || profile.get("active") !== true || profile.get("role") !== "admin") {
    throw new HttpsError("permission-denied", "Admin access is required.");
  }
  return uid;
}

function requireRecentAuth(authData: { token?: Record<string, unknown> } | undefined): void {
  const authTime = Number(authData?.token?.auth_time);
  const maxAgeSeconds = 5 * 60;
  if (!Number.isFinite(authTime) || (Date.now() / 1000) - authTime > maxAgeSeconds) {
    throw new HttpsError("failed-precondition", "Re-enter your password before purging transactions.");
  }
}

async function activeProfileFor(authUid: string | undefined): Promise<{ uid: string; role: Role }> {
  const uid = requireAuthUid(authUid);
  const profile = await db.collection("profiles").doc(uid).get();
  const role = profile.get("role");
  if (!profile.exists || profile.get("active") !== true || (role !== "admin" && role !== "standard")) {
    throw new HttpsError("permission-denied", "An active user profile is required.");
  }
  return { uid, role };
}

function assertDateRange(startDate: string, endDate: string): void {
  if (!startDate.match(/^\d{4}-\d{2}-\d{2}$/) || !endDate.match(/^\d{4}-\d{2}-\d{2}$/) || startDate > endDate) {
    throw new HttpsError("invalid-argument", "Date range is invalid.");
  }
}

function assertAllowedUnit(unitOfMeasure: string): void {
  if (!ALLOWED_UNITS.has(unitOfMeasure)) {
    throw new HttpsError("invalid-argument", "Unit must be each, box, or daily.");
  }
}

function timestampMillis(value: unknown): number | null {
  return value instanceof Timestamp ? value.toMillis() : null;
}

function serializeTransaction(id: string, data: DocumentData): DocumentData {
  return {
    ...data,
    id,
    submittedAt: timestampMillis(data.submittedAt),
    correctedAt: timestampMillis(data.correctedAt),
    createdAt: timestampMillis(data.createdAt),
    updatedAt: timestampMillis(data.updatedAt)
  };
}

async function accessibleProjectIdsFor(uid: string, role: Role, selectedProjectId: string): Promise<string[]> {
  if (role === "admin") {
    if (selectedProjectId && selectedProjectId !== "all") return [selectedProjectId];
    const projects = await db.collection("projects").get();
    return projects.docs.map((doc) => doc.id);
  }

  const memberships = await db
    .collection("projectMemberships")
    .where("userId", "==", uid)
    .where("active", "==", true)
    .get();
  const projectIds = memberships.docs.map((doc) => String(doc.get("projectId"))).filter(Boolean);
  if (!selectedProjectId || selectedProjectId === "all") return projectIds;
  if (!projectIds.includes(selectedProjectId)) {
    throw new HttpsError("permission-denied", "You do not have access to this project.");
  }
  return [selectedProjectId];
}

function assertRole(role: unknown): asserts role is Role {
  if (role !== "admin" && role !== "standard") {
    throw new HttpsError("invalid-argument", "Role must be admin or standard.");
  }
}

function assertEmail(email: string): void {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new HttpsError("invalid-argument", "Enter a valid email address.");
  }
}

function assertProjectIds(projectIds: unknown): string[] {
  if (projectIds === undefined) return [];
  if (!Array.isArray(projectIds)) {
    throw new HttpsError("invalid-argument", "Project IDs must be an array.");
  }
  return projectIds.map(cleanString).filter(Boolean);
}

function randomTemporaryPassword(): string {
  return `${randomUUID()}Aa1!`;
}

async function writeAudit(
  actorUserId: string,
  action: string,
  entityType: string,
  entityId: string,
  beforeJson: DocumentData | null,
  afterJson: DocumentData | null,
  reason?: string
): Promise<void> {
  await db.collection("auditLog").add({
    actorUserId,
    action,
    entityType,
    entityId,
    beforeJson,
    afterJson,
    reason: reason ?? null,
    createdAt: FieldValue.serverTimestamp()
  });
}

async function actorDisplayName(actorUserId: string): Promise<string> {
  const profile = await db.collection("profiles").doc(actorUserId).get();
  return String(profile.get("displayName") ?? actorUserId);
}

async function setMemberships(
  actorUserId: string,
  userId: string,
  projectIds: string[]
): Promise<void> {
  const existing = await db.collection("projectMemberships").where("userId", "==", userId).get();
  const selected = new Set(projectIds);
  const batch = db.batch();
  const now = FieldValue.serverTimestamp();

  existing.docs.forEach((doc) => {
    const shouldBeActive = selected.has(String(doc.get("projectId")));
    if (doc.get("active") !== shouldBeActive) {
      batch.set(
        doc.ref,
        { active: shouldBeActive, updatedAt: now, updatedBy: actorUserId },
        { merge: true }
      );
    }
    selected.delete(String(doc.get("projectId")));
  });

  selected.forEach((projectId) => {
    const id = `${userId}_${projectId}`;
    batch.set(
      db.collection("projectMemberships").doc(id),
      {
        userId,
        projectId,
        active: true,
        createdAt: now,
        updatedAt: now,
        updatedBy: actorUserId
      },
      { merge: true }
    );
  });

  await batch.commit();
}

export const adminCreateUser = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const data = request.data as Partial<CreateUserInput>;
  const email = cleanString(data.email).toLowerCase();
  const displayName = cleanString(data.displayName);
  const role = data.role;
  const projectIds = assertProjectIds(data.projectIds);

  assertEmail(email);
  assertRole(role);
  if (!displayName) {
    throw new HttpsError("invalid-argument", "Display name is required.");
  }

  const created = await auth.createUser({
    email,
    displayName,
    disabled: false,
    emailVerified: false,
    password: randomTemporaryPassword()
  });

  const now = FieldValue.serverTimestamp();
  await db.collection("profiles").doc(created.uid).set({
    email,
    displayName,
    role,
    active: true,
    createdAt: now,
    updatedAt: now,
    updatedBy: actorUserId
  });
  await setMemberships(actorUserId, created.uid, projectIds);
  const resetLink = await auth.generatePasswordResetLink(email);

  await writeAudit(actorUserId, "create", "profile", created.uid, null, {
    email,
    displayName,
    role,
    active: true,
    projectIds
  });

  return { uid: created.uid, resetLink };
});

export const adminUpdateUser = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const data = request.data as Partial<UpdateUserInput>;
  const uid = cleanString(data.uid);
  if (!uid) {
    throw new HttpsError("invalid-argument", "User ID is required.");
  }

  const profileRef = db.collection("profiles").doc(uid);
  const before = await profileRef.get();
  if (!before.exists) {
    throw new HttpsError("not-found", "User profile was not found.");
  }

  const updateAuth: UpdateRequest = {};
  const updateProfile: Record<string, unknown> = {
    updatedAt: FieldValue.serverTimestamp(),
    updatedBy: actorUserId
  };

  if (data.email !== undefined) {
    const email = cleanString(data.email).toLowerCase();
    assertEmail(email);
    updateAuth.email = email;
    updateProfile.email = email;
  }

  if (data.displayName !== undefined) {
    const displayName = cleanString(data.displayName);
    if (!displayName) throw new HttpsError("invalid-argument", "Display name is required.");
    updateAuth.displayName = displayName;
    updateProfile.displayName = displayName;
  }

  if (data.role !== undefined) {
    assertRole(data.role);
    updateProfile.role = data.role;
  }

  if (data.active !== undefined) {
    updateAuth.disabled = data.active !== true;
    updateProfile.active = data.active === true;
  }

  if (Object.keys(updateAuth).length > 0) {
    await auth.updateUser(uid, updateAuth);
  }
  await profileRef.set(updateProfile, { merge: true });

  if (data.projectIds !== undefined) {
    await setMemberships(actorUserId, uid, assertProjectIds(data.projectIds));
  }

  const after = await profileRef.get();
  await writeAudit(actorUserId, "update", "profile", uid, before.data() ?? null, after.data() ?? null);
  return { ok: true };
});

export const adminTriggerPasswordReset = onCall(async (request) => {
  await requireAdmin(request.auth?.uid);
  const email = cleanString((request.data as { email?: unknown }).email).toLowerCase();
  assertEmail(email);
  const resetLink = await auth.generatePasswordResetLink(email);
  return { resetLink };
});

export const adminGetInvoiceTemplate = onCall(async (request) => {
  await requireAdmin(request.auth?.uid);
  const template = await db.collection("appConfig").doc("invoiceTemplate").get();
  const contentBase64 = String(template.get("contentBase64") ?? "");
  if (!contentBase64) {
    throw new HttpsError("failed-precondition", "Invoice template has not been configured.");
  }
  return {
    contentBase64,
    fileName: String(template.get("fileName") ?? "invoice_template.xlsx"),
    updatedAt: timestampMillis(template.get("updatedAt"))
  };
});

export const adminDeleteOrDeactivateUser = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const uid = cleanString((request.data as { uid?: unknown }).uid);
  if (!uid) {
    throw new HttpsError("invalid-argument", "User ID is required.");
  }
  if (uid === actorUserId) {
    throw new HttpsError("failed-precondition", "Admins cannot delete or deactivate themselves here.");
  }

  const tx = await db.collection("transactions").where("userId", "==", uid).limit(1).get();
  if (!tx.empty) {
    await auth.updateUser(uid, { disabled: true });
    await db.collection("profiles").doc(uid).set(
      { active: false, updatedAt: FieldValue.serverTimestamp(), updatedBy: actorUserId },
      { merge: true }
    );
    await writeAudit(actorUserId, "deactivate", "profile", uid, null, { active: false });
    return { action: "deactivated" };
  }

  await auth.deleteUser(uid);
  await db.collection("profiles").doc(uid).delete();
  const memberships = await db.collection("projectMemberships").where("userId", "==", uid).get();
  const batch = db.batch();
  memberships.docs.forEach((doc) => batch.delete(doc.ref));
  await batch.commit();
  await writeAudit(actorUserId, "delete", "profile", uid, null, null);
  return { action: "deleted" };
});

export const adminDeleteOrDeactivateProject = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const projectId = cleanString((request.data as { projectId?: unknown }).projectId);
  if (!projectId) {
    throw new HttpsError("invalid-argument", "Project ID is required.");
  }

  const projectRef = db.collection("projects").doc(projectId);
  const before = await projectRef.get();
  if (!before.exists) {
    throw new HttpsError("not-found", "Project not found.");
  }

  const tx = await db.collection("transactions").where("projectId", "==", projectId).limit(1).get();
  if (!tx.empty) {
    await projectRef.set(
      { active: false, updatedAt: FieldValue.serverTimestamp(), updatedBy: actorUserId },
      { merge: true }
    );
    const after = await projectRef.get();
    await writeAudit(actorUserId, "deactivate", "project", projectId, before.data() ?? null, after.data() ?? null);
    return { action: "deactivated" };
  }

  await projectRef.delete();
  const memberships = await db.collection("projectMemberships").where("projectId", "==", projectId).get();
  const batch = db.batch();
  memberships.docs.forEach((doc) => batch.delete(doc.ref));
  await batch.commit();
  await writeAudit(actorUserId, "delete", "project", projectId, before.data() ?? null, null);
  return { action: "deleted" };
});

export const adminDeleteOrDeactivateItem = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const itemId = cleanString((request.data as { itemId?: unknown }).itemId);
  if (!itemId) {
    throw new HttpsError("invalid-argument", "Item ID is required.");
  }

  const itemRef = db.collection("items").doc(itemId);
  const before = await itemRef.get();
  if (!before.exists) {
    throw new HttpsError("not-found", "Item not found.");
  }

  const tx = await db.collection("transactions").where("itemId", "==", itemId).limit(1).get();
  if (!tx.empty) {
    await itemRef.set(
      { active: false, updatedAt: FieldValue.serverTimestamp(), updatedBy: actorUserId },
      { merge: true }
    );
    const after = await itemRef.get();
    await writeAudit(actorUserId, "deactivate", "item", itemId, before.data() ?? null, after.data() ?? null);
    return { action: "deactivated" };
  }

  const batch = db.batch();
  batch.delete(itemRef);
  batch.delete(db.collection("itemCosts").doc(itemId));
  await batch.commit();
  await writeAudit(actorUserId, "delete", "item", itemId, before.data() ?? null, null);
  return { action: "deleted" };
});

export const voidTransaction = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const displayName = await actorDisplayName(actorUserId);
  const data = request.data as { transactionId?: unknown; reason?: unknown };
  const transactionId = cleanString(data.transactionId);
  const reason = cleanString(data.reason);
  if (!transactionId || !reason) {
    throw new HttpsError("invalid-argument", "Transaction ID and reason are required.");
  }

  const ref = db.collection("transactions").doc(transactionId);
  const before = await ref.get();
  if (!before.exists) {
    throw new HttpsError("not-found", "Transaction not found.");
  }
  if (before.get("status") !== "active") {
    throw new HttpsError("failed-precondition", "Only active transactions can be voided.");
  }

  const update = {
    status: "voided",
    voidOrCorrectionReason: reason,
    correctedBy: actorUserId,
    correctedByName: displayName,
    correctedAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
    updatedBy: actorUserId
  };
  await ref.set(update, { merge: true });
  const after = await ref.get();
  await writeAudit(actorUserId, "void", "transaction", transactionId, before.data() ?? null, after.data() ?? null, reason);
  return { ok: true };
});

export const listAccessibleTransactions = onCall(async (request) => {
  const actor = await activeProfileFor(request.auth?.uid);
  const data = request.data as ListTransactionsInput;
  const selectedProjectId = cleanString(data.projectId) || "all";
  const startDate = cleanString(data.startDate);
  const endDate = cleanString(data.endDate);
  assertDateRange(startDate, endDate);

  const projectIds = await accessibleProjectIdsFor(actor.uid, actor.role, selectedProjectId);
  if (projectIds.length === 0) return { transactions: [] };

  const chunks: string[][] = [];
  for (let index = 0; index < projectIds.length; index += 30) {
    chunks.push(projectIds.slice(index, index + 30));
  }

  const results = await Promise.all(
    chunks.map(async (ids) => {
      const snapshot = await db.collection("transactions")
        .where("projectId", "in", ids)
        .where("transactionDate", ">=", startDate)
        .where("transactionDate", "<=", endDate)
        .orderBy("transactionDate", "desc")
        .orderBy("submittedAt", "desc")
        .limit(1000)
        .get();
      return snapshot.docs.map((doc) => serializeTransaction(doc.id, doc.data()));
    })
  );

  const transactions = results.flat().sort((a, b) => {
    const dateCompare = String(b.transactionDate ?? "").localeCompare(String(a.transactionDate ?? ""));
    if (dateCompare !== 0) return dateCompare;
    return Number(b.submittedAt ?? 0) - Number(a.submittedAt ?? 0);
  });

  return { transactions };
});

export const correctTransaction = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  const displayName = await actorDisplayName(actorUserId);
  const data = request.data as { transactionId?: unknown; reason?: unknown; replacement?: TransactionPatch };
  const transactionId = cleanString(data.transactionId);
  const reason = cleanString(data.reason);
  if (!transactionId || !reason || !data.replacement) {
    throw new HttpsError("invalid-argument", "Transaction ID, reason, and replacement values are required.");
  }

  const originalRef = db.collection("transactions").doc(transactionId);
  const before = await originalRef.get();
  if (!before.exists) {
    throw new HttpsError("not-found", "Transaction not found.");
  }
  if (before.get("status") !== "active") {
    throw new HttpsError("failed-precondition", "Only active transactions can be corrected.");
  }

  const original = before.data() ?? {};
  const replacement = data.replacement;
  const amount = Number(replacement.amount ?? original.amount);
  const unitOfMeasure = cleanString(replacement.unitOfMeasure ?? original.unitOfMeasure);
  const transactionDate = cleanString(replacement.transactionDate ?? original.transactionDate);
  const projectId = cleanString(replacement.projectId ?? original.projectId);
  const itemId = cleanString(replacement.itemId ?? original.itemId);

  if (!transactionDate.match(/^\d{4}-\d{2}-\d{2}$/) || !projectId || !itemId || !unitOfMeasure || amount <= 0) {
    throw new HttpsError("invalid-argument", "Replacement transaction has invalid required values.");
  }
  assertAllowedUnit(unitOfMeasure);

  const now = FieldValue.serverTimestamp();
  const correctedRef = db.collection("transactions").doc();
  const corrected = {
    ...original,
    transactionDate,
    projectId,
    itemId,
    amount,
    unitOfMeasure,
    comments: cleanString(replacement.comments ?? original.comments),
    projectCode: cleanString(replacement.projectCode ?? original.projectCode),
    projectName: cleanString(replacement.projectName ?? original.projectName),
    databaseCode: cleanString(replacement.databaseCode ?? original.databaseCode),
    itemCode: cleanString(replacement.itemCode ?? original.itemCode),
    itemType: cleanString(replacement.itemType ?? original.itemType),
    itemName: cleanString(replacement.itemName ?? original.itemName),
    status: "active",
    originalTransactionId: transactionId,
    voidOrCorrectionReason: reason,
    submittedAt: Timestamp.now(),
    createdAt: now,
    updatedAt: now,
    updatedBy: actorUserId,
    correctedBy: actorUserId,
    correctedByName: displayName,
    correctedAt: now
  };

  const batch = db.batch();
  batch.set(originalRef, {
    status: "corrected",
    voidOrCorrectionReason: reason,
    correctedBy: actorUserId,
    correctedByName: displayName,
    correctedAt: now,
    updatedAt: now,
    updatedBy: actorUserId
  }, { merge: true });
  batch.set(correctedRef, corrected);
  await batch.commit();

  const after = await originalRef.get();
  const correctedAfter = await correctedRef.get();
  await writeAudit(actorUserId, "correct", "transaction", transactionId, before.data() ?? null, after.data() ?? null, reason);
  await writeAudit(actorUserId, "create_correction", "transaction", correctedRef.id, null, correctedAfter.data() ?? null, reason);
  return { ok: true, correctedTransactionId: correctedRef.id };
});

export const adminPurgeTransactions = onCall(async (request) => {
  const actorUserId = await requireAdmin(request.auth?.uid);
  requireRecentAuth(request.auth);
  const data = request.data as PurgeTransactionsInput;
  const projectId = cleanString(data.projectId);
  const startDate = cleanString(data.startDate);
  const endDate = cleanString(data.endDate);
  const confirm = cleanString(data.confirm);

  if (confirm !== "DELETE") {
    throw new HttpsError("invalid-argument", "Type DELETE to confirm transaction purge.");
  }
  if ((startDate && !endDate) || (!startDate && endDate)) {
    throw new HttpsError("invalid-argument", "Provide both start and end dates, or neither for all dates.");
  }
  if (startDate && (!startDate.match(/^\d{4}-\d{2}-\d{2}$/) || !endDate.match(/^\d{4}-\d{2}-\d{2}$/) || startDate > endDate)) {
    throw new HttpsError("invalid-argument", "Date range is invalid.");
  }
  if (projectId) {
    const project = await db.collection("projects").doc(projectId).get();
    if (!project.exists) throw new HttpsError("not-found", "Project not found.");
  }

  let purgeQuery: Query<DocumentData> = db.collection("transactions");
  if (projectId) purgeQuery = purgeQuery.where("projectId", "==", projectId);
  if (startDate) {
    purgeQuery = purgeQuery
      .where("transactionDate", ">=", startDate)
      .where("transactionDate", "<=", endDate);
  }

  let deletedCount = 0;
  const sampleDeletedIds: string[] = [];
  const batchSize = 400;

  while (true) {
    const snapshot = await purgeQuery.limit(batchSize).get();
    if (snapshot.empty) break;

    const batch = db.batch();
    snapshot.docs.forEach((doc) => {
      if (sampleDeletedIds.length < 200) sampleDeletedIds.push(doc.id);
      batch.delete(doc.ref);
    });
    await batch.commit();
    deletedCount += snapshot.size;
    if (snapshot.size < batchSize) break;
  }

  await writeAudit(
    actorUserId,
    "purge",
    "transactions",
    "bulk",
    {
      filter: {
        projectId: projectId || "all",
        startDate: startDate || "all",
        endDate: endDate || "all"
      },
      deletedCount,
      sampleDeletedIds
    },
    null,
    "Admin transaction purge"
  );

  return { deletedCount };
});

export const auditAdminWrites = onDocumentWritten("{collectionId}/{docId}", async (event) => {
  const { collectionId, docId } = event.params;
  if (!AUDITED_COLLECTIONS.has(collectionId)) return;
  if (!event.data) return;

  const before: DocumentData | null = event.data.before.exists ? event.data.before.data() ?? null : null;
  const after: DocumentData | null = event.data.after.exists ? event.data.after.data() ?? null : null;
  const actorUserId = String(after?.updatedBy ?? before?.updatedBy ?? "system");
  const action = before && after ? "update" : before ? "delete" : "create";

  await writeAudit(actorUserId, action, collectionId.slice(0, -1), docId, before, after);
});
