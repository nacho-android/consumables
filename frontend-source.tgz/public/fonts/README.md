Arimo Regular and Bold are embedded as font subsets in invoice PDFs. Arimo is metrically compatible with Arial, which the workbook uses. The invoice's dimensions and pagination come from the shared print-layout module.

Source: https://github.com/googlefonts/Arimo/tree/main/fonts/ttf

See Arimo-OFL.txt for the SIL Open Font License. The older Roboto files remain for compatibility with previously loaded app versions.
