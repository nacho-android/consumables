Roboto Condensed Regular and Bold are bundled for invoice PDF rendering and embedded as font subsets.

Source: https://github.com/googlefonts/roboto-2/tree/main/src/hinted

Copyright 2011 Google Inc. Licensed under the Apache License, Version 2.0; see Roboto-LICENSE.txt.
