# Consumable Acquisitions

A secure, mobile-friendly web app for recording consumable item acquisitions. It uses Firebase Auth, Cloud Firestore, Firestore Security Rules, and Firebase Cloud Functions. Supabase is not used.

## What Is Included

- React + TypeScript frontend.
- Firebase Auth email/password login, persistent sessions, password reset, and password change.
- Firestore data model for profiles, projects, memberships, items, transactions, and audit logs.
- Backend-enforced Firestore Security Rules in `firestore.rules`.
- Firebase Functions for admin user management and transaction void/correct workflows.
- Admin screens for users, projects, items, imports, exports, and transaction correction.
- Browser CSV/XLSX export.
- Spreadsheet import through the admin UI and a dry-run-first CLI script.
- Sydney date defaults via `Australia/Sydney`.

## Local Setup

1. Install Node.js 20+.
2. Install dependencies:

```powershell
npm install
cd functions
npm install
cd ..
```

3. Create a Firebase project.
4. Enable Firebase Authentication with Email/Password.
5. Create a Firestore database.
6. Copy `.env.example` to `.env.local` and fill in the Firebase web app values.
7. Copy `.firebaserc.example` to `.firebaserc` and set your Firebase project ID.

Run locally:

```powershell
npm run dev
```

Run Firebase emulators:

```powershell
npm run firebase:emulators
```

## Admin Bootstrap

The first admin must be created from a trusted machine with Firebase Admin credentials. Use Application Default Credentials or `GOOGLE_APPLICATION_CREDENTIALS`.

```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS="C:\secure\firebase-service-account.json"
$env:ADMIN_EMAIL="admin@example.org"
$env:ADMIN_DISPLAY_NAME="System Admin"
$env:ADMIN_TEMP_PASSWORD="replace-with-a-long-temporary-password"
npm run bootstrap:admin
```

After login, change the password from the Admin page.

## Seed / Import

Admin UI:

1. Log in as an admin.
2. Open Admin utilities.
3. Open Import.
4. Upload `items_20260603.xlsx`.
5. Review errors/warnings, then import.
6. Create user accounts with real email addresses.
7. Upload `projects-users_20260603.xlsx`.
8. Import projects and matched memberships. Unmatched display names need accounts or exact display-name reconciliation.

CLI dry run:

```powershell
npm run import:spreadsheets -- --items items_20260603.xlsx --projects-users projects-users_20260603.xlsx
```

CLI commit:

```powershell
npm run import:spreadsheets -- --items items_20260603.xlsx --projects-users projects-users_20260603.xlsx --commit
```

The item importer trims text, preserves `database_code`, treats `item_code` as text, validates `active`, reports missing `item_code`, reports missing `unit_of_measure`, reports duplicate names/codes, and writes items by `database_code` after explicit preview/commit.

The seed spreadsheets are not committed by default because the frontend repository is public and the project/user file contains real names.

## Deploy

Firebase Hosting:

```powershell
npm run build
firebase deploy --only firestore,functions,hosting
```

GitHub Pages or Cloudflare Pages can host the static `dist` output, but the app still needs Firebase Auth, Firestore, rules, indexes, and Functions deployed.

If using strict signup blocking, deploy Functions first, then register `blockUninvitedAuthUser` under Firebase Authentication blocking functions in the Firebase/Google Cloud console.

GitHub Pages deployment uses `.github/workflows/deploy-pages.yml`. The workflow includes the Firebase web app config for `viv-consumables`; these values are not backend secrets. You can override them with repository variables if the Firebase web app changes. Optional `VITE_BASE_PATH` defaults to `/consumables/`.

Optional backend deployment uses `.github/workflows/deploy-firebase.yml`. Add `FIREBASE_SERVICE_ACCOUNT` as a GitHub secret containing a Firebase service-account JSON with permission to deploy Firestore rules/indexes and Functions.

The deployment service account needs IAM permissions to deploy Firebase resources. In Google Cloud IAM, grant a purpose-specific deploy service account these roles, or equivalent custom permissions:

- Firebase Admin
- Cloud Functions Developer
- Cloud Build Service Account or Cloud Build Editor
- Service Account User
- Firestore Service Agent or Firestore Owner
- Firebase Rules Admin

## Security Notes

- Do not commit `.env.local`, service account JSON, or Admin SDK credentials.
- The Firebase web API key is not a database secret; access is controlled by Auth, Firestore Rules, and Functions.
- Keep `firestore.rules` deployed with the app.
- Use HTTPS hosting only.
- For strict admin-only Auth account creation, enable Firebase Authentication with Identity Platform blocking functions and register the included `blockUninvitedAuthUser` trigger. Without the blocking trigger, stray Firebase Auth accounts may be created outside the UI, but they receive no profile and Firestore Rules deny app data access.
- Enable Firebase App Check before production use if the deployment target supports it.
- Review audit logs after admin imports and transaction corrections.
- As of this build, root production dependencies audit clean. Firebase Functions production dependencies report a moderate transitive `uuid` advisory through the current Firebase Admin SDK / Google Cloud package chain; npm's forced fix downgrades Firebase Admin and is not recommended without Firebase compatibility testing.

## Basic Test Plan

- Login rejects invalid credentials with a generic error.
- Inactive profile is signed out and cannot read Firestore data.
- Standard user sees only active memberships and active items on entry.
- Standard user cannot query another project’s transactions.
- Standard user cannot write a transaction for another user ID, inactive project, inactive item, or non-member project.
- Transaction creation stores acquisition date and server submission timestamp.
- Add clears the form; Add & Done navigates to Summary; Clear does not submit.
- Summary filters by today/week/month/year/custom range and paginates at 10/20/50/100.
- CSV and XLSX exports contain the required friendly columns.
- Admin can create user, generate reset link, assign projects, activate/deactivate, and safe delete/deactivate.
- Admin can activate/deactivate projects and items without hiding historical transaction snapshots.
- Void marks the original transaction voided and writes audit log.
- Correct marks the original corrected, creates a replacement linked by `originalTransactionId`, and writes audit log.
- Import reports missing item codes, missing units, invalid active values, duplicate names, and duplicate item codes.

## More Detail

See `docs/ARCHITECTURE.md` for the backend option comparison, collection schema, security model, and assumptions.
