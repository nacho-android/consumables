# Architecture

## Chosen Implementation

This project implements a static React/TypeScript frontend with Firebase Authentication, Cloud Firestore, Firestore Security Rules, and Firebase Cloud Functions.

The user specifically requested not to use Supabase. The recommended non-Supabase option is Firebase Hosting or another static host for the frontend, Firebase Authentication for email/password sessions, Firestore for data, Firestore Security Rules for backend-enforced project access, and Cloud Functions for privileged admin operations that require Firebase Admin SDK.

Public frontend code contains only Firebase web configuration. It must never contain service account JSON, Firebase Admin SDK credentials, or privileged API keys.

## Option Comparison

| Option | Free-tier suitability | Authentication | Database | Project-level security | Export ease | Risks / limitations | Recommendation |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GitHub Pages + Firebase Auth + Firestore | GitHub Pages is suitable for static hosting. Firebase Spark includes Auth and Firestore free quotas; Cloud Functions need Blaze/pay-as-you-go with no-cost quotas. | Firebase email/password, password reset, persistent sessions. | Firestore document database. | Firestore Rules can enforce membership checks per document. | CSV/XLSX can run in browser; larger exports may need server-side batching. | Admin Auth operations need Cloud Functions, so GitHub Pages alone is not enough for full admin user creation. | Good if you want GitHub Pages hosting; still requires Firebase backend and Functions. |
| GitHub Pages + Supabase backend | Good static hosting and strong relational backend. | Supabase Auth. | Postgres. | Postgres RLS is excellent for project membership rules. | SQL/views/functions make exports clean. | Not implemented because the user asked not to use Supabase. | Would normally be strongest relational fit, but excluded. |
| Firebase Hosting + Firebase Auth + Firestore | Firebase Hosting static deploy is straightforward; Auth/Firestore free quotas fit a small app. Functions require Blaze but include free monthly quotas. | Firebase email/password, reset links, Admin SDK. | Firestore document database. | Firestore Rules enforce profile, role, project membership, active item/project checks. | Browser CSV/XLSX works well for expected data size. | Firestore is not relational; reporting joins are handled with denormalized snapshots. Blaze billing must be enabled for Functions. | Recommended non-Supabase option and implemented here. |
| Cloudflare Pages + Workers + D1 | Pages, Workers, and D1 have useful free allowances. | No first-party simple email/password user store equivalent to Firebase Auth; custom auth must be built or integrated. | D1 SQLite. | Enforced in Worker API code, not direct browser database rules. | CSV export is easy through Worker endpoints. | Custom auth/session/password reset is higher security burden. D1 is newer and operational patterns are more bespoke. | Good if you want full API ownership, but more custom security work. |
| Render/Fly/Railway free app + Postgres-like backend | Useful for a traditional API and relational schema when free quota is available. | Implement via Auth.js, Firebase Auth, or custom. | Depends on provider; free Postgres options change often. | API-enforced plus SQL policies if available. | Server-side exports easy. | Free tiers sleep/change; more ops work than Firebase. | Reasonable fallback, not selected for lowest admin overhead. |

Official references checked:

- Firebase pricing and free quotas: https://firebase.google.com/pricing
- Firestore Security Rules: https://firebase.google.com/docs/firestore/security/get-started
- Firebase Admin user management: https://firebase.google.com/docs/auth/admin/manage-users
- GitHub Pages static hosting: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- Cloudflare D1 pricing: https://developers.cloudflare.com/d1/platform/pricing/
- Cloudflare Pages limits: https://developers.cloudflare.com/pages/platform/limits/
- Supabase RLS, evaluated but not used: https://supabase.com/docs/guides/database/postgres/row-level-security

## Data Model

Firestore stores document IDs separately from document fields. The application uses stable document IDs:

- `profiles/{uid}` where `uid` is the Firebase Auth UID.
- `projects/{projectId}` where `projectId` is a slug from `projectCode`.
- `projectMemberships/{uid_projectId}`.
- `items/{databaseCode}` because `database_code` is stable and `item_code` may be blank or duplicated.
- `transactions/{autoId}`.
- `auditLog/{autoId}`.
- `importRuns/{autoId}` for optional admin import previews or records.

### profiles

- `email`
- `displayName`
- `role`: `admin` or `standard`
- `active`
- `createdAt`
- `updatedAt`
- `updatedBy`

### projects

- `projectCode`
- `projectName`
- `active`
- `createdAt`
- `updatedAt`
- `updatedBy`

### projectMemberships

- `userId`
- `projectId`
- `active`
- `createdAt`
- `updatedAt`
- `updatedBy`

### items

- `databaseCode`
- `itemCode`
- `itemType`
- `item`
- `unitOfMeasure`
- `active`
- `createdAt`
- `updatedAt`
- `updatedBy`

### transactions

- `transactionDate`: `YYYY-MM-DD` acquisition date in Sydney-facing UI.
- `submittedAt`: server timestamp for actual submission time.
- `userId`
- `projectId`
- `itemId`
- `amount`
- `unitOfMeasure`
- `comments`
- `status`: `active`, `voided`, or `corrected`
- `originalTransactionId`
- `voidOrCorrectionReason`
- `correctedBy`
- `correctedAt`
- `createdAt`
- `updatedAt`
- `updatedBy`
- Snapshot fields: `userDisplayName`, `userEmail`, `projectCode`, `projectName`, `databaseCode`, `itemCode`, `itemType`, `itemName`

Snapshot fields keep historical summaries readable after users, projects, or items are deactivated or renamed.

### auditLog

- `actorUserId`
- `action`
- `entityType`
- `entityId`
- `beforeJson`
- `afterJson`
- `reason`
- `createdAt`

## Security Model

- Firebase Auth handles email/password login, persistent sessions, password reset, and password changes.
- Strict admin-only account creation is enforced by the included `blockUninvitedAuthUser` Auth blocking Function when Firebase Authentication with Identity Platform blocking functions is enabled. Admin user creation writes a short-lived allowlist entry before calling the Admin SDK.
- Inactive profiles are signed out by the frontend and blocked by Firestore Rules.
- Standard users can read only active memberships and transactions for projects where they have active membership.
- Standard users can create transactions only for their own UID, active projects, active items, and active memberships.
- Standard users cannot update/delete transactions.
- Transaction void/correct actions go through Cloud Functions and always write audit log records.
- Admin user creation, disabling, safe delete/deactivate, and password reset-link generation go through Cloud Functions.
- Admin CRUD for projects/items/memberships/profiles is rule-restricted and audited by a Firestore trigger.
- React escapes rendered text by default. Free-text comments are stored as text and rendered without `dangerouslySetInnerHTML`.
- CSV export quotes fields to avoid malformed output.

## Assumptions

- The supplied project/user spreadsheet has names but no email addresses, so it can seed projects immediately and can seed memberships only for profiles whose display names already match those names.
- Admins create real user accounts with email addresses before importing or reconciling memberships.
- Export volumes are expected to be operationally modest. For very large exports, add a server-side paginated export Function.
- Cloud Functions deployment requires Firebase Blaze. It has no-cost quotas, but billing must be enabled.
- Firebase Auth blocking functions may require upgrading Firebase Authentication to Identity Platform. If that is not enabled, unprofiled self-created Auth accounts still cannot access Firestore data, but the Auth user record itself is not prevented at creation time.
