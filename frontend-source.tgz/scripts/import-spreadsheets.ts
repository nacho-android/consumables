import { initializeApp, applicationDefault } from "firebase-admin/app";
import { FieldValue, getFirestore } from "firebase-admin/firestore";
import { DOMParser } from "@xmldom/xmldom";
import { readFileSync } from "node:fs";
import { firstSheetRowsFromXlsx } from "../src/lib/importers";
import { ALLOWED_UNITS } from "../src/lib/units";

type RawRow = Record<string, unknown>;

type ItemSeed = {
  rowNumber: number;
  databaseCode: string;
  itemCode: string;
  itemType: string;
  item: string;
  unitOfMeasure: string;
  active: boolean;
  cost: number | null;
};

type ProjectUserSeed = {
  rowNumber: number;
  projectCode: string;
  displayName: string;
};

type Issue = {
  severity: "warning" | "error";
  row?: number;
  field?: string;
  message: string;
};

const args = new Set(process.argv.slice(2));
const commit = args.has("--commit");
const itemsOnly = args.has("--items-only");
const projectsUsersOnly = args.has("--projects-users-only");
const itemsPath = valueAfter("--items") ?? "items_20260605.xlsx";
const projectUsersPath = valueAfter("--projects-users") ?? "projects-users_20260603.xlsx";

initializeApp({ credential: applicationDefault() });
const db = getFirestore();

function valueAfter(flag: string): string | undefined {
  const index = process.argv.indexOf(flag);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

function trim(value: unknown): string {
  return value === null || value === undefined ? "" : String(value).trim();
}

function readRows(path: string): RawRow[] {
  const bytes = readFileSync(path);
  return firstSheetRowsFromXlsx(
    bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    (xml) => new DOMParser().parseFromString(xml, "application/xml") as unknown as Document
  );
}

function parseActive(value: unknown, row: number, issues: Issue[]): boolean {
  const text = trim(value).toLowerCase();
  if (["yes", "y", "true", "1", "active"].includes(text)) return true;
  if (["no", "n", "false", "0", "inactive"].includes(text)) return false;
  issues.push({ severity: "error", row, field: "active", message: `Invalid active value "${trim(value)}".` });
  return false;
}

function parseCost(value: unknown, row: number, issues: Issue[]): number | null {
  const text = trim(value);
  if (!text) {
    issues.push({ severity: "warning", row, field: "cost", message: "Missing cost." });
    return null;
  }
  const cost = Number(text.replace(/[$,]/g, ""));
  if (!Number.isFinite(cost) || cost < 0) {
    issues.push({ severity: "error", row, field: "cost", message: `Invalid cost value "${text}".` });
    return null;
  }
  return cost;
}

function count(values: string[]): Map<string, number> {
  const counts = new Map<string, number>();
  values.filter(Boolean).forEach((value) => counts.set(value, (counts.get(value) ?? 0) + 1));
  return counts;
}

function parseItems(path: string): { rows: ItemSeed[]; issues: Issue[] } {
  const issues: Issue[] = [];
  const rows = readRows(path).map((raw, index) => {
    const rowNumber = index + 2;
    const item: ItemSeed = {
      rowNumber,
      databaseCode: trim(raw.database_code),
      itemCode: trim(raw.item_code),
      itemType: trim(raw.item_type),
      item: trim(raw.item),
      unitOfMeasure: trim(raw.unit_of_measure),
      active: parseActive(raw.active, rowNumber, issues),
      cost: parseCost(raw.cost, rowNumber, issues)
    };
    if (!item.databaseCode) issues.push({ severity: "error", row: rowNumber, field: "database_code", message: "Missing database_code." });
    if (!item.itemCode) issues.push({ severity: "warning", row: rowNumber, field: "item_code", message: "Missing item_code." });
    if (!item.unitOfMeasure) issues.push({ severity: "warning", row: rowNumber, field: "unit_of_measure", message: "Missing unit_of_measure." });
    if (item.unitOfMeasure && !(ALLOWED_UNITS as readonly string[]).includes(item.unitOfMeasure)) {
      issues.push({ severity: "error", row: rowNumber, field: "unit_of_measure", message: `Invalid unit_of_measure "${item.unitOfMeasure}". Use each, box, or daily.` });
    }
    if (!item.item) issues.push({ severity: "error", row: rowNumber, field: "item", message: "Missing item." });
    return item;
  });

  const names = count(rows.map((row) => row.item.toLowerCase()));
  const codes = count(rows.map((row) => row.itemCode.toLowerCase()));
  rows.forEach((row) => {
    if (row.item && names.get(row.item.toLowerCase())! > 1) {
      issues.push({ severity: "warning", row: row.rowNumber, field: "item", message: `Duplicate item name "${row.item}".` });
    }
    if (row.itemCode && codes.get(row.itemCode.toLowerCase())! > 1) {
      issues.push({ severity: "warning", row: row.rowNumber, field: "item_code", message: `Duplicate item_code "${row.itemCode}".` });
    }
  });
  return { rows, issues };
}

function parseProjectUsers(path: string): { rows: ProjectUserSeed[]; issues: Issue[] } {
  const issues: Issue[] = [];
  const rows = readRows(path).map((raw, index) => {
    const rowNumber = index + 2;
    const row = {
      rowNumber,
      projectCode: trim(raw.project),
      displayName: trim(raw.user)
    };
    if (!row.projectCode) issues.push({ severity: "error", row: rowNumber, field: "project", message: "Missing project." });
    if (!row.displayName) issues.push({ severity: "error", row: rowNumber, field: "user", message: "Missing user." });
    return row;
  });
  return { rows, issues };
}

function projectIdFromCode(projectCode: string): string {
  return projectCode.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

async function main() {
  if (itemsOnly && projectsUsersOnly) {
    console.log("Use either --items-only or --projects-users-only, not both.");
    return;
  }

  const shouldImportItems = !projectsUsersOnly;
  const shouldImportProjectUsers = !itemsOnly;
  const items = shouldImportItems ? parseItems(itemsPath) : { rows: [], issues: [] };
  const projectUsers = shouldImportProjectUsers ? parseProjectUsers(projectUsersPath) : { rows: [], issues: [] };
  const allIssues = [...items.issues, ...projectUsers.issues];
  const errors = allIssues.filter((issue) => issue.severity === "error");

  if (shouldImportItems) console.log(`Items: ${items.rows.length} rows`);
  if (shouldImportProjectUsers) console.log(`Project/user rows: ${projectUsers.rows.length}`);
  console.log(`Issues: ${errors.length} errors, ${allIssues.length - errors.length} warnings`);
  allIssues.slice(0, 30).forEach((issue) => {
    console.log(`${issue.severity.toUpperCase()} ${issue.row ? `row ${issue.row} ` : ""}${issue.field ?? ""}: ${issue.message}`);
  });

  if (errors.length > 0) {
    console.log("Fix errors before committing.");
    return;
  }
  if (!commit) {
    console.log("Dry run only. Re-run with --commit to write to Firestore.");
    return;
  }

  const batch = db.batch();
  const now = FieldValue.serverTimestamp();

  items.rows.forEach((row) => {
    batch.set(db.collection("items").doc(row.databaseCode), {
      databaseCode: row.databaseCode,
      itemCode: row.itemCode,
      itemType: row.itemType,
      item: row.item,
      unitOfMeasure: row.unitOfMeasure,
      active: row.active,
      createdAt: now,
      updatedAt: now,
      updatedBy: "script-import"
    }, { merge: true });
    batch.set(db.collection("itemCosts").doc(row.databaseCode), {
      itemId: row.databaseCode,
      databaseCode: row.databaseCode,
      itemCode: row.itemCode,
      itemType: row.itemType,
      itemName: row.item,
      cost: row.cost,
      createdAt: now,
      updatedAt: now,
      updatedBy: "script-import"
    }, { merge: true });
  });

  const projectCodes = [...new Set(projectUsers.rows.map((row) => row.projectCode).filter(Boolean))];
  projectCodes.forEach((projectCode) => {
    const projectId = projectIdFromCode(projectCode);
    batch.set(db.collection("projects").doc(projectId), {
      projectCode,
      projectName: projectCode,
      active: true,
      createdAt: now,
      updatedAt: now,
      updatedBy: "script-import"
    }, { merge: true });
  });

  let matchedMemberships = 0;
  const unmatched = new Set<string>();
  if (shouldImportProjectUsers) {
    const profilesSnapshot = await db.collection("profiles").get();
    const profilesByName = new Map(
      profilesSnapshot.docs.map((doc) => [String(doc.get("displayName")).toLowerCase(), doc.id])
    );
    projectUsers.rows.forEach((row) => {
      const uid = profilesByName.get(row.displayName.toLowerCase());
      if (!uid) {
        unmatched.add(row.displayName);
        return;
      }
      const projectId = projectIdFromCode(row.projectCode);
      batch.set(db.collection("projectMemberships").doc(`${uid}_${projectId}`), {
        userId: uid,
        projectId,
        active: true,
        createdAt: now,
        updatedAt: now,
        updatedBy: "script-import"
      }, { merge: true });
      matchedMemberships += 1;
    });
  }

  await batch.commit();
  console.log(`Committed ${items.rows.length} items, ${items.rows.length} item costs, ${projectCodes.length} projects, ${matchedMemberships} memberships.`);
  if (unmatched.size > 0) {
    console.log(`Unmatched user display names: ${[...unmatched].join(", ")}`);
  }
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
