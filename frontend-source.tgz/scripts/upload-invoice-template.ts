import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { readFileSync } from "node:fs";
import { basename, resolve } from "node:path";

type Args = {
  file: string;
  commit: boolean;
};

function parseArgs(): Args {
  const args = process.argv.slice(2);
  const fileIndex = args.indexOf("--file");
  return {
    file: fileIndex >= 0 ? args[fileIndex + 1] : "invoice_template_20260605.xlsx",
    commit: args.includes("--commit")
  };
}

function initializeAdmin(): void {
  if (getApps().length) return;
  const keyPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;
  if (!keyPath) {
    initializeApp();
    return;
  }
  initializeApp({
    credential: cert(JSON.parse(readFileSync(keyPath, "utf8")))
  });
}

async function main(): Promise<void> {
  const args = parseArgs();
  const filePath = resolve(args.file);
  const bytes = readFileSync(filePath);
  const contentBase64 = bytes.toString("base64");
  console.log(`Template: ${filePath}`);
  console.log(`Size: ${bytes.byteLength} bytes`);

  if (!args.commit) {
    console.log("Dry run only. Add --commit to upload to Firestore.");
    return;
  }

  initializeAdmin();
  await getFirestore().collection("appConfig").doc("invoiceTemplate").set(
    {
      fileName: basename(filePath),
      contentBase64,
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      updatedAt: FieldValue.serverTimestamp()
    },
    { merge: true }
  );
  console.log("Uploaded invoice template to appConfig/invoiceTemplate.");
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
