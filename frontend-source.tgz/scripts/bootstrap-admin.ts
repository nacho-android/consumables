import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { FieldValue, Timestamp, getFirestore } from "firebase-admin/firestore";

const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
const displayName = process.env.ADMIN_DISPLAY_NAME?.trim() || "Admin";
const password = process.env.ADMIN_TEMP_PASSWORD;

if (!email || !password) {
  console.error("Set ADMIN_EMAIL and ADMIN_TEMP_PASSWORD before running this script.");
  process.exit(1);
}

initializeApp({ credential: applicationDefault() });

const auth = getAuth();
const db = getFirestore();

function allowlistIdForEmail(value: string): string {
  return Buffer.from(value.toLowerCase()).toString("base64url");
}

async function main() {
  let user;
  try {
    user = await auth.getUserByEmail(email!);
    await auth.updateUser(user.uid, {
      displayName,
      disabled: false,
      password
    });
  } catch {
    await db.collection("authCreationAllowlist").doc(allowlistIdForEmail(email!)).set({
      email,
      createdBy: "bootstrap-admin",
      createdAt: FieldValue.serverTimestamp(),
      expiresAt: Timestamp.fromMillis(Date.now() + 5 * 60 * 1000)
    });
    user = await auth.createUser({
      email,
      displayName,
      disabled: false,
      emailVerified: false,
      password
    });
  }

  await db.collection("profiles").doc(user.uid).set(
    {
      email,
      displayName,
      role: "admin",
      active: true,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      updatedBy: "bootstrap-admin"
    },
    { merge: true }
  );

  console.log(`Admin ready: ${email} (${user.uid})`);
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
