import {
  addDoc,
  deleteField,
  deleteDoc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch
} from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  FileDown,
  FileUp,
  KeyRound,
  Pencil,
  Plus,
  RefreshCw,
  Save,
  Search,
  ShieldAlert,
  Trash2,
  UserPlus
} from "lucide-react";
import { useEffect, useState } from "react";
import { Message } from "../components/Message";
import { useAuth } from "../hooks/useAuth";
import {
  auditLogCollection,
  billingAddressDoc,
  billingAddressesCollection,
  inventoryCollection,
  itemCostDoc,
  itemCostsCollection,
  itemDoc,
  itemsCollection,
  membershipDoc,
  membershipsCollection,
  profilesCollection,
  projectDoc,
  projectsCollection,
  transactionsCollection
} from "../lib/collections";
import { functions } from "../lib/firebase";
import { downloadRowsXlsx } from "../lib/export";
import {
  itemIdFromDatabaseCode,
  billingAddressIdFromDisplayName,
  parseBillingAddressesFile,
  parseItemsFile,
  parseProjectUsersFile,
  projectIdFromCode,
  type ParsedItemsImport,
  type ParsedBillingAddressesImport,
  type ParsedProjectUsersImport
} from "../lib/importers";
import { formatDate, formatDateTime } from "../lib/date";
import { costBoxForItem, costEachForItem, formatCost } from "../lib/itemCosts";
import { ALLOWED_UNITS, FALLBACK_UNIT, safeUnit } from "../lib/units";
import type {
  AcquisitionTransaction,
  BillingAddress,
  InventoryRecord,
  Item,
  ItemCost,
  Profile,
  Project,
  ProjectMembership,
  Role
} from "../types";

type AdminTab = "users" | "projects" | "items" | "inventory" | "billingAddresses" | "data" | "bulkImportExport";

const PAGE_SIZES = [10, 20, 50, 100] as const;

const createUser = httpsCallable(functions, "adminCreateUser");
const updateUser = httpsCallable(functions, "adminUpdateUser");
const resetPassword = httpsCallable(functions, "adminTriggerPasswordReset");
const deleteOrDeactivateUser = httpsCallable(functions, "adminDeleteOrDeactivateUser");
const voidTransaction = httpsCallable(functions, "voidTransaction");
const correctTransaction = httpsCallable(functions, "correctTransaction");
const deleteOrDeactivateProject = httpsCallable(functions, "adminDeleteOrDeactivateProject");
const deleteOrDeactivateItem = httpsCallable(functions, "adminDeleteOrDeactivateItem");
const submitStocktake = httpsCallable(functions, "adminSubmitStocktake");

function adminTabLabel(tab: AdminTab): string {
  if (tab === "billingAddresses") return "billing addresses";
  if (tab === "bulkImportExport") return "bulk import/export";
  return tab;
}

export function AdminPage(): JSX.Element {
  const { user } = useAuth();
  const [tab, setTab] = useState<AdminTab>("users");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [memberships, setMemberships] = useState<ProjectMembership[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [inventory, setInventory] = useState<InventoryRecord[]>([]);
  const [itemCosts, setItemCosts] = useState<ItemCost[]>([]);
  const [billingAddresses, setBillingAddresses] = useState<BillingAddress[]>([]);
  const [transactions, setTransactions] = useState<AcquisitionTransaction[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function refreshAll() {
    setBusy(true);
    setError(null);
    try {
      const [profileSnap, projectSnap, membershipSnap, itemSnap, inventorySnap, itemCostSnap, billingAddressSnap] = await Promise.all([
        getDocs(query(profilesCollection, orderBy("displayName"))),
        getDocs(query(projectsCollection, orderBy("projectCode"))),
        getDocs(query(membershipsCollection, orderBy("projectId"))),
        getDocs(query(itemsCollection, orderBy("item"))),
        getDocs(inventoryCollection),
        getDocs(query(itemCostsCollection, orderBy("itemName"))),
        getDocs(query(billingAddressesCollection, orderBy("displayName")))
      ]);
      setProfiles(profileSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Profile)));
      setProjects(projectSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Project)));
      setMemberships(membershipSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as ProjectMembership)));
      setItems(itemSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Item)));
      setInventory(inventorySnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as InventoryRecord)));
      setItemCosts(itemCostSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as ItemCost)));
      setBillingAddresses(billingAddressSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as BillingAddress)));
    } catch {
      setError("Could not load admin data.");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    void refreshAll();
  }, []);

  async function loadTransactions() {
    const snapshot = await getDocs(query(transactionsCollection, orderBy("submittedAt", "desc")));
    setTransactions(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as AcquisitionTransaction)));
  }

  return (
    <section className="admin-layout">
      <div className="toolbar">
        <div className="segmented" aria-label="Admin section">
          {(["users", "projects", "items", "inventory", "billingAddresses", "data", "bulkImportExport"] as AdminTab[]).map((nextTab) => (
            <button key={nextTab} type="button" className={tab === nextTab ? "active" : ""} onClick={() => setTab(nextTab)}>
              {adminTabLabel(nextTab)}
            </button>
          ))}
        </div>
        <button className="secondary" type="button" disabled={busy} onClick={() => void refreshAll()}>
          <RefreshCw size={18} aria-hidden="true" />
          Refresh
        </button>
      </div>

      {message ? <Message kind="success">{message}</Message> : null}
      {error ? <Message kind="error">{error}</Message> : null}

      {tab === "users" ? (
        <UsersAdmin
          profiles={profiles}
          projects={projects}
          memberships={memberships}
          actorId={user!.uid}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
      {tab === "projects" ? (
        <ProjectsAdmin projects={projects} actorId={user!.uid} onMessage={setMessage} onError={setError} onRefresh={refreshAll} />
      ) : null}
      {tab === "items" ? (
        <ItemsAdmin
          items={items}
          itemCosts={itemCosts}
          actorId={user!.uid}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
      {tab === "inventory" ? (
        <InventoryAdmin
          items={items}
          inventory={inventory}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
      {tab === "billingAddresses" ? (
        <BillingAddressesAdmin
          billingAddresses={billingAddresses}
          projects={projects}
          actorId={user!.uid}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
      {tab === "data" ? (
        <DataAdmin
          transactions={transactions}
          projects={projects}
          items={items}
          onLoad={loadTransactions}
          onMessage={setMessage}
          onError={setError}
        />
      ) : null}
      {tab === "bulkImportExport" ? (
        <BulkImportExportAdmin
          actorId={user!.uid}
          profiles={profiles}
          projects={projects}
          memberships={memberships}
          items={items}
          inventory={inventory}
          itemCosts={itemCosts}
          billingAddresses={billingAddresses}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
    </section>
  );
}

type AdminChildProps = {
  onMessage: (message: string | null) => void;
  onError: (message: string | null) => void;
  onRefresh: () => Promise<void>;
};

function UsersAdmin({
  profiles,
  projects,
  memberships,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & {
  profiles: Profile[];
  projects: Project[];
  memberships: ProjectMembership[];
  actorId: string;
}): JSX.Element {
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<Role>("standard");
  const [newProjectIds, setNewProjectIds] = useState<string[]>([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [editProjectIds, setEditProjectIds] = useState<string[]>([]);
  const [editingUserId, setEditingUserId] = useState("");
  const [editDisplayName, setEditDisplayName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editRole, setEditRole] = useState<Role>("standard");
  const [resetLink, setResetLink] = useState("");

  async function submitCreate(event: React.FormEvent) {
    event.preventDefault();
    onError(null);
    onMessage(null);
    try {
      const result = await createUser({ email, displayName, role, projectIds: newProjectIds });
      const link = (result.data as { resetLink?: string }).resetLink || "";
      setResetLink(link);
      setEmail("");
      setDisplayName("");
      setNewProjectIds([]);
      onMessage("User created. Share the reset link through a trusted channel.");
      await onRefresh();
    } catch {
      onError("Could not create the user.");
    }
  }

  async function toggleActive(profile: Profile) {
    try {
      await updateUser({ uid: profile.id, active: !profile.active });
      onMessage(profile.active ? "User deactivated." : "User activated.");
      await onRefresh();
    } catch {
      onError("Could not update user status.");
    }
  }

  async function sendReset(profile: Profile) {
    try {
      const result = await resetPassword({ email: profile.email });
      setResetLink((result.data as { resetLink?: string }).resetLink || "");
      onMessage("Password reset link generated.");
    } catch {
      onError("Could not generate password reset link.");
    }
  }

  async function removeUser(profile: Profile) {
    if (!window.confirm(`Delete ${profile.displayName}? Users with transaction history cannot be deleted and will be deactivated instead.`)) return;
    try {
      const result = await deleteOrDeactivateUser({ uid: profile.id });
      const action = (result.data as { action: string }).action;
      onMessage(
        action === "deleted"
          ? "User deleted because they had no transaction history."
          : "User has transaction history, so they were deactivated instead of deleted."
      );
      await onRefresh();
    } catch {
      onError("Could not delete or deactivate user.");
    }
  }

  async function saveMemberships() {
    const target = profiles.find((profile) => profile.id === selectedUserId);
    if (!target) return;
    try {
      await updateUser({ uid: target.id, projectIds: editProjectIds });
      onMessage("Project memberships saved.");
      await onRefresh();
    } catch {
      onError("Could not save memberships.");
    }
  }

  function startEditUser(profile: Profile) {
    setEditingUserId(profile.id);
    setEditDisplayName(profile.displayName);
    setEditEmail(profile.email);
    setEditRole(profile.role);
    onError(null);
    onMessage(null);
  }

  async function saveUserEdit(event: React.FormEvent) {
    event.preventDefault();
    const target = profiles.find((profile) => profile.id === editingUserId);
    if (!target) return;
    try {
      await updateUser({
        uid: target.id,
        email: editEmail,
        displayName: editDisplayName,
        role: editRole
      });
      setEditingUserId("");
      onMessage("User details saved.");
      await onRefresh();
    } catch {
      onError("Could not save user details.");
    }
  }

  function toggleNewProject(projectId: string) {
    setNewProjectIds((current) =>
      current.includes(projectId)
        ? current.filter((id) => id !== projectId)
        : [...current, projectId]
    );
  }

  function toggleEditProject(projectId: string) {
    setEditProjectIds((current) =>
      current.includes(projectId)
        ? current.filter((id) => id !== projectId)
        : [...current, projectId]
    );
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void submitCreate(event)}>
        <h2>Add user</h2>
        <label htmlFor="new-user-email">Email</label>
        <input id="new-user-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
        <label htmlFor="new-user-name">Display name</label>
        <input id="new-user-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} required />
        <label htmlFor="new-user-role">Role</label>
        <select id="new-user-role" value={role} onChange={(event) => setRole(event.target.value as Role)}>
          <option value="standard">standard</option>
          <option value="admin">admin</option>
        </select>
        <ProjectCheckboxes projects={projects.filter((project) => project.active)} selected={newProjectIds} onToggle={toggleNewProject} />
        <button type="submit">
          <UserPlus size={18} aria-hidden="true" />
          Add user
        </button>
        {resetLink ? <textarea readOnly rows={3} value={resetLink} aria-label="Password reset link" /> : null}
      </form>

      {editingUserId ? (
        <form className="panel form-stack" onSubmit={(event) => void saveUserEdit(event)}>
          <h2>Edit user</h2>
          <label htmlFor="edit-user-email">Email</label>
          <input id="edit-user-email" type="email" value={editEmail} onChange={(event) => setEditEmail(event.target.value)} required />
          <label htmlFor="edit-user-name">Display name</label>
          <input id="edit-user-name" value={editDisplayName} onChange={(event) => setEditDisplayName(event.target.value)} required />
          <label htmlFor="edit-user-role">Role</label>
          <select id="edit-user-role" value={editRole} onChange={(event) => setEditRole(event.target.value as Role)}>
            <option value="standard">standard</option>
            <option value="admin">admin</option>
          </select>
          <div className="button-row">
            <button type="submit">
              <Pencil size={18} aria-hidden="true" />
              Save user
            </button>
            <button className="secondary" type="button" onClick={() => setEditingUserId("")}>
              Cancel
            </button>
          </div>
        </form>
      ) : null}

      <section className="panel">
        <h2>Users</h2>
        <div className="table-shell compact-table">
          <table>
            <thead>
              <tr>
                <th>User</th>
                <th>Role</th>
                <th>Active</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {profiles.map((profile) => (
                <tr key={profile.id}>
                  <td data-label="User">
                    <span>{profile.displayName}</span>
                    <small>{profile.email}</small>
                  </td>
                  <td data-label="Role">{profile.role}</td>
                  <td data-label="Active">{profile.active ? "yes" : "no"}</td>
                  <td data-label="Actions" className="action-cell">
                    <button className="secondary" type="button" onClick={() => startEditUser(profile)}>
                      <Pencil size={16} aria-hidden="true" />
                      Edit
                    </button>
                    <button className="secondary" type="button" onClick={() => void toggleActive(profile)}>
                      <ShieldAlert size={16} aria-hidden="true" />
                      {profile.active ? "Deactivate" : "Activate"}
                    </button>
                    <button className="secondary" type="button" onClick={() => void sendReset(profile)}>
                      <KeyRound size={16} aria-hidden="true" />
                      Reset
                    </button>
                    <button className="danger" type="button" disabled={profile.id === actorId} onClick={() => void removeUser(profile)}>
                      <Trash2 size={16} aria-hidden="true" />
                      Delete/Deactivate
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="panel form-stack">
        <h2>Memberships</h2>
        <label htmlFor="membership-user">User</label>
        <select
          id="membership-user"
          value={selectedUserId}
          onChange={(event) => {
            const uid = event.target.value;
            setSelectedUserId(uid);
            setEditProjectIds([...memberships.filter((membership) => membership.userId === uid && membership.active).map((membership) => membership.projectId)]);
          }}
        >
          <option value="">Select user</option>
          {profiles.map((profile) => (
            <option key={profile.id} value={profile.id}>{profile.displayName}</option>
          ))}
        </select>
        {selectedUserId ? (
          <>
            <ProjectCheckboxes
              projects={projects}
              selected={editProjectIds}
              onToggle={toggleEditProject}
            />
            <button type="button" onClick={() => void saveMemberships()}>
              <Pencil size={18} aria-hidden="true" />
              Save memberships
            </button>
          </>
        ) : null}
      </section>
    </div>
  );
}

function ProjectsAdmin({
  projects,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & { projects: Project[]; actorId: string }): JSX.Element {
  const [projectCode, setProjectCode] = useState("");
  const [projectName, setProjectName] = useState("");
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);

  async function saveProject(event: React.FormEvent) {
    event.preventDefault();
    const trimmedCode = projectCode.trim();
    const trimmedName = projectName.trim() || trimmedCode;
    if (!trimmedCode) {
      onError("Project code is required.");
      return;
    }
    const duplicate = projects.find(
      (project) =>
        project.id !== editingProjectId &&
        project.projectCode.trim().toLowerCase() === trimmedCode.toLowerCase()
    );
    if (duplicate) {
      onError("Another project already uses that code.");
      return;
    }
    try {
      if (editingProjectId) {
        await updateDoc(projectDoc(editingProjectId), {
          projectCode: trimmedCode,
          projectName: trimmedName,
          updatedAt: serverTimestamp(),
          updatedBy: actorId
        });
      } else {
        await setDoc(
          projectDoc(projectIdFromCode(trimmedCode)),
          {
            projectCode: trimmedCode,
            projectName: trimmedName,
            active: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      }
      setProjectCode("");
      setProjectName("");
      setEditingProjectId(null);
      onMessage("Project saved.");
      await onRefresh();
    } catch {
      onError("Could not save project.");
    }
  }

  async function toggleProject(project: Project) {
    try {
      await updateDoc(projectDoc(project.id), {
        active: !project.active,
        updatedAt: serverTimestamp(),
        updatedBy: actorId
      });
      onMessage(project.active ? "Project deactivated." : "Project activated.");
      await onRefresh();
    } catch {
      onError("Could not update project.");
    }
  }

  async function removeProject(project: Project) {
    if (!window.confirm(`Delete ${project.projectCode} if safe, otherwise deactivate?`)) return;
    try {
      const result = await deleteOrDeactivateProject({ projectId: project.id });
      onMessage(`Project ${(result.data as { action: string }).action}.`);
      await onRefresh();
    } catch {
      onError("Could not delete or deactivate project.");
    }
  }

  function editProject(project: Project) {
    setEditingProjectId(project.id);
    setProjectCode(project.projectCode);
    setProjectName(project.projectName);
    onError(null);
    onMessage(null);
  }

  function cancelEdit() {
    setEditingProjectId(null);
    setProjectCode("");
    setProjectName("");
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void saveProject(event)}>
        <h2>{editingProjectId ? "Edit project" : "Add project"}</h2>
        <label htmlFor="project-code">Project code</label>
        <input id="project-code" value={projectCode} onChange={(event) => setProjectCode(event.target.value)} required />
        <label htmlFor="project-name">Project name</label>
        <input id="project-name" value={projectName} onChange={(event) => setProjectName(event.target.value)} />
        <div className="button-row">
          <button type="submit">
            <Plus size={18} aria-hidden="true" />
            Save project
          </button>
          {editingProjectId ? (
            <button className="secondary" type="button" onClick={cancelEdit}>
              Cancel
            </button>
          ) : null}
        </div>
      </form>
      <EntityTable
        title="Projects"
        rows={projects.map((project) => ({
          id: project.id,
          primary: project.projectCode,
          secondary: project.projectName,
          active: project.active,
          onEdit: () => editProject(project),
          onToggle: () => void toggleProject(project),
          onDelete: () => void removeProject(project)
        }))}
      />
    </div>
  );
}

function ItemsAdmin({
  items,
  itemCosts,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & { items: Item[]; itemCosts: ItemCost[]; actorId: string }): JSX.Element {
  const [search, setSearch] = useState("");
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [form, setForm] = useState(() => emptyItemForm(nextAvailableDatabaseCode(items)));
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(0);
  const costByItemId = new Map(itemCosts.map((itemCost) => [itemCost.itemId, itemCost]));
  const suggestedDatabaseCode = nextAvailableDatabaseCode(items);
  const filtered = items.filter((item) =>
    [item.item, item.databaseCode, item.itemCode, item.itemType].join(" ").toLowerCase().includes(search.toLowerCase())
  );
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pagedItems = filtered.slice(page * pageSize, page * pageSize + pageSize);

  useEffect(() => {
    if (editingItemId) return;
    setForm((current) => current.databaseCode ? current : { ...current, databaseCode: suggestedDatabaseCode });
  }, [editingItemId, suggestedDatabaseCode]);

  useEffect(() => {
    setPage(0);
  }, [search]);

  useEffect(() => {
    setPage((current) => Math.min(current, totalPages - 1));
  }, [totalPages]);

  async function saveItem(event: React.FormEvent) {
    event.preventDefault();
    const trimmed = {
      databaseCode: form.databaseCode.trim(),
      itemCode: form.itemCode.trim(),
      itemType: form.itemType.trim(),
      item: form.item.trim(),
      unitOfMeasure: safeUnit(form.unitOfMeasure)
    };
    const parsedCostEach = parseCostInput(form.costEach);
    const parsedCostBox = parseCostInput(form.costBox);
    if (!trimmed.databaseCode || !trimmed.item) {
      onError("Database code and item name are required.");
      return;
    }
    if (parsedCostEach === "invalid" || parsedCostBox === "invalid") {
      onError("Costs must be non-negative numbers.");
      return;
    }
    const duplicate = items.find(
      (item) =>
        item.id !== editingItemId &&
        item.databaseCode.trim().toLowerCase() === trimmed.databaseCode.toLowerCase()
    );
    if (duplicate) {
      onError("Another item already uses that database code.");
      return;
    }
    try {
      if (editingItemId) {
        await updateDoc(itemDoc(editingItemId), {
          ...trimmed,
          updatedAt: serverTimestamp(),
          updatedBy: actorId
        });
        await setDoc(
          itemCostDoc(editingItemId),
          {
            itemId: editingItemId,
            databaseCode: trimmed.databaseCode,
            itemCode: trimmed.itemCode,
            itemType: trimmed.itemType,
            itemName: trimmed.item,
            costEach: parsedCostEach,
            costBox: parsedCostBox,
            cost: deleteField(),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      } else {
        const newItemId = itemIdFromDatabaseCode(trimmed.databaseCode);
        await setDoc(
          itemDoc(newItemId),
          {
            ...trimmed,
            active: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
        await setDoc(
          itemCostDoc(newItemId),
          {
            itemId: newItemId,
            databaseCode: trimmed.databaseCode,
            itemCode: trimmed.itemCode,
            itemType: trimmed.itemType,
            itemName: trimmed.item,
            costEach: parsedCostEach,
            costBox: parsedCostBox,
            cost: deleteField(),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      }
      const nextDatabaseCode = editingItemId
        ? suggestedDatabaseCode
        : nextAvailableDatabaseCode([...items, { databaseCode: trimmed.databaseCode }]);
      setForm(emptyItemForm(nextDatabaseCode));
      setEditingItemId(null);
      onMessage("Item saved.");
      await onRefresh();
    } catch {
      onError("Could not save item.");
    }
  }

  async function toggleItem(item: Item) {
    try {
      await updateDoc(itemDoc(item.id), {
        active: !item.active,
        updatedAt: serverTimestamp(),
        updatedBy: actorId
      });
      onMessage(item.active ? "Item deactivated." : "Item activated.");
      await onRefresh();
    } catch {
      onError("Could not update item.");
    }
  }

  async function removeItem(item: Item) {
    if (!window.confirm(`Delete ${item.item} if safe, otherwise deactivate?`)) return;
    try {
      const result = await deleteOrDeactivateItem({ itemId: item.id });
      onMessage(`Item ${(result.data as { action: string }).action}.`);
      await onRefresh();
    } catch {
      onError("Could not delete or deactivate item.");
    }
  }

  function editItem(item: Item) {
    setEditingItemId(item.id);
    setForm({
      databaseCode: item.databaseCode,
      itemCode: item.itemCode,
      itemType: item.itemType,
      item: item.item,
      unitOfMeasure: safeUnit(item.unitOfMeasure),
      costEach: costEachForItem(costByItemId.get(item.id))?.toString() ?? "",
      costBox: costBoxForItem(costByItemId.get(item.id))?.toString() ?? ""
    });
    onError(null);
    onMessage(null);
  }

  function cancelEdit() {
    setEditingItemId(null);
    setForm(emptyItemForm(suggestedDatabaseCode));
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void saveItem(event)}>
        <h2>{editingItemId ? "Edit item" : "Add item"}</h2>
        {(["databaseCode", "itemCode", "itemType", "item"] as const).map((field) => (
          <div className="form-stack compact" key={field}>
            <label htmlFor={field}>{field}</label>
            <input
              id={field}
              value={form[field]}
              required={field === "databaseCode" || field === "item"}
              onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))}
            />
          </div>
        ))}
        <label htmlFor="unitOfMeasure">unitOfMeasure</label>
        <select
          id="unitOfMeasure"
          value={form.unitOfMeasure}
          onChange={(event) => setForm((current) => ({ ...current, unitOfMeasure: safeUnit(event.target.value) }))}
        >
          {ALLOWED_UNITS.map((unit) => (
            <option key={unit} value={unit}>{unit}</option>
          ))}
        </select>
        <div className="two-column">
          <div className="form-stack compact">
            <label htmlFor="item-cost-each">cost each</label>
            <input
              id="item-cost-each"
              type="number"
              inputMode="decimal"
              step="0.01"
              min="0"
              value={form.costEach}
              onChange={(event) => setForm((current) => ({ ...current, costEach: event.target.value }))}
            />
          </div>
          <div className="form-stack compact">
            <label htmlFor="item-cost-box">cost box</label>
            <input
              id="item-cost-box"
              type="number"
              inputMode="decimal"
              step="0.01"
              min="0"
              value={form.costBox}
              onChange={(event) => setForm((current) => ({ ...current, costBox: event.target.value }))}
            />
          </div>
        </div>
        <button type="submit">
          <Plus size={18} aria-hidden="true" />
          Save item
        </button>
        {editingItemId ? (
          <button className="secondary" type="button" onClick={cancelEdit}>
            Cancel
          </button>
        ) : null}
      </form>
      <section className="panel">
        <h2>Items</h2>
        <div className="field-row">
          <Search size={18} aria-hidden="true" />
          <input aria-label="Search items" value={search} onChange={(event) => setSearch(event.target.value)} />
        </div>
        <EntityTable
          title=""
          rows={pagedItems.map((item) => ({
            id: item.id,
            primary: item.item,
            secondary: [
              item.itemType,
              item.databaseCode,
              item.itemCode,
              item.unitOfMeasure || "missing unit",
              `each ${formatCost(costEachForItem(costByItemId.get(item.id)))}`,
              `box ${formatCost(costBoxForItem(costByItemId.get(item.id)))}`
            ].join(" | "),
            active: item.active,
            onEdit: () => editItem(item),
            onToggle: () => void toggleItem(item),
            onDelete: () => void removeItem(item)
          }))}
        />
        <footer className="pagination">
          <label htmlFor="items-page-size">Rows</label>
          <select
            id="items-page-size"
            value={pageSize}
            onChange={(event) => {
              setPageSize(Number(event.target.value));
              setPage(0);
            }}
          >
            {PAGE_SIZES.map((size) => <option key={size} value={size}>{size}</option>)}
          </select>
          <button className="icon-button" type="button" disabled={page === 0} onClick={() => setPage((current) => current - 1)} title="Previous page">
            <ChevronLeft size={20} aria-hidden="true" />
            <span className="sr-only">Previous page</span>
          </button>
          <span>Page {page + 1} of {totalPages}</span>
          <button className="icon-button" type="button" disabled={page + 1 >= totalPages} onClick={() => setPage((current) => current + 1)} title="Next page">
            <ChevronRight size={20} aria-hidden="true" />
            <span className="sr-only">Next page</span>
          </button>
        </footer>
      </section>
    </div>
  );
}

function emptyItemForm(databaseCode: string) {
  return {
    databaseCode,
    itemCode: "",
    itemType: "",
    item: "",
    unitOfMeasure: FALLBACK_UNIT,
    costEach: "",
    costBox: ""
  };
}

function nextAvailableDatabaseCode(items: Array<Pick<Item, "databaseCode">>): string {
  const parsed = items
    .map((item) => item.databaseCode.trim().match(/^(.*?)(\d+)$/))
    .filter((match): match is RegExpMatchArray => Boolean(match));
  if (parsed.length === 0) return "";

  const prefixCounts = new Map<string, number>();
  parsed.forEach((match) => prefixCounts.set(match[1], (prefixCounts.get(match[1]) ?? 0) + 1));
  const prefix = [...prefixCounts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0][0];
  const matching = parsed.filter((match) => match[1] === prefix);
  const width = Math.max(...matching.map((match) => match[2].length));
  const used = new Set(matching.map((match) => Number(match[2])));
  let next = Math.max(...used, 0) + 1;
  while (used.has(next)) next += 1;
  return `${prefix}${String(next).padStart(width, "0")}`;
}

function parseCostInput(value: string): number | null | "invalid" {
  const trimmed = value.trim();
  if (!trimmed) return null;
  const parsed = Number(trimmed);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : "invalid";
}

function InventoryAdmin({
  items,
  inventory,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & { items: Item[]; inventory: InventoryRecord[] }): JSX.Element {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [actualBalances, setActualBalances] = useState<Record<string, string>>({});
  const [addStockAmounts, setAddStockAmounts] = useState<Record<string, string>>({});
  const [alertThresholds, setAlertThresholds] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(0);
  const inventoryByItemId = new Map(inventory.map((record) => [record.itemId || record.id, record]));

  useEffect(() => {
    setAlertThresholds(Object.fromEntries(inventory.map((record) => [
      record.itemId || record.id,
      typeof record.alertThreshold === "number" ? String(record.alertThreshold) : ""
    ])));
  }, [inventory]);

  const filtered = items
    .filter((item) => {
      if (statusFilter === "active" && !item.active) return false;
      if (statusFilter === "inactive" && item.active) return false;
      return [item.item, item.databaseCode, item.itemCode, item.itemType]
        .join(" ")
        .toLowerCase()
        .includes(search.trim().toLowerCase());
    });
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pagedItems = filtered.slice(page * pageSize, page * pageSize + pageSize);

  useEffect(() => {
    setPage(0);
  }, [search, statusFilter]);

  useEffect(() => {
    setPage((current) => Math.min(current, totalPages - 1));
  }, [totalPages]);

  function copyCalculatedBalance(itemId: string): void {
    const calculated = inventoryByItemId.get(itemId)?.calculatedBalance;
    if (typeof calculated !== "number") return;
    setActualBalances((current) => ({ ...current, [itemId]: String(calculated) }));
  }

  async function saveStocktake(): Promise<void> {
    onError(null);
    onMessage(null);
    const entries: Array<{ itemId: string; actualBalance?: number; addStock?: number; alertThreshold: number | null }> = [];

    for (const item of items) {
      const actualText = (actualBalances[item.id] ?? "").trim();
      const addStockText = (addStockAmounts[item.id] ?? "").trim();
      const thresholdText = (alertThresholds[item.id] ?? "").trim();
      const currentThreshold = inventoryByItemId.get(item.id)?.alertThreshold ?? null;
      const actualBalance = actualText === "" ? undefined : Number(actualText);
      const addStock = addStockText === "" ? undefined : Number(addStockText);
      const alertThreshold = thresholdText === "" ? null : Number(thresholdText);

      if (actualBalance !== undefined && addStock !== undefined) {
        onError(`Choose either Actual Balance or Add Stock for ${item.item}, not both. Clear one value and submit again.`);
        return;
      }
      if (actualBalance !== undefined && !Number.isFinite(actualBalance)) {
        onError(`Enter a valid actual balance for ${item.item}.`);
        return;
      }
      if (addStock !== undefined && (!Number.isFinite(addStock) || addStock <= 0)) {
        onError(`Add Stock for ${item.item} must be a positive number.`);
        return;
      }
      if (addStock !== undefined && typeof inventoryByItemId.get(item.id)?.calculatedBalance !== "number") {
        onError(`Enter and submit an Actual Balance for ${item.item} before adding stock.`);
        return;
      }
      if (alertThreshold !== null && !Number.isFinite(alertThreshold)) {
        onError(`Enter a valid alert threshold for ${item.item}.`);
        return;
      }

      const thresholdChanged = alertThreshold !== currentThreshold;
      if (actualBalance === undefined && addStock === undefined && !thresholdChanged) continue;
      entries.push({
        itemId: item.id,
        ...(actualBalance === undefined ? {} : { actualBalance }),
        ...(addStock === undefined ? {} : { addStock }),
        alertThreshold
      });
    }

    if (entries.length === 0) {
      onError("Enter at least one actual balance, add stock amount, or change an alert threshold.");
      return;
    }

    setBusy(true);
    try {
      const result = await submitStocktake({ entries });
      const updatedCount = Number((result.data as { updatedCount?: unknown }).updatedCount ?? entries.length);
      setActualBalances({});
      setAddStockAmounts({});
      onMessage(`Stocktake saved for ${updatedCount} item${updatedCount === 1 ? "" : "s"}.`);
      await onRefresh();
    } catch (error) {
      onError(error instanceof Error && error.message ? error.message : "Could not save the stocktake.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-grid">
      <section className="panel full-width-panel form-stack">
        <div className="form-header">
          <div>
            <h2>Inventory stocktake</h2>
            <p className="helper-text">
              Enter the physically counted balance for each item, or use the arrow to copy its calculated balance. Use Add Stock to increase an existing calculated balance. Actual Balance and Add Stock cannot both be entered for the same item. Alerts are emailed to active admins after an acquisition leaves an item at or below its threshold; leave a threshold blank to disable alerts.
            </p>
          </div>
          <button type="button" disabled={busy} onClick={() => void saveStocktake()}>
            <Save size={18} aria-hidden="true" />
            Submit stocktake
          </button>
        </div>

        <div className="toolbar stocktake-filters">
          <div className="field-row">
            <Search size={18} aria-hidden="true" />
            <input
              type="search"
              aria-label="Search inventory"
              placeholder="Search items"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <label className="inline-field" htmlFor="inventory-status-filter">
            Status
            <select id="inventory-status-filter" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value as typeof statusFilter)}>
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </label>
        </div>

        <div className="table-shell stocktake-table">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Last checked</th>
                <th>Calculated Balance</th>
                <th>Actual Balance</th>
                <th>Add Stock</th>
                <th>Alert Threshold</th>
              </tr>
            </thead>
            <tbody>
              {pagedItems.map((item) => {
                const record = inventoryByItemId.get(item.id);
                const hasCalculatedBalance = typeof record?.calculatedBalance === "number";
                return (
                  <tr key={item.id}>
                    <td data-label="Name">
                      <span>{item.item}</span>
                      <small>{[item.itemType, item.databaseCode, item.itemCode, item.unitOfMeasure, item.active ? "active" : "inactive"].filter(Boolean).join(" | ")}</small>
                    </td>
                    <td data-label="Last checked">
                      {record?.lastCheckedAt ? (
                        <>
                          <span>{formatDateTime(record.lastCheckedAt)}</span>
                          <small>{record.lastCheckedByName || record.lastCheckedBy || "Unknown user"}</small>
                        </>
                      ) : "n/a"}
                    </td>
                    <td data-label="Calculated Balance">{hasCalculatedBalance ? formatBalance(record.calculatedBalance!) : "n/a"}</td>
                    <td data-label="Actual Balance">
                      <div className="balance-entry">
                        <button
                          className="icon-button"
                          type="button"
                          disabled={!hasCalculatedBalance}
                          title="Copy calculated balance"
                          onClick={() => copyCalculatedBalance(item.id)}
                        >
                          <ArrowRight size={18} aria-hidden="true" />
                          <span className="sr-only">Copy calculated balance for {item.item}</span>
                        </button>
                        <input
                          type="number"
                          inputMode="decimal"
                          step="any"
                          aria-label={`Actual balance for ${item.item}`}
                          value={actualBalances[item.id] ?? ""}
                          onChange={(event) => setActualBalances((current) => ({ ...current, [item.id]: event.target.value }))}
                        />
                      </div>
                    </td>
                    <td data-label="Add Stock">
                      <input
                        type="number"
                        inputMode="decimal"
                        min={Number.MIN_VALUE}
                        step="any"
                        disabled={!hasCalculatedBalance}
                        title={hasCalculatedBalance ? "Add to calculated balance" : "Submit an actual balance first"}
                        aria-label={`Add stock for ${item.item}`}
                        value={addStockAmounts[item.id] ?? ""}
                        onChange={(event) => setAddStockAmounts((current) => ({ ...current, [item.id]: event.target.value }))}
                      />
                    </td>
                    <td data-label="Alert Threshold">
                      <input
                        type="number"
                        inputMode="decimal"
                        step="any"
                        aria-label={`Alert threshold for ${item.item}`}
                        value={alertThresholds[item.id] ?? ""}
                        onChange={(event) => setAlertThresholds((current) => ({ ...current, [item.id]: event.target.value }))}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 ? <p className="empty-row">No matching items.</p> : null}
        </div>
        <footer className="pagination">
          <label htmlFor="inventory-page-size">Rows</label>
          <select
            id="inventory-page-size"
            value={pageSize}
            onChange={(event) => {
              setPageSize(Number(event.target.value));
              setPage(0);
            }}
          >
            {PAGE_SIZES.map((size) => <option key={size} value={size}>{size}</option>)}
          </select>
          <button className="icon-button" type="button" disabled={page === 0} onClick={() => setPage((current) => current - 1)} title="Previous page">
            <ChevronLeft size={20} aria-hidden="true" />
            <span className="sr-only">Previous page</span>
          </button>
          <span>Page {page + 1} of {totalPages}</span>
          <button className="icon-button" type="button" disabled={page + 1 >= totalPages} onClick={() => setPage((current) => current + 1)} title="Next page">
            <ChevronRight size={20} aria-hidden="true" />
            <span className="sr-only">Next page</span>
          </button>
        </footer>
      </section>
    </div>
  );
}

function formatBalance(value: number): string {
  return Number.isInteger(value) ? value.toLocaleString() : value.toLocaleString(undefined, { maximumFractionDigits: 6 });
}

function parseProjectCodes(projectCodes: string): string[] {
  return projectCodes
    .split(/[,;\n]+/)
    .map((code) => code.trim())
    .filter(Boolean);
}

function projectIdsFromCodes(projects: Project[], projectCodes: string): string[] {
  const selectedCodes = new Set(parseProjectCodes(projectCodes).map((code) => code.toLowerCase()));
  return projects
    .filter((project) => selectedCodes.has(project.projectCode.trim().toLowerCase()))
    .map((project) => project.id);
}

function projectCodesFromIds(projects: Project[], projectIds: string[]): string {
  const selectedIds = new Set(projectIds);
  return projects
    .filter((project) => selectedIds.has(project.id))
    .map((project) => project.projectCode.trim())
    .filter(Boolean)
    .join(", ");
}

function BillingAddressesAdmin({
  billingAddresses,
  projects,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & { billingAddresses: BillingAddress[]; projects: Project[]; actorId: string }): JSX.Element {
  const [form, setForm] = useState({
    displayName: "",
    address: "",
    projectCodes: ""
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const selectedProjectIds = projectIdsFromCodes(projects, form.projectCodes);

  async function saveBillingAddress(event: React.FormEvent) {
    event.preventDefault();
    const displayName = form.displayName.trim();
    const address = form.address.trim();
    const projectCodes = form.projectCodes.trim();
    if (!displayName || !address) {
      onError("Display name and address are required.");
      return;
    }
    const duplicate = billingAddresses.find(
      (entry) =>
        entry.id !== editingId &&
        entry.displayName.trim().toLowerCase() === displayName.toLowerCase()
    );
    if (duplicate) {
      onError("Another billing address already uses that display name.");
      return;
    }

    try {
      const id = editingId || billingAddressIdFromDisplayName(displayName);
      await setDoc(
        billingAddressDoc(id),
        {
          displayName,
          address,
          projectCodes,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          updatedBy: actorId
        },
        { merge: true }
      );
      setEditingId(null);
      setForm({ displayName: "", address: "", projectCodes: "" });
      onMessage("Billing address saved.");
      await onRefresh();
    } catch {
      onError("Could not save billing address.");
    }
  }

  function editBillingAddress(entry: BillingAddress) {
    setEditingId(entry.id);
    setForm({
      displayName: entry.displayName,
      address: entry.address,
      projectCodes: entry.projectCodes
    });
    onError(null);
    onMessage(null);
  }

  function toggleBillingProject(projectId: string) {
    setForm((current) => {
      const currentIds = projectIdsFromCodes(projects, current.projectCodes);
      const nextIds = currentIds.includes(projectId)
        ? currentIds.filter((id) => id !== projectId)
        : [...currentIds, projectId];
      return { ...current, projectCodes: projectCodesFromIds(projects, nextIds) };
    });
  }

  async function removeBillingAddress(entry: BillingAddress) {
    if (!window.confirm(`Delete billing address for ${entry.displayName}?`)) return;
    try {
      await deleteDoc(billingAddressDoc(entry.id));
      onMessage("Billing address deleted.");
      await onRefresh();
    } catch {
      onError("Could not delete billing address.");
    }
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void saveBillingAddress(event)}>
        <h2>{editingId ? "Edit billing address" : "Add billing address"}</h2>
        <label htmlFor="billing-display-name">Display name</label>
        <input
          id="billing-display-name"
          value={form.displayName}
          onChange={(event) => setForm((current) => ({ ...current, displayName: event.target.value }))}
          required
        />
        <label htmlFor="billing-address">Address</label>
        <textarea
          id="billing-address"
          rows={5}
          value={form.address}
          onChange={(event) => setForm((current) => ({ ...current, address: event.target.value }))}
          required
        />
        <ProjectCheckboxes
          projects={projects}
          selected={selectedProjectIds}
          onToggle={toggleBillingProject}
        />
        <div className="button-row">
          <button type="submit">
            <Plus size={18} aria-hidden="true" />
            Save billing address
          </button>
          {editingId ? (
            <button className="secondary" type="button" onClick={() => {
              setEditingId(null);
              setForm({ displayName: "", address: "", projectCodes: "" });
            }}>
              Cancel
            </button>
          ) : null}
        </div>
      </form>

      <section className="panel">
        <h2>Billing addresses</h2>
        <div className="table-shell compact-table">
          <table>
            <thead>
              <tr>
                <th>Display name</th>
                <th>Project codes</th>
                <th>Address</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {billingAddresses.map((entry) => (
                <tr key={entry.id}>
                  <td data-label="Display name">{entry.displayName}</td>
                  <td data-label="Project codes">{entry.projectCodes}</td>
                  <td data-label="Address"><small>{entry.address}</small></td>
                  <td data-label="Actions" className="action-cell">
                    <button className="secondary" type="button" onClick={() => editBillingAddress(entry)}>
                      <Pencil size={16} aria-hidden="true" />
                      Edit
                    </button>
                    <button className="danger" type="button" onClick={() => void removeBillingAddress(entry)}>
                      <Trash2 size={16} aria-hidden="true" />
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function DataAdmin({
  transactions,
  projects,
  items,
  onLoad,
  onMessage,
  onError
}: {
  transactions: AcquisitionTransaction[];
  projects: Project[];
  items: Item[];
  onLoad: () => Promise<void>;
  onMessage: (message: string | null) => void;
  onError: (message: string | null) => void;
}): JSX.Element {
  const [selected, setSelected] = useState<AcquisitionTransaction | null>(null);
  const [reason, setReason] = useState("");
  const [replacement, setReplacement] = useState({
    transactionDate: "",
    projectId: "",
    itemId: "",
    amount: "",
    unitOfMeasure: "",
    comments: ""
  });
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(0);
  const totalPages = Math.max(1, Math.ceil(transactions.length / pageSize));
  const pagedTransactions = transactions.slice(page * pageSize, page * pageSize + pageSize);

  useEffect(() => {
    setPage((current) => Math.min(current, totalPages - 1));
  }, [totalPages]);
  async function voidSelected(tx: AcquisitionTransaction) {
    const why = window.prompt("Reason for voiding this transaction");
    if (!why) return;
    try {
      await voidTransaction({ transactionId: tx.id, reason: why });
      onMessage("Transaction voided.");
      await onLoad();
    } catch {
      onError("Could not void transaction.");
    }
  }

  function startCorrection(tx: AcquisitionTransaction) {
    setSelected(tx);
    setReason("");
    setReplacement({
      transactionDate: tx.transactionDate,
      projectId: tx.projectId,
      itemId: tx.itemId,
      amount: String(tx.amount),
      unitOfMeasure: safeUnit(tx.unitOfMeasure),
      comments: tx.comments || ""
    });
  }

  async function submitCorrection(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) return;
    const project = projects.find((entry) => entry.id === replacement.projectId);
    const item = items.find((entry) => entry.id === replacement.itemId);
    if (!project || !item || !reason.trim()) {
      onError("Correction requires a reason, project, and item.");
      return;
    }
    try {
      await correctTransaction({
        transactionId: selected.id,
        reason,
        replacement: {
          transactionDate: replacement.transactionDate,
          projectId: project.id,
          itemId: item.id,
          amount: Number(replacement.amount),
          unitOfMeasure: replacement.unitOfMeasure,
          comments: replacement.comments,
          projectCode: project.projectCode,
          projectName: project.projectName,
          databaseCode: item.databaseCode,
          itemCode: item.itemCode,
          itemType: item.itemType,
          itemName: item.item
        }
      });
      setSelected(null);
      onMessage("Correction saved.");
      await onLoad();
    } catch {
      onError("Could not correct transaction.");
    }
  }

  return (
    <div className="admin-grid">
      <section className="panel full-width-panel">
        <div className="form-header">
          <h2>Transactions</h2>
          <button className="secondary" type="button" onClick={() => void onLoad()}>
            <RefreshCw size={18} aria-hidden="true" />
            Load
          </button>
        </div>
        <div className="table-shell compact-table">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Project</th>
                <th>Item</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {pagedTransactions.map((tx) => (
                <tr key={tx.id}>
                  <td data-label="Date">
                    <span>{formatDate(tx.transactionDate)}</span>
                    <small>{formatDateTime(tx.submittedAt)}</small>
                  </td>
                  <td data-label="Project">{tx.projectCode}</td>
                  <td data-label="Item">{tx.itemName}</td>
                  <td data-label="Status"><span className={`status ${tx.status}`}>{tx.status}</span></td>
                  <td data-label="Actions" className="action-cell">
                    <button className="secondary" type="button" disabled={tx.status !== "active"} onClick={() => void voidSelected(tx)}>
                      Void
                    </button>
                    <button className="secondary" type="button" disabled={tx.status !== "active"} onClick={() => startCorrection(tx)}>
                      Correct
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {pagedTransactions.length === 0 ? <p className="empty-row">Load transactions to review them.</p> : null}
        </div>
        <footer className="pagination">
          <label htmlFor="data-page-size">Rows</label>
          <select
            id="data-page-size"
            value={pageSize}
            onChange={(event) => {
              setPageSize(Number(event.target.value));
              setPage(0);
            }}
          >
            {PAGE_SIZES.map((size) => <option key={size} value={size}>{size}</option>)}
          </select>
          <button className="icon-button" type="button" disabled={page === 0} onClick={() => setPage((current) => current - 1)} title="Previous page">
            <ChevronLeft size={20} aria-hidden="true" />
            <span className="sr-only">Previous page</span>
          </button>
          <span>Page {page + 1} of {totalPages}</span>
          <button className="icon-button" type="button" disabled={page + 1 >= totalPages} onClick={() => setPage((current) => current + 1)} title="Next page">
            <ChevronRight size={20} aria-hidden="true" />
            <span className="sr-only">Next page</span>
          </button>
        </footer>
      </section>

      {selected ? (
        <form className="panel form-stack" onSubmit={(event) => void submitCorrection(event)}>
          <h2>Correct transaction</h2>
          <label htmlFor="correction-reason">Reason</label>
          <textarea id="correction-reason" value={reason} onChange={(event) => setReason(event.target.value)} required />
          <label htmlFor="correction-date">Date</label>
          <input id="correction-date" type="date" value={replacement.transactionDate} onChange={(event) => setReplacement((current) => ({ ...current, transactionDate: event.target.value }))} required />
          <label htmlFor="correction-project">Project</label>
          <select id="correction-project" value={replacement.projectId} onChange={(event) => setReplacement((current) => ({ ...current, projectId: event.target.value }))}>
            {projects.map((project) => <option key={project.id} value={project.id}>{project.projectCode} {project.projectName}</option>)}
          </select>
          <label htmlFor="correction-item">Item</label>
          <select id="correction-item" value={replacement.itemId} onChange={(event) => setReplacement((current) => ({ ...current, itemId: event.target.value }))}>
            {items.map((item) => <option key={item.id} value={item.id}>{item.item}</option>)}
          </select>
          <label htmlFor="correction-amount">Amount</label>
          <input id="correction-amount" type="number" step="any" value={replacement.amount} onChange={(event) => setReplacement((current) => ({ ...current, amount: event.target.value }))} required />
          <label htmlFor="correction-unit">Unit</label>
          <select id="correction-unit" value={safeUnit(replacement.unitOfMeasure)} onChange={(event) => setReplacement((current) => ({ ...current, unitOfMeasure: event.target.value }))} required>
            {ALLOWED_UNITS.map((unit) => <option key={unit} value={unit}>{unit}</option>)}
          </select>
          <label htmlFor="correction-comments">Comments</label>
          <textarea id="correction-comments" value={replacement.comments} onChange={(event) => setReplacement((current) => ({ ...current, comments: event.target.value }))} />
          <button type="submit">Save correction</button>
        </form>
      ) : null}
    </div>
  );
}

const ITEM_EXPORT_HEADERS = ["database_code", "item_code", "item_type", "item", "unit_of_measure", "active", "cost_each", "cost_box", "calculated_balance", "alert_threshold"];
const BILLING_ADDRESS_EXPORT_HEADERS = ["Display_name", "Address", "Project_codes"];
const USER_PROJECT_EXPORT_HEADERS = ["email", "display_name", "project_code", "project_name"];

type ChangePreview = {
  lines: Array<{ label: string; value: string | number }>;
  details: string[];
};

type BatchWrite = (batch: ReturnType<typeof writeBatch>) => void;

async function commitBatchWrites(
  firestore: Parameters<typeof writeBatch>[0],
  writes: BatchWrite[],
  chunkSize = 450
): Promise<void> {
  for (let index = 0; index < writes.length; index += chunkSize) {
    const batch = writeBatch(firestore);
    writes.slice(index, index + chunkSize).forEach((write) => write(batch));
    await batch.commit();
  }
}

function BulkImportExportAdmin({
  actorId,
  profiles,
  projects,
  memberships,
  items,
  inventory,
  itemCosts,
  billingAddresses,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & {
  actorId: string;
  profiles: Profile[];
  projects: Project[];
  memberships: ProjectMembership[];
  items: Item[];
  inventory: InventoryRecord[];
  itemCosts: ItemCost[];
  billingAddresses: BillingAddress[];
}): JSX.Element {
  const [itemsImport, setItemsImport] = useState<ParsedItemsImport | null>(null);
  const [billingAddressesImport, setBillingAddressesImport] = useState<ParsedBillingAddressesImport | null>(null);
  const [projectUsersImport, setProjectUsersImport] = useState<ParsedProjectUsersImport | null>(null);

  const itemPreview = itemsImport ? buildItemsPreview(itemsImport, items, itemCosts) : null;
  const billingPreview = billingAddressesImport ? buildBillingAddressesPreview(billingAddressesImport, billingAddresses) : null;
  const membershipPlan = projectUsersImport ? buildMembershipImportPlan(projectUsersImport, profiles, projects, memberships) : null;
  const membershipPreview = membershipPlan ? membershipPlan.preview : null;

  function downloadItemsExport() {
    const inventoryByItemId = new Map(inventory.map((record) => [record.itemId || record.id, record]));
    const rows = [...items]
      .sort((a, b) => a.databaseCode.localeCompare(b.databaseCode))
      .map((item) => {
        const itemCost = itemCostForItem(item, itemCosts);
        const inventoryRecord = inventoryByItemId.get(item.id);
        return {
          database_code: item.databaseCode,
          item_code: item.itemCode,
          item_type: item.itemType,
          item: item.item,
          unit_of_measure: item.unitOfMeasure,
          active: item.active ? "TRUE" : "FALSE",
          cost_each: costEachForItem(itemCost) ?? "",
          cost_box: costBoxForItem(itemCost) ?? "",
          calculated_balance: typeof inventoryRecord?.calculatedBalance === "number" ? inventoryRecord.calculatedBalance : "",
          alert_threshold: typeof inventoryRecord?.alertThreshold === "number" ? inventoryRecord.alertThreshold : ""
        };
      });
    downloadRowsXlsx({
      rows,
      headers: ITEM_EXPORT_HEADERS,
      sheetName: "Items",
      fileName: `${timestampForFile()}-items-list.xlsx`
    });
  }

  function downloadBillingAddressesExport() {
    const rows = [...billingAddresses]
      .sort((a, b) => a.displayName.localeCompare(b.displayName))
      .map((entry) => ({
        Display_name: entry.displayName,
        Address: entry.address,
        Project_codes: entry.projectCodes
      }));
    downloadRowsXlsx({
      rows,
      headers: BILLING_ADDRESS_EXPORT_HEADERS,
      sheetName: "Invoice addresses",
      fileName: `${timestampForFile()}-invoice-addresses.xlsx`
    });
  }

  function downloadUserProjectsExport() {
    const profileById = new Map(profiles.map((profile) => [profile.id, profile]));
    const projectById = new Map(projects.map((project) => [project.id, project]));
    const rows = memberships
      .filter((membership) => membership.active)
      .map((membership) => {
        const profile = profileById.get(membership.userId);
        const project = projectById.get(membership.projectId);
        return {
          email: profile?.email || "",
          display_name: profile?.displayName || membership.userId,
          project_code: project?.projectCode || membership.projectId,
          project_name: project?.projectName || ""
        };
      })
      .sort((a, b) =>
        `${a.display_name} ${a.project_code}`.localeCompare(`${b.display_name} ${b.project_code}`)
      );
    downloadRowsXlsx({
      rows,
      headers: USER_PROJECT_EXPORT_HEADERS,
      sheetName: "User projects",
      fileName: `${timestampForFile()}-user-project-memberships.xlsx`
    });
  }

  function canImport(issues: { severity: string }[]): boolean {
    return !issues.some((issue) => issue.severity === "error");
  }

  function confirmImport(label: string, preview: ChangePreview, deleteMissing = false): boolean {
    const summary = preview.lines.map((line) => `${line.label}: ${line.value}`).join("\n");
    const deleteMessage = deleteMissing ? "\n\nDatabase records omitted from this spreadsheet will be deleted." : "";
    return window.confirm(
      `Import ${label}?\n\n${summary}\n\nSpreadsheet values will supersede matching database records.${deleteMessage}\n\nThis will not create duplicate records for the same stable keys.`
    );
  }

  async function importItems() {
    if (!itemsImport || !itemPreview || !canImport(itemsImport.issues)) return;
    if (!confirmImport("items list", itemPreview, true)) return;
    try {
      const existingItems = new Map(items.map((item) => [item.id, item]));
      const existingCosts = new Map(itemCosts.map((cost) => [cost.itemId, cost]));
      const uploadedItemIds = new Set<string>();
      const writes: BatchWrite[] = [];
      itemsImport.rows.forEach((row) => {
        if (!row.databaseCode || !row.item) return;
        const itemId = itemIdFromDatabaseCode(row.databaseCode);
        uploadedItemIds.add(itemId);
        const existingItem = existingItems.get(itemId);
        const existingCost = existingCosts.get(itemId);
        writes.push((batch) => batch.set(
          itemDoc(itemId),
          {
            databaseCode: row.databaseCode,
            itemCode: row.itemCode,
            itemType: row.itemType,
            item: row.item,
            unitOfMeasure: row.unitOfMeasure,
            active: row.active,
            createdAt: existingItem?.createdAt ?? serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        ));
        writes.push((batch) => batch.set(
          itemCostDoc(itemId),
          {
            itemId,
            databaseCode: row.databaseCode,
            itemCode: row.itemCode,
            itemType: row.itemType,
            itemName: row.item,
            costEach: row.costEach,
            costBox: row.costBox,
            cost: deleteField(),
            createdAt: existingCost?.createdAt ?? serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        ));
      });
      items.forEach((item) => {
        if (uploadedItemIds.has(item.id)) return;
        writes.push((batch) => batch.delete(itemDoc(item.id)));
        const costIds = new Set<string>([item.id]);
        const existingCost = itemCostForItem(item, itemCosts);
        if (existingCost) costIds.add(existingCost.id);
        costIds.forEach((costId) => writes.push((batch) => batch.delete(itemCostDoc(costId))));
      });
      await commitBatchWrites(itemsCollection.firestore, writes);
      await addDoc(auditLogCollection, {
        actorUserId: actorId,
        action: "import_items",
        entityType: "items",
        entityId: "items_20260605",
        beforeJson: null,
        afterJson: {
          rowCount: itemsImport.rows.length,
          issueCount: itemsImport.issues.length,
          costEachCount: itemsImport.rows.filter((row) => row.costEach !== null).length,
          costBoxCount: itemsImport.rows.filter((row) => row.costBox !== null).length,
          deletedCount: itemPreview.lines.find((line) => line.label === "Deleted records")?.value ?? 0,
          preview: itemPreview.lines
        },
        reason: "Admin-approved spreadsheet import",
        createdAt: serverTimestamp()
      });
      onMessage("Items imported.");
      await onRefresh();
    } catch {
      onError("Could not import items.");
    }
  }

  async function importBillingAddresses() {
    if (!billingAddressesImport || !billingPreview || !canImport(billingAddressesImport.issues)) return;
    if (!confirmImport("invoice addresses", billingPreview, true)) return;
    try {
      const existingAddresses = new Map(billingAddresses.map((entry) => [entry.id, entry]));
      const uploadedAddressIds = new Set<string>();
      const writes: BatchWrite[] = [];
      billingAddressesImport.rows.forEach((row) => {
        if (!row.displayName || !row.address) return;
        uploadedAddressIds.add(row.id);
        const existing = existingAddresses.get(row.id);
        writes.push((batch) => batch.set(
          billingAddressDoc(row.id),
          {
            displayName: row.displayName,
            address: row.address,
            projectCodes: row.projectCodes,
            createdAt: existing?.createdAt ?? serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        ));
      });
      billingAddresses.forEach((entry) => {
        if (!uploadedAddressIds.has(entry.id)) {
          writes.push((batch) => batch.delete(billingAddressDoc(entry.id)));
        }
      });
      await commitBatchWrites(billingAddressesCollection.firestore, writes);
      await addDoc(auditLogCollection, {
        actorUserId: actorId,
        action: "import_billing_addresses",
        entityType: "billingAddresses",
        entityId: "bulk-import",
        beforeJson: null,
        afterJson: {
          rowCount: billingAddressesImport.rows.length,
          issueCount: billingAddressesImport.issues.length,
          deletedCount: billingPreview.lines.find((line) => line.label === "Deleted records")?.value ?? 0,
          preview: billingPreview.lines
        },
        reason: "Admin-approved spreadsheet import",
        createdAt: serverTimestamp()
      });
      onMessage("Invoice addresses imported.");
      await onRefresh();
    } catch {
      onError("Could not import invoice addresses.");
    }
  }

  async function importProjectUsers() {
    if (!projectUsersImport || !membershipPlan || !membershipPreview || !canImport(projectUsersImport.issues)) return;
    if (!confirmImport("user project memberships", membershipPreview)) return;
    try {
      const batch = writeBatch(projectsCollection.firestore);
      const existingProjects = new Map(projects.map((project) => [project.id, project]));
      const existingMemberships = new Map(memberships.map((membership) => [`${membership.userId}:${membership.projectId}`, membership]));

      membershipPlan.projects.forEach((project) => {
        const existing = existingProjects.get(project.id);
        batch.set(
          projectDoc(project.id),
          {
            projectCode: project.projectCode,
            projectName: project.projectName,
            active: true,
            createdAt: existing?.createdAt ?? serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      });

      membershipPlan.users.forEach((entry) => {
        entry.projectIds.forEach((projectId) => {
          const existing = existingMemberships.get(`${entry.userId}:${projectId}`);
          batch.set(
            membershipDoc(entry.userId, projectId),
            {
              userId: entry.userId,
              projectId,
              active: true,
              createdAt: existing?.createdAt ?? serverTimestamp(),
              updatedAt: serverTimestamp(),
              updatedBy: actorId
            },
            { merge: true }
          );
        });
        memberships
          .filter((membership) => membership.userId === entry.userId && membership.active && !entry.projectIds.includes(membership.projectId))
          .forEach((membership) => {
            batch.set(
              membershipDoc(membership.userId, membership.projectId),
              {
                userId: membership.userId,
                projectId: membership.projectId,
                active: false,
                createdAt: membership.createdAt ?? serverTimestamp(),
                updatedAt: serverTimestamp(),
                updatedBy: actorId
              },
              { merge: true }
            );
          });
      });

      await batch.commit();
      await addDoc(auditLogCollection, {
        actorUserId: actorId,
        action: "import_project_users",
        entityType: "projectMemberships",
        entityId: "projects-users_20260603",
        beforeJson: null,
        afterJson: {
          projectCount: membershipPlan.projects.length,
          affectedUsers: membershipPlan.users.length,
          unmatchedUsers: membershipPlan.unmatchedUsers,
          preview: membershipPreview.lines
        },
        reason: "Admin-approved spreadsheet import",
        createdAt: serverTimestamp()
      });
      onMessage(`User project memberships imported for ${membershipPlan.users.length} user${membershipPlan.users.length === 1 ? "" : "s"}.`);
      await onRefresh();
    } catch {
      onError("Could not import project/user data.");
    }
  }

  return (
    <div className="admin-grid">
      <section className="panel form-stack full-width-panel">
        <h2>Bulk import/export</h2>
        <p className="helper-text">
          Download the latest database data, edit the spreadsheet, then upload the same format to bulk add or update records.
          Imports use stable keys: item database_code, invoice address Display_name, and user email/display name plus project_code.
          Matching records are overwritten with the spreadsheet values; records omitted from item and invoice address uploads are deleted after confirmation.
          Membership uploads replace project memberships for users included in the file.
        </p>
      </section>

      <section className="panel form-stack">
        <h2>Download spreadsheets</h2>
        <p className="helper-text">Exports are generated from the current Firebase data and named with the Sydney timestamp.</p>
        <button type="button" onClick={downloadItemsExport}>
          <FileDown size={18} aria-hidden="true" />
          Download items list
        </button>
        <button type="button" onClick={downloadBillingAddressesExport}>
          <FileDown size={18} aria-hidden="true" />
          Download invoice addresses
        </button>
        <button type="button" onClick={downloadUserProjectsExport}>
          <FileDown size={18} aria-hidden="true" />
          Download user project memberships
        </button>
      </section>

      <section className="panel form-stack">
        <h2>Upload items list</h2>
        <p className="helper-text">Expected columns: database_code, item_code, item_type, item, unit_of_measure, active, cost_each, cost_box.</p>
        <input type="file" accept=".xlsx" onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void parseItemsFile(file).then(setItemsImport).catch(() => onError("Could not read item spreadsheet."));
        }} />
        {itemsImport ? (
          <>
            <ImportSummary issues={itemsImport.issues} rowCount={itemsImport.rows.length} />
            {itemPreview ? <ChangePreviewSummary preview={itemPreview} /> : null}
            <button type="button" disabled={!canImport(itemsImport.issues)} onClick={() => void importItems()}>
              <FileUp size={18} aria-hidden="true" />
              Import items
            </button>
          </>
        ) : null}
      </section>

      <section className="panel form-stack">
        <h2>Upload invoice addresses</h2>
        <p className="helper-text">Expected columns: Display_name, Address, Project_codes.</p>
        <input type="file" accept=".xlsx" onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void parseBillingAddressesFile(file).then(setBillingAddressesImport).catch(() => onError("Could not read invoice address spreadsheet."));
        }} />
        {billingAddressesImport ? (
          <>
            <ImportSummary issues={billingAddressesImport.issues} rowCount={billingAddressesImport.rows.length} />
            {billingPreview ? <ChangePreviewSummary preview={billingPreview} /> : null}
            <button type="button" disabled={!canImport(billingAddressesImport.issues)} onClick={() => void importBillingAddresses()}>
              <FileUp size={18} aria-hidden="true" />
              Import invoice addresses
            </button>
          </>
        ) : null}
      </section>

      <section className="panel form-stack">
        <h2>Upload user project memberships</h2>
        <p className="helper-text">
          Expected columns: email, display_name, project_code, project_name. Users must already exist; missing projects are created.
          For every user included in the file, the uploaded project list replaces their existing memberships.
        </p>
        <input type="file" accept=".xlsx" onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void parseProjectUsersFile(file).then(setProjectUsersImport).catch(() => onError("Could not read project/user spreadsheet."));
        }} />
        {projectUsersImport ? (
          <>
            <ImportSummary issues={projectUsersImport.issues} rowCount={projectUsersImport.rows.length} />
            {membershipPreview ? <ChangePreviewSummary preview={membershipPreview} /> : null}
            <button type="button" disabled={!canImport(projectUsersImport.issues)} onClick={() => void importProjectUsers()}>
              <FileUp size={18} aria-hidden="true" />
              Import user memberships
            </button>
          </>
        ) : null}
      </section>
    </div>
  );
}

function timestampForFile(): string {
  const parts = new Intl.DateTimeFormat("en-AU", {
    timeZone: "Australia/Sydney",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    hourCycle: "h23"
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}${values.month}${values.day}-${values.hour}${values.minute}${values.second}`;
}

function itemCostForItem(item: Item, itemCosts: ItemCost[]): ItemCost | undefined {
  return itemCosts.find((cost) => cost.itemId === item.id || cost.databaseCode === item.databaseCode);
}

function buildItemsPreview(
  parsed: ParsedItemsImport,
  items: Item[],
  itemCosts: ItemCost[]
): ChangePreview {
  const itemById = new Map(items.map((item) => [item.id, item]));
  const costByItemId = new Map(itemCosts.map((cost) => [cost.itemId, cost]));
  const uploadedItemIds = new Set<string>();
  let newCount = 0;
  let changedCount = 0;
  let unchangedCount = 0;
  let skippedCount = 0;
  const details: string[] = [];

  parsed.rows.forEach((row) => {
    if (!row.databaseCode || !row.item) {
      skippedCount += 1;
      return;
    }
    const itemId = itemIdFromDatabaseCode(row.databaseCode);
    uploadedItemIds.add(itemId);
    const existing = itemById.get(itemId);
    const existingCost = costByItemId.get(itemId);
    if (!existing) {
      newCount += 1;
      if (details.length < 10) details.push(`New item ${row.databaseCode}: ${row.item}`);
      return;
    }
    const changed =
      existing.itemCode !== row.itemCode ||
      existing.itemType !== row.itemType ||
      existing.item !== row.item ||
      existing.unitOfMeasure !== row.unitOfMeasure ||
      existing.active !== row.active ||
      costEachForItem(existingCost) !== row.costEach ||
      costBoxForItem(existingCost) !== row.costBox;
    if (changed) {
      changedCount += 1;
      if (details.length < 10) details.push(`Update item ${row.databaseCode}: ${row.item}`);
    } else {
      unchangedCount += 1;
    }
  });

  const deletedItems = items.filter((item) => !uploadedItemIds.has(item.id));
  deletedItems.forEach((item) => {
    if (details.length < 10) details.push(`Delete item ${item.databaseCode}: ${item.item}`);
  });

  return {
    lines: [
      { label: "Rows", value: parsed.rows.length },
      { label: "New records", value: newCount },
      { label: "Changed records", value: changedCount },
      { label: "Unchanged records", value: unchangedCount },
      { label: "Deleted records", value: deletedItems.length },
      { label: "Skipped invalid rows", value: skippedCount }
    ],
    details
  };
}

function buildBillingAddressesPreview(
  parsed: ParsedBillingAddressesImport,
  billingAddresses: BillingAddress[]
): ChangePreview {
  const addressById = new Map(billingAddresses.map((entry) => [entry.id, entry]));
  const uploadedAddressIds = new Set<string>();
  let newCount = 0;
  let changedCount = 0;
  let unchangedCount = 0;
  let skippedCount = 0;
  const details: string[] = [];

  parsed.rows.forEach((row) => {
    if (!row.displayName || !row.address) {
      skippedCount += 1;
      return;
    }
    uploadedAddressIds.add(row.id);
    const existing = addressById.get(row.id);
    if (!existing) {
      newCount += 1;
      if (details.length < 10) details.push(`New address: ${row.displayName}`);
      return;
    }
    const changed =
      existing.displayName !== row.displayName ||
      existing.address !== row.address ||
      existing.projectCodes !== row.projectCodes;
    if (changed) {
      changedCount += 1;
      if (details.length < 10) details.push(`Update address: ${row.displayName}`);
    } else {
      unchangedCount += 1;
    }
  });

  const deletedAddresses = billingAddresses.filter((entry) => !uploadedAddressIds.has(entry.id));
  deletedAddresses.forEach((entry) => {
    if (details.length < 10) details.push(`Delete address: ${entry.displayName}`);
  });

  return {
    lines: [
      { label: "Rows", value: parsed.rows.length },
      { label: "New records", value: newCount },
      { label: "Changed records", value: changedCount },
      { label: "Unchanged records", value: unchangedCount },
      { label: "Deleted records", value: deletedAddresses.length },
      { label: "Skipped invalid rows", value: skippedCount }
    ],
    details
  };
}

type MembershipImportPlan = {
  users: Array<{ userId: string; projectIds: string[] }>;
  projects: Array<{ id: string; projectCode: string; projectName: string }>;
  unmatchedUsers: string[];
  preview: ChangePreview;
};

function buildMembershipImportPlan(
  parsed: ParsedProjectUsersImport,
  profiles: Profile[],
  projects: Project[],
  memberships: ProjectMembership[]
): MembershipImportPlan {
  const profileByEmail = new Map(profiles.map((profile) => [profile.email.trim().toLowerCase(), profile]));
  const profileByName = new Map(profiles.map((profile) => [profile.displayName.trim().toLowerCase(), profile]));
  const projectById = new Map(projects.map((project) => [project.id, project]));
  const desiredByUser = new Map<string, { profile: Profile; projectIds: Set<string> }>();
  const desiredProjects = new Map<string, { id: string; projectCode: string; projectName: string }>();
  const unmatchedUsers = new Set<string>();
  let skippedCount = 0;

  parsed.rows.forEach((row) => {
    if (!row.projectCode || (!row.email && !row.displayName)) {
      skippedCount += 1;
      return;
    }
    const profile = row.email
      ? profileByEmail.get(row.email.trim().toLowerCase())
      : profileByName.get(row.displayName.trim().toLowerCase());
    if (!profile) {
      unmatchedUsers.add(row.email || row.displayName);
      return;
    }

    const projectId = projectIdFromCode(row.projectCode);
    const existingProject = projectById.get(projectId);
    const projectName = row.projectName || existingProject?.projectName || row.projectCode;
    desiredProjects.set(projectId, { id: projectId, projectCode: row.projectCode, projectName });
    const userEntry = desiredByUser.get(profile.id) ?? { profile, projectIds: new Set<string>() };
    userEntry.projectIds.add(projectId);
    desiredByUser.set(profile.id, userEntry);
  });

  const membershipByKey = new Map(memberships.map((membership) => [`${membership.userId}:${membership.projectId}`, membership]));
  let projectNewCount = 0;
  let projectChangedCount = 0;
  let membershipActivateCount = 0;
  let membershipDeactivateCount = 0;
  let membershipUnchangedCount = 0;
  const details: string[] = [];

  desiredProjects.forEach((project) => {
    const existing = projectById.get(project.id);
    if (!existing) {
      projectNewCount += 1;
      if (details.length < 10) details.push(`Create project ${project.projectCode}`);
      return;
    }
    if (existing.projectCode !== project.projectCode || existing.projectName !== project.projectName || !existing.active) {
      projectChangedCount += 1;
      if (details.length < 10) details.push(`Update project ${project.projectCode}`);
    }
  });

  desiredByUser.forEach((entry) => {
    const desiredIds = [...entry.projectIds];
    desiredIds.forEach((projectId) => {
      const existing = membershipByKey.get(`${entry.profile.id}:${projectId}`);
      if (!existing || !existing.active) {
        membershipActivateCount += 1;
        if (details.length < 10) details.push(`Add membership: ${entry.profile.displayName} -> ${projectById.get(projectId)?.projectCode || projectId}`);
      } else {
        membershipUnchangedCount += 1;
      }
    });
    memberships
      .filter((membership) => membership.userId === entry.profile.id && membership.active && !entry.projectIds.has(membership.projectId))
      .forEach((membership) => {
        membershipDeactivateCount += 1;
        if (details.length < 10) {
          details.push(`Remove membership: ${entry.profile.displayName} -> ${projectById.get(membership.projectId)?.projectCode || membership.projectId}`);
        }
      });
  });

  return {
    users: [...desiredByUser.entries()].map(([userId, entry]) => ({ userId, projectIds: [...entry.projectIds] })),
    projects: [...desiredProjects.values()],
    unmatchedUsers: [...unmatchedUsers],
    preview: {
      lines: [
        { label: "Rows", value: parsed.rows.length },
        { label: "Affected users", value: desiredByUser.size },
        { label: "New projects", value: projectNewCount },
        { label: "Changed projects", value: projectChangedCount },
        { label: "Memberships added/reactivated", value: membershipActivateCount },
        { label: "Memberships removed", value: membershipDeactivateCount },
        { label: "Memberships unchanged", value: membershipUnchangedCount },
        { label: "Unmatched users not imported", value: unmatchedUsers.size },
        { label: "Skipped invalid rows", value: skippedCount }
      ],
      details: [
        ...details,
        ...[...unmatchedUsers].slice(0, 5).map((user) => `Unmatched user: ${user}`)
      ].slice(0, 12)
    }
  };
}

function ChangePreviewSummary({ preview }: { preview: ChangePreview }): JSX.Element {
  return (
    <div className="import-summary">
      <p>Change preview</p>
      <ul>
        {preview.lines.map((line) => (
          <li key={line.label}>{line.label}: {line.value}</li>
        ))}
      </ul>
      {preview.details.length > 0 ? (
        <ul className="preview-details">
          {preview.details.map((detail, index) => <li key={`${detail}-${index}`}>{detail}</li>)}
        </ul>
      ) : null}
    </div>
  );
}

function ProjectCheckboxes({
  projects,
  selected,
  onToggle
}: {
  projects: Project[];
  selected: string[];
  onToggle: (projectId: string) => void;
}): JSX.Element {
  return (
    <fieldset className="checkbox-grid">
      <legend>Projects</legend>
      {projects.map((project) => (
        <label key={project.id}>
          <input
            type="checkbox"
            checked={selected.includes(project.id)}
            onChange={() => onToggle(project.id)}
          />
          <span>{project.projectCode}</span>
        </label>
      ))}
    </fieldset>
  );
}

function EntityTable({
  title,
  rows
}: {
  title: string;
  rows: Array<{
    id: string;
    primary: string;
    secondary: string;
    active: boolean;
    onEdit?: () => void;
    onToggle: () => void;
    onDelete: () => void;
  }>;
}): JSX.Element {
  return (
    <section className={title ? "panel" : ""}>
      {title ? <h2>{title}</h2> : null}
      <div className="table-shell compact-table">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Active</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td data-label="Name">
                  <span>{row.primary}</span>
                  <small>{row.secondary}</small>
                </td>
                <td data-label="Active">{row.active ? "yes" : "no"}</td>
                <td data-label="Actions" className="action-cell">
                  {row.onEdit ? (
                    <button className="secondary" type="button" onClick={row.onEdit}>
                      <Pencil size={16} aria-hidden="true" />
                      Edit
                    </button>
                  ) : null}
                  <button className="secondary" type="button" onClick={row.onToggle}>
                    {row.active ? "Deactivate" : "Activate"}
                  </button>
                  <button className="danger" type="button" onClick={row.onDelete}>
                    <Trash2 size={16} aria-hidden="true" />
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function ImportSummary({ issues, rowCount }: { issues: { severity: string; message: string; row?: number; field?: string }[]; rowCount: number }): JSX.Element {
  const errors = issues.filter((issue) => issue.severity === "error").length;
  const warnings = issues.length - errors;
  return (
    <div className="import-summary">
      <p>{rowCount} rows, {errors} errors, {warnings} warnings.</p>
      <ul>
        {issues.slice(0, 12).map((issue, index) => (
          <li key={`${issue.row}-${issue.field}-${index}`}>
            {issue.row ? `Row ${issue.row}: ` : ""}{issue.message}
          </li>
        ))}
      </ul>
    </div>
  );
}
