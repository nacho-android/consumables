import {
  addDoc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch
} from "firebase/firestore";
import { EmailAuthProvider, reauthenticateWithCredential, type User } from "firebase/auth";
import { httpsCallable } from "firebase/functions";
import {
  FileUp,
  KeyRound,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  Trash2,
  UserPlus
} from "lucide-react";
import { useEffect, useState } from "react";
import { Message } from "../components/Message";
import { useAuth } from "../hooks/useAuth";
import {
  auditLogCollection,
  itemDoc,
  itemsCollection,
  membershipDoc,
  membershipsCollection,
  profilesCollection,
  projectDoc,
  projectsCollection,
  transactionsCollection
} from "../lib/collections";
import { functions } from "../lib/firebase";
import {
  itemIdFromDatabaseCode,
  parseItemsFile,
  parseProjectUsersFile,
  projectIdFromCode,
  type ParsedItemsImport,
  type ParsedProjectUsersImport
} from "../lib/importers";
import { formatDate, formatDateTime } from "../lib/date";
import type {
  AcquisitionTransaction,
  Item,
  Profile,
  Project,
  ProjectMembership,
  Role
} from "../types";

type AdminTab = "users" | "projects" | "items" | "data" | "import";

const createUser = httpsCallable(functions, "adminCreateUser");
const updateUser = httpsCallable(functions, "adminUpdateUser");
const resetPassword = httpsCallable(functions, "adminTriggerPasswordReset");
const deleteOrDeactivateUser = httpsCallable(functions, "adminDeleteOrDeactivateUser");
const voidTransaction = httpsCallable(functions, "voidTransaction");
const correctTransaction = httpsCallable(functions, "correctTransaction");
const purgeTransactions = httpsCallable(functions, "adminPurgeTransactions");
const deleteOrDeactivateProject = httpsCallable(functions, "adminDeleteOrDeactivateProject");
const deleteOrDeactivateItem = httpsCallable(functions, "adminDeleteOrDeactivateItem");

export function AdminPage(): JSX.Element {
  const { user } = useAuth();
  const [tab, setTab] = useState<AdminTab>("users");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [memberships, setMemberships] = useState<ProjectMembership[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [transactions, setTransactions] = useState<AcquisitionTransaction[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function refreshAll() {
    setBusy(true);
    setError(null);
    try {
      const [profileSnap, projectSnap, membershipSnap, itemSnap] = await Promise.all([
        getDocs(query(profilesCollection, orderBy("displayName"))),
        getDocs(query(projectsCollection, orderBy("projectCode"))),
        getDocs(query(membershipsCollection, orderBy("projectId"))),
        getDocs(query(itemsCollection, orderBy("item")))
      ]);
      setProfiles(profileSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Profile)));
      setProjects(projectSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Project)));
      setMemberships(membershipSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as ProjectMembership)));
      setItems(itemSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Item)));
    } catch {
      setError("Could not load admin data.");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    void refreshAll();
  }, []);

  async function loadTransactions() {
    const snapshot = await getDocs(query(transactionsCollection, orderBy("transactionDate", "desc"), orderBy("submittedAt", "desc")));
    setTransactions(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as AcquisitionTransaction)).slice(0, 250));
  }

  return (
    <section className="admin-layout">
      <div className="toolbar">
        <div className="segmented" aria-label="Admin section">
          {(["users", "projects", "items", "data", "import"] as AdminTab[]).map((nextTab) => (
            <button key={nextTab} type="button" className={tab === nextTab ? "active" : ""} onClick={() => setTab(nextTab)}>
              {nextTab}
            </button>
          ))}
        </div>
        <button className="secondary" type="button" disabled={busy} onClick={() => void refreshAll()}>
          <RefreshCw size={18} aria-hidden="true" />
          Refresh
        </button>
      </div>

      {message ? <Message kind="success">{message}</Message> : null}
      {error ? <Message kind="error">{error}</Message> : null}

      {tab === "users" ? (
        <UsersAdmin
          profiles={profiles}
          projects={projects}
          memberships={memberships}
          actorId={user!.uid}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
      {tab === "projects" ? (
        <ProjectsAdmin projects={projects} actorId={user!.uid} onMessage={setMessage} onError={setError} onRefresh={refreshAll} />
      ) : null}
      {tab === "items" ? (
        <ItemsAdmin items={items} actorId={user!.uid} onMessage={setMessage} onError={setError} onRefresh={refreshAll} />
      ) : null}
      {tab === "data" ? (
        <DataAdmin
          currentUser={user!}
          transactions={transactions}
          projects={projects}
          items={items}
          onLoad={loadTransactions}
          onMessage={setMessage}
          onError={setError}
        />
      ) : null}
      {tab === "import" ? (
        <ImportAdmin
          actorId={user!.uid}
          profiles={profiles}
          projects={projects}
          onMessage={setMessage}
          onError={setError}
          onRefresh={refreshAll}
        />
      ) : null}
    </section>
  );
}

type AdminChildProps = {
  onMessage: (message: string | null) => void;
  onError: (message: string | null) => void;
  onRefresh: () => Promise<void>;
};

function UsersAdmin({
  profiles,
  projects,
  memberships,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & {
  profiles: Profile[];
  projects: Project[];
  memberships: ProjectMembership[];
  actorId: string;
}): JSX.Element {
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<Role>("standard");
  const [newProjectIds, setNewProjectIds] = useState<string[]>([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [editProjectIds, setEditProjectIds] = useState<string[]>([]);
  const [resetLink, setResetLink] = useState("");

  async function submitCreate(event: React.FormEvent) {
    event.preventDefault();
    onError(null);
    onMessage(null);
    try {
      const result = await createUser({ email, displayName, role, projectIds: newProjectIds });
      const link = (result.data as { resetLink?: string }).resetLink || "";
      setResetLink(link);
      setEmail("");
      setDisplayName("");
      setNewProjectIds([]);
      onMessage("User created. Share the reset link through a trusted channel.");
      await onRefresh();
    } catch {
      onError("Could not create the user.");
    }
  }

  async function toggleActive(profile: Profile) {
    try {
      await updateUser({ uid: profile.id, active: !profile.active });
      onMessage(profile.active ? "User deactivated." : "User activated.");
      await onRefresh();
    } catch {
      onError("Could not update user status.");
    }
  }

  async function sendReset(profile: Profile) {
    try {
      const result = await resetPassword({ email: profile.email });
      setResetLink((result.data as { resetLink?: string }).resetLink || "");
      onMessage("Password reset link generated.");
    } catch {
      onError("Could not generate password reset link.");
    }
  }

  async function removeUser(profile: Profile) {
    if (!window.confirm(`Delete ${profile.displayName} if safe, otherwise deactivate?`)) return;
    try {
      const result = await deleteOrDeactivateUser({ uid: profile.id });
      onMessage(`User ${(result.data as { action: string }).action}.`);
      await onRefresh();
    } catch {
      onError("Could not delete or deactivate user.");
    }
  }

  async function saveMemberships() {
    const target = profiles.find((profile) => profile.id === selectedUserId);
    if (!target) return;
    try {
      await updateUser({ uid: target.id, projectIds: editProjectIds });
      onMessage("Project memberships saved.");
      await onRefresh();
    } catch {
      onError("Could not save memberships.");
    }
  }

  function toggleNewProject(projectId: string) {
    setNewProjectIds((current) =>
      current.includes(projectId)
        ? current.filter((id) => id !== projectId)
        : [...current, projectId]
    );
  }

  function toggleEditProject(projectId: string) {
    setEditProjectIds((current) =>
      current.includes(projectId)
        ? current.filter((id) => id !== projectId)
        : [...current, projectId]
    );
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void submitCreate(event)}>
        <h2>Add user</h2>
        <label htmlFor="new-user-email">Email</label>
        <input id="new-user-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
        <label htmlFor="new-user-name">Display name</label>
        <input id="new-user-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} required />
        <label htmlFor="new-user-role">Role</label>
        <select id="new-user-role" value={role} onChange={(event) => setRole(event.target.value as Role)}>
          <option value="standard">standard</option>
          <option value="admin">admin</option>
        </select>
        <ProjectCheckboxes projects={projects.filter((project) => project.active)} selected={newProjectIds} onToggle={toggleNewProject} />
        <button type="submit">
          <UserPlus size={18} aria-hidden="true" />
          Add user
        </button>
        {resetLink ? <textarea readOnly rows={3} value={resetLink} aria-label="Password reset link" /> : null}
      </form>

      <section className="panel">
        <h2>Users</h2>
        <div className="table-shell compact-table">
          <table>
            <thead>
              <tr>
                <th>User</th>
                <th>Role</th>
                <th>Active</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {profiles.map((profile) => (
                <tr key={profile.id}>
                  <td data-label="User">
                    <span>{profile.displayName}</span>
                    <small>{profile.email}</small>
                  </td>
                  <td data-label="Role">{profile.role}</td>
                  <td data-label="Active">{profile.active ? "yes" : "no"}</td>
                  <td data-label="Actions" className="action-cell">
                    <button className="secondary" type="button" onClick={() => void toggleActive(profile)}>
                      <ShieldAlert size={16} aria-hidden="true" />
                      {profile.active ? "Deactivate" : "Activate"}
                    </button>
                    <button className="secondary" type="button" onClick={() => void sendReset(profile)}>
                      <KeyRound size={16} aria-hidden="true" />
                      Reset
                    </button>
                    <button className="danger" type="button" disabled={profile.id === actorId} onClick={() => void removeUser(profile)}>
                      <Trash2 size={16} aria-hidden="true" />
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="panel form-stack">
        <h2>Memberships</h2>
        <label htmlFor="membership-user">User</label>
        <select
          id="membership-user"
          value={selectedUserId}
          onChange={(event) => {
            const uid = event.target.value;
            setSelectedUserId(uid);
            setEditProjectIds([...memberships.filter((membership) => membership.userId === uid && membership.active).map((membership) => membership.projectId)]);
          }}
        >
          <option value="">Select user</option>
          {profiles.map((profile) => (
            <option key={profile.id} value={profile.id}>{profile.displayName}</option>
          ))}
        </select>
        {selectedUserId ? (
          <>
            <ProjectCheckboxes
              projects={projects}
              selected={editProjectIds}
              onToggle={toggleEditProject}
            />
            <button type="button" onClick={() => void saveMemberships()}>
              <Pencil size={18} aria-hidden="true" />
              Save memberships
            </button>
          </>
        ) : null}
      </section>
    </div>
  );
}

function ProjectsAdmin({
  projects,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & { projects: Project[]; actorId: string }): JSX.Element {
  const [projectCode, setProjectCode] = useState("");
  const [projectName, setProjectName] = useState("");
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);

  async function saveProject(event: React.FormEvent) {
    event.preventDefault();
    const trimmedCode = projectCode.trim();
    const trimmedName = projectName.trim() || trimmedCode;
    if (!trimmedCode) {
      onError("Project code is required.");
      return;
    }
    const duplicate = projects.find(
      (project) =>
        project.id !== editingProjectId &&
        project.projectCode.trim().toLowerCase() === trimmedCode.toLowerCase()
    );
    if (duplicate) {
      onError("Another project already uses that code.");
      return;
    }
    try {
      if (editingProjectId) {
        await updateDoc(projectDoc(editingProjectId), {
          projectCode: trimmedCode,
          projectName: trimmedName,
          updatedAt: serverTimestamp(),
          updatedBy: actorId
        });
      } else {
        await setDoc(
          projectDoc(projectIdFromCode(trimmedCode)),
          {
            projectCode: trimmedCode,
            projectName: trimmedName,
            active: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      }
      setProjectCode("");
      setProjectName("");
      setEditingProjectId(null);
      onMessage("Project saved.");
      await onRefresh();
    } catch {
      onError("Could not save project.");
    }
  }

  async function toggleProject(project: Project) {
    try {
      await updateDoc(projectDoc(project.id), {
        active: !project.active,
        updatedAt: serverTimestamp(),
        updatedBy: actorId
      });
      onMessage(project.active ? "Project deactivated." : "Project activated.");
      await onRefresh();
    } catch {
      onError("Could not update project.");
    }
  }

  async function removeProject(project: Project) {
    if (!window.confirm(`Delete ${project.projectCode} if safe, otherwise deactivate?`)) return;
    try {
      const result = await deleteOrDeactivateProject({ projectId: project.id });
      onMessage(`Project ${(result.data as { action: string }).action}.`);
      await onRefresh();
    } catch {
      onError("Could not delete or deactivate project.");
    }
  }

  function editProject(project: Project) {
    setEditingProjectId(project.id);
    setProjectCode(project.projectCode);
    setProjectName(project.projectName);
    onError(null);
    onMessage(null);
  }

  function cancelEdit() {
    setEditingProjectId(null);
    setProjectCode("");
    setProjectName("");
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void saveProject(event)}>
        <h2>{editingProjectId ? "Edit project" : "Add project"}</h2>
        <label htmlFor="project-code">Project code</label>
        <input id="project-code" value={projectCode} onChange={(event) => setProjectCode(event.target.value)} required />
        <label htmlFor="project-name">Project name</label>
        <input id="project-name" value={projectName} onChange={(event) => setProjectName(event.target.value)} />
        <div className="button-row">
          <button type="submit">
            <Plus size={18} aria-hidden="true" />
            Save project
          </button>
          {editingProjectId ? (
            <button className="secondary" type="button" onClick={cancelEdit}>
              Cancel
            </button>
          ) : null}
        </div>
      </form>
      <EntityTable
        title="Projects"
        rows={projects.map((project) => ({
          id: project.id,
          primary: project.projectCode,
          secondary: project.projectName,
          active: project.active,
          onEdit: () => editProject(project),
          onToggle: () => void toggleProject(project),
          onDelete: () => void removeProject(project)
        }))}
      />
    </div>
  );
}

function ItemsAdmin({
  items,
  actorId,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & { items: Item[]; actorId: string }): JSX.Element {
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({
    databaseCode: "",
    itemCode: "",
    itemType: "",
    item: "",
    unitOfMeasure: ""
  });
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const filtered = items.filter((item) =>
    [item.item, item.databaseCode, item.itemCode, item.itemType].join(" ").toLowerCase().includes(search.toLowerCase())
  ).slice(0, 100);

  async function saveItem(event: React.FormEvent) {
    event.preventDefault();
    const trimmed = {
      databaseCode: form.databaseCode.trim(),
      itemCode: form.itemCode.trim(),
      itemType: form.itemType.trim(),
      item: form.item.trim(),
      unitOfMeasure: form.unitOfMeasure.trim()
    };
    if (!trimmed.databaseCode || !trimmed.item) {
      onError("Database code and item name are required.");
      return;
    }
    const duplicate = items.find(
      (item) =>
        item.id !== editingItemId &&
        item.databaseCode.trim().toLowerCase() === trimmed.databaseCode.toLowerCase()
    );
    if (duplicate) {
      onError("Another item already uses that database code.");
      return;
    }
    try {
      if (editingItemId) {
        await updateDoc(itemDoc(editingItemId), {
          ...trimmed,
          updatedAt: serverTimestamp(),
          updatedBy: actorId
        });
      } else {
        await setDoc(
          itemDoc(itemIdFromDatabaseCode(trimmed.databaseCode)),
          {
            ...trimmed,
            active: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      }
      setForm({ databaseCode: "", itemCode: "", itemType: "", item: "", unitOfMeasure: "" });
      setEditingItemId(null);
      onMessage("Item saved.");
      await onRefresh();
    } catch {
      onError("Could not save item.");
    }
  }

  async function toggleItem(item: Item) {
    try {
      await updateDoc(itemDoc(item.id), {
        active: !item.active,
        updatedAt: serverTimestamp(),
        updatedBy: actorId
      });
      onMessage(item.active ? "Item deactivated." : "Item activated.");
      await onRefresh();
    } catch {
      onError("Could not update item.");
    }
  }

  async function removeItem(item: Item) {
    if (!window.confirm(`Delete ${item.item} if safe, otherwise deactivate?`)) return;
    try {
      const result = await deleteOrDeactivateItem({ itemId: item.id });
      onMessage(`Item ${(result.data as { action: string }).action}.`);
      await onRefresh();
    } catch {
      onError("Could not delete or deactivate item.");
    }
  }

  function editItem(item: Item) {
    setEditingItemId(item.id);
    setForm({
      databaseCode: item.databaseCode,
      itemCode: item.itemCode,
      itemType: item.itemType,
      item: item.item,
      unitOfMeasure: item.unitOfMeasure
    });
    onError(null);
    onMessage(null);
  }

  function cancelEdit() {
    setEditingItemId(null);
    setForm({ databaseCode: "", itemCode: "", itemType: "", item: "", unitOfMeasure: "" });
  }

  return (
    <div className="admin-grid">
      <form className="panel form-stack" onSubmit={(event) => void saveItem(event)}>
        <h2>{editingItemId ? "Edit item" : "Add item"}</h2>
        {(["databaseCode", "itemCode", "itemType", "item", "unitOfMeasure"] as const).map((field) => (
          <div className="form-stack compact" key={field}>
            <label htmlFor={field}>{field}</label>
            <input
              id={field}
              value={form[field]}
              required={field === "databaseCode" || field === "item"}
              onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))}
            />
          </div>
        ))}
        <button type="submit">
          <Plus size={18} aria-hidden="true" />
          Save item
        </button>
        {editingItemId ? (
          <button className="secondary" type="button" onClick={cancelEdit}>
            Cancel
          </button>
        ) : null}
      </form>
      <section className="panel">
        <h2>Items</h2>
        <div className="field-row">
          <Search size={18} aria-hidden="true" />
          <input aria-label="Search items" value={search} onChange={(event) => setSearch(event.target.value)} />
        </div>
        <EntityTable
          title=""
          rows={filtered.map((item) => ({
            id: item.id,
            primary: item.item,
            secondary: [item.itemType, item.databaseCode, item.itemCode, item.unitOfMeasure || "missing unit"].join(" | "),
            active: item.active,
            onEdit: () => editItem(item),
            onToggle: () => void toggleItem(item),
            onDelete: () => void removeItem(item)
          }))}
        />
      </section>
    </div>
  );
}

function DataAdmin({
  currentUser,
  transactions,
  projects,
  items,
  onLoad,
  onMessage,
  onError
}: {
  currentUser: User;
  transactions: AcquisitionTransaction[];
  projects: Project[];
  items: Item[];
  onLoad: () => Promise<void>;
  onMessage: (message: string | null) => void;
  onError: (message: string | null) => void;
}): JSX.Element {
  const [selected, setSelected] = useState<AcquisitionTransaction | null>(null);
  const [reason, setReason] = useState("");
  const [replacement, setReplacement] = useState({
    transactionDate: "",
    projectId: "",
    itemId: "",
    amount: "",
    unitOfMeasure: "",
    comments: ""
  });
  const [purgeScope, setPurgeScope] = useState<"range" | "all">("range");
  const [purgeProjectId, setPurgeProjectId] = useState("all");
  const [purgeStartDate, setPurgeStartDate] = useState("");
  const [purgeEndDate, setPurgeEndDate] = useState("");
  const [purgeConfirm, setPurgeConfirm] = useState("");
  const [purgePassword, setPurgePassword] = useState("");
  const [purgeBusy, setPurgeBusy] = useState(false);

  async function voidSelected(tx: AcquisitionTransaction) {
    const why = window.prompt("Reason for voiding this transaction");
    if (!why) return;
    try {
      await voidTransaction({ transactionId: tx.id, reason: why });
      onMessage("Transaction voided.");
      await onLoad();
    } catch {
      onError("Could not void transaction.");
    }
  }

  function startCorrection(tx: AcquisitionTransaction) {
    setSelected(tx);
    setReason("");
    setReplacement({
      transactionDate: tx.transactionDate,
      projectId: tx.projectId,
      itemId: tx.itemId,
      amount: String(tx.amount),
      unitOfMeasure: tx.unitOfMeasure,
      comments: tx.comments || ""
    });
  }

  async function submitCorrection(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) return;
    const project = projects.find((entry) => entry.id === replacement.projectId);
    const item = items.find((entry) => entry.id === replacement.itemId);
    if (!project || !item || !reason.trim()) {
      onError("Correction requires a reason, project, and item.");
      return;
    }
    try {
      await correctTransaction({
        transactionId: selected.id,
        reason,
        replacement: {
          transactionDate: replacement.transactionDate,
          projectId: project.id,
          itemId: item.id,
          amount: Number(replacement.amount),
          unitOfMeasure: replacement.unitOfMeasure,
          comments: replacement.comments,
          projectCode: project.projectCode,
          projectName: project.projectName,
          databaseCode: item.databaseCode,
          itemCode: item.itemCode,
          itemType: item.itemType,
          itemName: item.item
        }
      });
      setSelected(null);
      onMessage("Correction saved.");
      await onLoad();
    } catch {
      onError("Could not correct transaction.");
    }
  }

  async function submitPurge(event: React.FormEvent) {
    event.preventDefault();
    onError(null);
    onMessage(null);
    if (!currentUser.email) {
      onError("Your account needs an email address before purging transactions.");
      return;
    }
    if (purgeConfirm !== "DELETE") {
      onError("Type DELETE to confirm transaction purge.");
      return;
    }
    if (purgeScope === "range" && (!purgeStartDate || !purgeEndDate || purgeStartDate > purgeEndDate)) {
      onError("Choose a valid date range, or switch to all dates.");
      return;
    }

    setPurgeBusy(true);
    try {
      const credential = EmailAuthProvider.credential(currentUser.email, purgePassword);
      await reauthenticateWithCredential(currentUser, credential);
      await currentUser.getIdToken(true);
      const result = await purgeTransactions({
        projectId: purgeProjectId === "all" ? "" : purgeProjectId,
        startDate: purgeScope === "range" ? purgeStartDate : "",
        endDate: purgeScope === "range" ? purgeEndDate : "",
        confirm: purgeConfirm
      });
      const deletedCount = Number((result.data as { deletedCount?: unknown }).deletedCount ?? 0);
      setPurgeConfirm("");
      setPurgePassword("");
      onMessage(`Deleted ${deletedCount} transaction${deletedCount === 1 ? "" : "s"}.`);
      await onLoad();
    } catch {
      onError("Could not purge transactions. Check your password, filters, and admin access.");
      setPurgePassword("");
    } finally {
      setPurgeBusy(false);
    }
  }

  return (
    <div className="admin-grid">
      <section className="panel">
        <div className="form-header">
          <h2>Transactions</h2>
          <button className="secondary" type="button" onClick={() => void onLoad()}>
            <RefreshCw size={18} aria-hidden="true" />
            Load
          </button>
        </div>
        <div className="table-shell compact-table">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Project</th>
                <th>Item</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr key={tx.id}>
                  <td data-label="Date">
                    <span>{formatDate(tx.transactionDate)}</span>
                    <small>{formatDateTime(tx.submittedAt)}</small>
                  </td>
                  <td data-label="Project">{tx.projectCode}</td>
                  <td data-label="Item">{tx.itemName}</td>
                  <td data-label="Status"><span className={`status ${tx.status}`}>{tx.status}</span></td>
                  <td data-label="Actions" className="action-cell">
                    <button className="secondary" type="button" disabled={tx.status !== "active"} onClick={() => void voidSelected(tx)}>
                      Void
                    </button>
                    <button className="secondary" type="button" disabled={tx.status !== "active"} onClick={() => startCorrection(tx)}>
                      Correct
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <form className="panel form-stack" onSubmit={(event) => void submitPurge(event)}>
        <div className="form-header">
          <h2>Purge transactions</h2>
          <Trash2 size={20} aria-hidden="true" />
        </div>
        <Message kind="error">
          This permanently deletes matching transaction records. Export data first if you need a copy.
        </Message>

        <label htmlFor="purge-project">Project</label>
        <select id="purge-project" value={purgeProjectId} onChange={(event) => setPurgeProjectId(event.target.value)}>
          <option value="all">All projects</option>
          {projects.map((project) => (
            <option key={project.id} value={project.id}>
              {project.projectCode} {project.projectName}
            </option>
          ))}
        </select>

        <label htmlFor="purge-scope">Dates</label>
        <select id="purge-scope" value={purgeScope} onChange={(event) => setPurgeScope(event.target.value as "range" | "all")}>
          <option value="range">Selected date range</option>
          <option value="all">All dates</option>
        </select>

        {purgeScope === "range" ? (
          <div className="two-column">
            <div className="form-stack compact">
              <label htmlFor="purge-start">Start date</label>
              <input id="purge-start" type="date" value={purgeStartDate} onChange={(event) => setPurgeStartDate(event.target.value)} required />
            </div>
            <div className="form-stack compact">
              <label htmlFor="purge-end">End date</label>
              <input id="purge-end" type="date" value={purgeEndDate} onChange={(event) => setPurgeEndDate(event.target.value)} required />
            </div>
          </div>
        ) : null}

        <label htmlFor="purge-confirm">Type DELETE to confirm</label>
        <input
          id="purge-confirm"
          value={purgeConfirm}
          onChange={(event) => setPurgeConfirm(event.target.value)}
          autoComplete="off"
          required
        />

        <label htmlFor="purge-password">Re-enter your password</label>
        <input
          id="purge-password"
          type="password"
          value={purgePassword}
          onChange={(event) => setPurgePassword(event.target.value)}
          autoComplete="current-password"
          required
        />

        <button className="danger" type="submit" disabled={purgeBusy}>
          <ShieldAlert size={18} aria-hidden="true" />
          Delete matching transactions
        </button>
      </form>

      {selected ? (
        <form className="panel form-stack" onSubmit={(event) => void submitCorrection(event)}>
          <h2>Correct transaction</h2>
          <label htmlFor="correction-reason">Reason</label>
          <textarea id="correction-reason" value={reason} onChange={(event) => setReason(event.target.value)} required />
          <label htmlFor="correction-date">Date</label>
          <input id="correction-date" type="date" value={replacement.transactionDate} onChange={(event) => setReplacement((current) => ({ ...current, transactionDate: event.target.value }))} required />
          <label htmlFor="correction-project">Project</label>
          <select id="correction-project" value={replacement.projectId} onChange={(event) => setReplacement((current) => ({ ...current, projectId: event.target.value }))}>
            {projects.map((project) => <option key={project.id} value={project.id}>{project.projectCode} {project.projectName}</option>)}
          </select>
          <label htmlFor="correction-item">Item</label>
          <select id="correction-item" value={replacement.itemId} onChange={(event) => setReplacement((current) => ({ ...current, itemId: event.target.value }))}>
            {items.map((item) => <option key={item.id} value={item.id}>{item.item}</option>)}
          </select>
          <label htmlFor="correction-amount">Amount</label>
          <input id="correction-amount" type="number" step="any" value={replacement.amount} onChange={(event) => setReplacement((current) => ({ ...current, amount: event.target.value }))} required />
          <label htmlFor="correction-unit">Unit</label>
          <input id="correction-unit" value={replacement.unitOfMeasure} onChange={(event) => setReplacement((current) => ({ ...current, unitOfMeasure: event.target.value }))} required />
          <label htmlFor="correction-comments">Comments</label>
          <textarea id="correction-comments" value={replacement.comments} onChange={(event) => setReplacement((current) => ({ ...current, comments: event.target.value }))} />
          <button type="submit">Save correction</button>
        </form>
      ) : null}
    </div>
  );
}

function ImportAdmin({
  actorId,
  profiles,
  projects,
  onMessage,
  onError,
  onRefresh
}: AdminChildProps & {
  actorId: string;
  profiles: Profile[];
  projects: Project[];
}): JSX.Element {
  const [itemsImport, setItemsImport] = useState<ParsedItemsImport | null>(null);
  const [projectUsersImport, setProjectUsersImport] = useState<ParsedProjectUsersImport | null>(null);

  async function importItems() {
    if (!itemsImport) return;
    try {
      const batch = writeBatch(itemsCollection.firestore);
      itemsImport.rows.forEach((row) => {
        if (!row.databaseCode || !row.item) return;
        batch.set(
          itemDoc(itemIdFromDatabaseCode(row.databaseCode)),
          {
            databaseCode: row.databaseCode,
            itemCode: row.itemCode,
            itemType: row.itemType,
            item: row.item,
            unitOfMeasure: row.unitOfMeasure,
            active: row.active,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      });
      await batch.commit();
      await addDoc(auditLogCollection, {
        actorUserId: actorId,
        action: "import_items",
        entityType: "items",
        entityId: "items_20260603",
        beforeJson: null,
        afterJson: { rowCount: itemsImport.rows.length, issueCount: itemsImport.issues.length },
        reason: "Admin-approved spreadsheet import",
        createdAt: serverTimestamp()
      });
      onMessage("Items imported.");
      await onRefresh();
    } catch {
      onError("Could not import items.");
    }
  }

  async function importProjectUsers() {
    if (!projectUsersImport) return;
    try {
      const batch = writeBatch(projectsCollection.firestore);
      projectUsersImport.projects.forEach((projectCode) => {
        const id = projectIdFromCode(projectCode);
        batch.set(
          projectDoc(id),
          {
            projectCode,
            projectName: projects.find((project) => project.projectCode === projectCode)?.projectName || projectCode,
            active: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
      });

      const profilesByName = new Map(profiles.map((profile) => [profile.displayName.toLowerCase(), profile]));
      let matchedMemberships = 0;
      const unmatchedUsers = new Set<string>();
      projectUsersImport.rows.forEach((row) => {
        const profile = profilesByName.get(row.displayName.toLowerCase());
        if (!profile) {
          unmatchedUsers.add(row.displayName);
          return;
        }
        const projectId = projectIdFromCode(row.projectCode);
        batch.set(
          membershipDoc(profile.id, projectId),
          {
            userId: profile.id,
            projectId,
            active: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            updatedBy: actorId
          },
          { merge: true }
        );
        matchedMemberships += 1;
      });

      await batch.commit();
      await addDoc(auditLogCollection, {
        actorUserId: actorId,
        action: "import_project_users",
        entityType: "projectMemberships",
        entityId: "projects-users_20260603",
        beforeJson: null,
        afterJson: {
          projectCount: projectUsersImport.projects.length,
          matchedMemberships,
          unmatchedUsers: [...unmatchedUsers]
        },
        reason: "Admin-approved spreadsheet import",
        createdAt: serverTimestamp()
      });
      onMessage(`Projects imported. Matched ${matchedMemberships} memberships; ${unmatchedUsers.size} names need user accounts or exact display-name matching.`);
      await onRefresh();
    } catch {
      onError("Could not import project/user data.");
    }
  }

  return (
    <div className="admin-grid">
      <section className="panel form-stack">
        <h2>Item spreadsheet</h2>
        <input type="file" accept=".xlsx" onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void parseItemsFile(file).then(setItemsImport).catch(() => onError("Could not read item spreadsheet."));
        }} />
        {itemsImport ? (
          <>
            <ImportSummary issues={itemsImport.issues} rowCount={itemsImport.rows.length} />
            <button type="button" onClick={() => void importItems()}>
              <FileUp size={18} aria-hidden="true" />
              Import items
            </button>
          </>
        ) : null}
      </section>

      <section className="panel form-stack">
        <h2>Project/user spreadsheet</h2>
        <input type="file" accept=".xlsx" onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void parseProjectUsersFile(file).then(setProjectUsersImport).catch(() => onError("Could not read project/user spreadsheet."));
        }} />
        {projectUsersImport ? (
          <>
            <ImportSummary issues={projectUsersImport.issues} rowCount={projectUsersImport.rows.length} />
            <p className="helper-text">{projectUsersImport.projects.length} projects, {projectUsersImport.users.length} user names.</p>
            <button type="button" onClick={() => void importProjectUsers()}>
              <FileUp size={18} aria-hidden="true" />
              Import projects
            </button>
          </>
        ) : null}
      </section>
    </div>
  );
}

function ProjectCheckboxes({
  projects,
  selected,
  onToggle
}: {
  projects: Project[];
  selected: string[];
  onToggle: (projectId: string) => void;
}): JSX.Element {
  return (
    <fieldset className="checkbox-grid">
      <legend>Projects</legend>
      {projects.map((project) => (
        <label key={project.id}>
          <input
            type="checkbox"
            checked={selected.includes(project.id)}
            onChange={() => onToggle(project.id)}
          />
          <span>{project.projectCode}</span>
        </label>
      ))}
    </fieldset>
  );
}

function EntityTable({
  title,
  rows
}: {
  title: string;
  rows: Array<{
    id: string;
    primary: string;
    secondary: string;
    active: boolean;
    onEdit?: () => void;
    onToggle: () => void;
    onDelete: () => void;
  }>;
}): JSX.Element {
  return (
    <section className={title ? "panel" : ""}>
      {title ? <h2>{title}</h2> : null}
      <div className="table-shell compact-table">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Active</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td data-label="Name">
                  <span>{row.primary}</span>
                  <small>{row.secondary}</small>
                </td>
                <td data-label="Active">{row.active ? "yes" : "no"}</td>
                <td data-label="Actions" className="action-cell">
                  {row.onEdit ? (
                    <button className="secondary" type="button" onClick={row.onEdit}>
                      <Pencil size={16} aria-hidden="true" />
                      Edit
                    </button>
                  ) : null}
                  <button className="secondary" type="button" onClick={row.onToggle}>
                    {row.active ? "Deactivate" : "Activate"}
                  </button>
                  <button className="danger" type="button" onClick={row.onDelete}>
                    <Trash2 size={16} aria-hidden="true" />
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function ImportSummary({ issues, rowCount }: { issues: { severity: string; message: string; row?: number; field?: string }[]; rowCount: number }): JSX.Element {
  const errors = issues.filter((issue) => issue.severity === "error").length;
  const warnings = issues.length - errors;
  return (
    <div className="import-summary">
      <p>{rowCount} rows, {errors} errors, {warnings} warnings.</p>
      <ul>
        {issues.slice(0, 12).map((issue, index) => (
          <li key={`${issue.row}-${issue.field}-${index}`}>
            {issue.row ? `Row ${issue.row}: ` : ""}{issue.message}
          </li>
        ))}
      </ul>
    </div>
  );
}
