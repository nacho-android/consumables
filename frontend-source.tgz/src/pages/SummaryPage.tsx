import {
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  where
} from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { ChevronLeft, ChevronRight, Download, FileSpreadsheet, Pencil, Save, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Message } from "../components/Message";
import { Modal } from "../components/Modal";
import { useAuth } from "../hooks/useAuth";
import {
  itemsCollection,
  membershipsCollection,
  profilesCollection,
  projectDoc,
  projectsCollection,
  transactionsCollection
} from "../lib/collections";
import { functions } from "../lib/firebase";
import {
  dateRangeLabel,
  formatDate,
  formatDateTime,
  rangeForPreset
} from "../lib/date";
import {
  downloadCsv,
  downloadXlsx,
  toFriendlyRows,
  type ExportFormat
} from "../lib/export";
import type {
  AcquisitionTransaction,
  DatePreset,
  DateRange,
  Item,
  Profile,
  Project
} from "../types";

const PAGE_SIZES = [10, 20, 50, 100];
const UNIT_OPTIONS = ["each", "box", "pack", "bottle", "bag", "tube", "vial", "strip of 10", "mL", "L", "g", "kg"];
const correctTransaction = httpsCallable(functions, "correctTransaction");

type EditForm = {
  transactionDate: string;
  projectId: string;
  itemId: string;
  amount: string;
  unitOfMeasure: string;
  comments: string;
};

export function SummaryPage(): JSX.Element {
  const { user, profile, isAdmin } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [projectFilter, setProjectFilter] = useState("all");
  const [preset, setPreset] = useState<DatePreset>("month");
  const [range, setRange] = useState<DateRange>(rangeForPreset("month"));
  const [transactions, setTransactions] = useState<AcquisitionTransaction[]>([]);
  const [profiles, setProfiles] = useState<Map<string, Profile>>(new Map());
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(0);
  const [downloadOpen, setDownloadOpen] = useState(false);
  const [downloadFormat, setDownloadFormat] = useState<ExportFormat>("csv");
  const [editing, setEditing] = useState<AcquisitionTransaction | null>(null);
  const [editReason, setEditReason] = useState("");
  const [editForm, setEditForm] = useState<EditForm>({
    transactionDate: "",
    projectId: "",
    itemId: "",
    amount: "",
    unitOfMeasure: "",
    comments: ""
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user || !profile) return undefined;
    let cancelled = false;
    async function loadProjects() {
      if (isAdmin) {
        const snapshot = await getDocs(query(projectsCollection, orderBy("projectCode")));
        if (!cancelled) setProjects(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Project)));
        return;
      }
      const membershipQuery = query(
        membershipsCollection,
        where("userId", "==", user!.uid),
        where("active", "==", true)
      );
      const memberships = await getDocs(membershipQuery);
      const loaded = await Promise.all(
        memberships.docs.map(async (membership) => {
          const snapshot = await getDocSafe(membership.data().projectId);
          return snapshot;
        })
      );
      if (!cancelled) {
        setProjects(loaded.filter((project): project is Project => Boolean(project)));
      }
    }
    void loadProjects().catch(() => setError("Could not load projects."));
    return () => {
      cancelled = true;
    };
  }, [isAdmin, profile, user]);

  useEffect(() => {
    if (!user || !profile) return undefined;
    let cancelled = false;
    async function loadItems() {
      const snapshot = await getDocs(query(itemsCollection, where("active", "==", true), orderBy("item")));
      if (!cancelled) setItems(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Item)));
    }
    void loadItems().catch(() => setError("Could not load active items for editing."));
    return () => {
      cancelled = true;
    };
  }, [profile, user]);

  useEffect(() => {
    setPage(0);
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectFilter, range.start, range.end, projects.length]);

  useEffect(() => {
    if (!isAdmin) {
      setProfiles(profile ? new Map([[profile.id, profile]]) : new Map());
      return;
    }
    async function loadProfiles() {
      const snapshot = await getDocs(profilesCollection);
      setProfiles(new Map(snapshot.docs.map((doc) => [doc.id, { id: doc.id, ...doc.data() } as Profile])));
    }
    void loadProfiles().catch(() => undefined);
  }, [isAdmin, profile]);

  const totalPages = Math.max(1, Math.ceil(transactions.length / pageSize));
  const paged = useMemo(
    () => transactions.slice(page * pageSize, page * pageSize + pageSize),
    [transactions, page, pageSize]
  );
  const editableProjects = useMemo(() => projects.filter((project) => project.active), [projects]);
  const editUnitOptions = useMemo(() => {
    const selectedItem = items.find((item) => item.id === editForm.itemId);
    const defaultUnit = selectedItem?.unitOfMeasure?.trim() || editForm.unitOfMeasure.trim() || "each";
    return [...new Set([defaultUnit, ...UNIT_OPTIONS])];
  }, [editForm.itemId, editForm.unitOfMeasure, items]);

  function selectableProjectIds(selected: string): string[] {
    if (selected === "all") return projects.map((project) => project.id);
    return projects.some((project) => project.id === selected) ? [selected] : [];
  }

  async function fetchTransactions(selectedProject: string, selectedRange: DateRange): Promise<AcquisitionTransaction[]> {
    const projectIds = selectableProjectIds(selectedProject);
    if (projectIds.length === 0) return [];

    const chunks = chunk(projectIds, 30);
    const results = await Promise.all(
      chunks.map(async (ids) => {
        const snapshot = await getDocs(
          query(
            transactionsCollection,
            where("projectId", "in", ids),
            where("transactionDate", ">=", selectedRange.start),
            where("transactionDate", "<=", selectedRange.end),
            orderBy("transactionDate", "desc"),
            orderBy("submittedAt", "desc"),
            limit(1000)
          )
        );
        return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as AcquisitionTransaction));
      })
    );

    return results
      .flat()
      .sort((a, b) => {
        if (a.transactionDate !== b.transactionDate) return b.transactionDate.localeCompare(a.transactionDate);
        return (b.submittedAt?.toMillis?.() ?? 0) - (a.submittedAt?.toMillis?.() ?? 0);
      });
  }

  async function refresh() {
    if (projects.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      setTransactions(await fetchTransactions(projectFilter, range));
    } catch {
      setError("Could not load transactions for this filter.");
    } finally {
      setBusy(false);
    }
  }

  async function downloadFiltered() {
    setBusy(true);
    setError(null);
    try {
      const rows = toFriendlyRows(await fetchTransactions(projectFilter, range), profiles);
      const suffix = `${projectFilter === "all" ? "all-projects" : projectFilter}_${range.start}_${range.end}`;
      if (downloadFormat === "csv") downloadCsv(rows, `acquisitions_${suffix}.csv`);
      else downloadXlsx(rows, `acquisitions_${suffix}.xlsx`);
      setDownloadOpen(false);
    } catch {
      setError("Could not download this data set.");
    } finally {
      setBusy(false);
    }
  }

  function startEdit(tx: AcquisitionTransaction) {
    const activeProjectId = editableProjects.some((project) => project.id === tx.projectId)
      ? tx.projectId
      : editableProjects[0]?.id || "";
    const activeItemId = items.some((item) => item.id === tx.itemId)
      ? tx.itemId
      : items[0]?.id || "";
    const selectedItem = items.find((item) => item.id === activeItemId);
    setEditing(tx);
    setEditReason("");
    setEditForm({
      transactionDate: tx.transactionDate,
      projectId: activeProjectId,
      itemId: activeItemId,
      amount: String(tx.amount),
      unitOfMeasure: tx.unitOfMeasure || selectedItem?.unitOfMeasure || "each",
      comments: tx.comments || ""
    });
    setError(null);
  }

  function setEditItem(itemId: string) {
    const selectedItem = items.find((item) => item.id === itemId);
    setEditForm((current) => ({
      ...current,
      itemId,
      unitOfMeasure: selectedItem?.unitOfMeasure?.trim() || current.unitOfMeasure || "each"
    }));
  }

  async function submitEdit(event: React.FormEvent) {
    event.preventDefault();
    if (!editing) return;
    const project = editableProjects.find((entry) => entry.id === editForm.projectId);
    const item = items.find((entry) => entry.id === editForm.itemId);
    const numericAmount = Number(editForm.amount);
    if (!project || !item || !editReason.trim()) {
      setError("Edit requires a reason, active project, and active item.");
      return;
    }
    if (!editForm.transactionDate || !Number.isFinite(numericAmount) || numericAmount <= 0 || !editForm.unitOfMeasure.trim()) {
      setError("Amount must be numeric and greater than zero, and a unit is required.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await correctTransaction({
        transactionId: editing.id,
        reason: editReason,
        replacement: {
          transactionDate: editForm.transactionDate,
          projectId: project.id,
          itemId: item.id,
          amount: numericAmount,
          unitOfMeasure: editForm.unitOfMeasure.trim(),
          comments: editForm.comments.trim(),
          projectCode: project.projectCode,
          projectName: project.projectName,
          databaseCode: item.databaseCode,
          itemCode: item.itemCode,
          itemType: item.itemType,
          itemName: item.item
        }
      });
      setEditing(null);
      await refresh();
    } catch {
      setError("Could not save the transaction edit.");
    } finally {
      setBusy(false);
    }
  }

  function setPresetAndRange(nextPreset: DatePreset) {
    setPreset(nextPreset);
    if (nextPreset !== "custom") setRange(rangeForPreset(nextPreset));
  }

  return (
    <section className="summary-layout">
      <div className="toolbar">
        <div className="field-row wrap">
          <label htmlFor="summary-project">Project</label>
          <select id="summary-project" value={projectFilter} onChange={(event) => setProjectFilter(event.target.value)}>
            <option value="all">All accessible projects</option>
            {projects.map((project) => (
              <option key={project.id} value={project.id}>
                {project.projectCode} {project.projectName}{project.active ? "" : " (inactive)"}
              </option>
            ))}
          </select>
        </div>

        <div className="segmented" aria-label="Date period">
          {(["today", "week", "month", "year", "custom"] as DatePreset[]).map((option) => (
            <button
              key={option}
              type="button"
              className={preset === option ? "active" : ""}
              onClick={() => setPresetAndRange(option)}
            >
              {option === "week" ? "This week" : option === "month" ? "This month" : option === "year" ? "This year" : option}
            </button>
          ))}
        </div>

        {preset === "custom" ? (
          <div className="field-row wrap">
            <input
              type="date"
              value={range.start}
              aria-label="Start date"
              onChange={(event) => setRange((current) => ({ ...current, start: event.target.value }))}
            />
            <input
              type="date"
              value={range.end}
              aria-label="End date"
              onChange={(event) => setRange((current) => ({ ...current, end: event.target.value }))}
            />
          </div>
        ) : null}

        <button className="secondary" type="button" disabled={busy} onClick={() => void refresh()}>
          <Search size={18} aria-hidden="true" />
          Refresh
        </button>
        <button type="button" disabled={busy} onClick={() => setDownloadOpen(true)}>
          <Download size={18} aria-hidden="true" />
          Download
        </button>
      </div>

      <div className="table-shell">
        <table>
          <thead>
            <tr>
              <th>Date and time</th>
              <th>User</th>
              <th>Project</th>
              <th>Item</th>
              <th>Amount</th>
              <th>Unit</th>
              <th>Comments</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {paged.map((tx) => (
              <tr key={tx.id}>
                <td data-label="Date and time">
                  <span>{formatDate(tx.transactionDate)}</span>
                  <small>{formatDateTime(tx.submittedAt)}</small>
                </td>
                <td data-label="User">{tx.userDisplayName || tx.userEmail}</td>
                <td data-label="Project">
                  <span>{tx.projectCode}</span>
                  <small>{tx.projectName}</small>
                </td>
                <td data-label="Item">
                  <span>{tx.itemName}</span>
                  <small>{[tx.itemType, tx.databaseCode, tx.itemCode].filter(Boolean).join(" | ")}</small>
                </td>
                <td data-label="Amount">{tx.amount}</td>
                <td data-label="Unit">{tx.unitOfMeasure}</td>
                <td data-label="Comments">{tx.comments}</td>
                <td data-label="Status">
                  <span className={`status ${tx.status}`}>{tx.status}</span>
                </td>
                <td data-label="Actions" className="action-cell">
                  <button className="secondary" type="button" disabled={tx.status !== "active" || busy} onClick={() => startEdit(tx)}>
                    <Pencil size={16} aria-hidden="true" />
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {paged.length === 0 ? <p className="empty-row">No transactions for {dateRangeLabel(range)}.</p> : null}
      </div>

      <footer className="pagination">
        <label htmlFor="page-size">Rows</label>
        <select
          id="page-size"
          value={pageSize}
          onChange={(event) => {
            setPageSize(Number(event.target.value));
            setPage(0);
          }}
        >
          {PAGE_SIZES.map((size) => (
            <option key={size} value={size}>{size}</option>
          ))}
        </select>
        <button className="icon-button" type="button" disabled={page === 0} onClick={() => setPage((current) => current - 1)} title="Previous page">
          <ChevronLeft size={20} aria-hidden="true" />
          <span className="sr-only">Previous page</span>
        </button>
        <span>Page {page + 1} of {totalPages}</span>
        <button className="icon-button" type="button" disabled={page + 1 >= totalPages} onClick={() => setPage((current) => current + 1)} title="Next page">
          <ChevronRight size={20} aria-hidden="true" />
          <span className="sr-only">Next page</span>
        </button>
      </footer>

      {error ? <Message kind="error">{error}</Message> : null}

      <Modal title="Download acquisitions" open={downloadOpen} onClose={() => setDownloadOpen(false)}>
        <div className="form-stack">
          <label htmlFor="download-project">Project</label>
          <select id="download-project" value={projectFilter} onChange={(event) => setProjectFilter(event.target.value)}>
            <option value="all">All accessible projects</option>
            {projects.map((project) => (
              <option key={project.id} value={project.id}>
                {project.projectCode} {project.projectName}{project.active ? "" : " (inactive)"}
              </option>
            ))}
          </select>

          <label htmlFor="download-format">Format</label>
          <select id="download-format" value={downloadFormat} onChange={(event) => setDownloadFormat(event.target.value as ExportFormat)}>
            <option value="csv">CSV</option>
            <option value="xlsx">Excel</option>
          </select>

          <p className="helper-text">{dateRangeLabel(range)}</p>
          <button type="button" disabled={busy} onClick={() => void downloadFiltered()}>
            <FileSpreadsheet size={18} aria-hidden="true" />
            Download
          </button>
        </div>
      </Modal>

      <Modal title="Edit acquisition" open={Boolean(editing)} onClose={() => setEditing(null)}>
        <form className="form-stack" onSubmit={(event) => void submitEdit(event)}>
          <label htmlFor="edit-reason">Correction reason</label>
          <textarea
            id="edit-reason"
            rows={3}
            value={editReason}
            onChange={(event) => setEditReason(event.target.value)}
            required
          />

          <label htmlFor="edit-date">Acquisition date</label>
          <input
            id="edit-date"
            type="date"
            value={editForm.transactionDate}
            onChange={(event) => setEditForm((current) => ({ ...current, transactionDate: event.target.value }))}
            required
          />

          <label htmlFor="edit-project">Project</label>
          <select
            id="edit-project"
            value={editForm.projectId}
            onChange={(event) => setEditForm((current) => ({ ...current, projectId: event.target.value }))}
            required
          >
            <option value="">Select project</option>
            {editableProjects.map((project) => (
              <option key={project.id} value={project.id}>
                {project.projectCode} {project.projectName}
              </option>
            ))}
          </select>

          <label htmlFor="edit-item">Item</label>
          <select id="edit-item" value={editForm.itemId} onChange={(event) => setEditItem(event.target.value)} required>
            <option value="">Select item</option>
            {items.map((item) => (
              <option key={item.id} value={item.id}>
                {item.item} {[item.itemType, item.itemCode].filter(Boolean).join(" | ")}
              </option>
            ))}
          </select>

          <div className="two-column">
            <div className="form-stack compact">
              <label htmlFor="edit-amount">Amount</label>
              <input
                id="edit-amount"
                type="number"
                inputMode="decimal"
                step="any"
                min="0"
                value={editForm.amount}
                onChange={(event) => setEditForm((current) => ({ ...current, amount: event.target.value }))}
                required
              />
            </div>
            <div className="form-stack compact">
              <label htmlFor="edit-unit">Unit</label>
              <select
                id="edit-unit"
                value={editForm.unitOfMeasure}
                onChange={(event) => setEditForm((current) => ({ ...current, unitOfMeasure: event.target.value }))}
                required
              >
                {editUnitOptions.map((unit) => (
                  <option key={unit} value={unit}>
                    {unit}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <label htmlFor="edit-comments">Comments</label>
          <textarea
            id="edit-comments"
            rows={3}
            value={editForm.comments}
            onChange={(event) => setEditForm((current) => ({ ...current, comments: event.target.value }))}
          />

          <div className="button-row">
            <button type="submit" disabled={busy}>
              <Save size={18} aria-hidden="true" />
              Save edit
            </button>
            <button className="secondary" type="button" disabled={busy} onClick={() => setEditing(null)}>
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </section>
  );
}

async function getDocSafe(projectId: string): Promise<Project | null> {
  const snapshot = await getDoc(projectDoc(projectId));
  return snapshot.exists() ? ({ id: snapshot.id, ...snapshot.data() } as Project) : null;
}

function chunk<T>(values: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let index = 0; index < values.length; index += size) {
    chunks.push(values.slice(index, index + size));
  }
  return chunks;
}
