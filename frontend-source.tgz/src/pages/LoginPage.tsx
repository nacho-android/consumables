import { LogIn } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { Message } from "../components/Message";

export function LoginPage(): JSX.Element {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(email, password);
    } catch {
      setError("Invalid email or password, or this account is not active.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="login-screen">
      <section className="login-panel" aria-labelledby="login-title">
        <div>
          <p className="eyebrow">Consumable acquisitions</p>
          <h1 id="login-title">Sign in</h1>
        </div>

        <form onSubmit={(event) => void submit(event)} className="form-stack">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            required
          />

          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            required
          />

          <button type="submit" disabled={busy}>
            <LogIn size={18} aria-hidden="true" />
            Sign in
          </button>
        </form>

        {error ? <Message kind="error">{error}</Message> : null}
      </section>
    </main>
  );
}
