import { getDocs, orderBy, query } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { FileDown, FileSpreadsheet, Mail } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Message } from "../components/Message";
import { useUserPreferences } from "../hooks/useUserPreferences";
import { billingAddressesCollection, itemCostsCollection, projectsCollection } from "../lib/collections";
import { functions } from "../lib/firebase";
import { buildInvoiceWorkbook, downloadInvoiceFile, invoiceFileName, invoiceXlsxFile, type InvoiceFile, type InvoiceLine, type InvoiceOptions } from "../lib/invoice";
import { costForUnit } from "../lib/itemCosts";
import invoiceTemplateUrl from "../assets/invoice_template_20261105.xlsx?url";
import type { AcquisitionTransaction, BillingAddress, ItemCost, Project } from "../types";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
] as const;

const listTransactions = httpsCallable(functions, "listAccessibleTransactions");
const emailInvoice = httpsCallable(functions, "adminEmailInvoice");
const getEmailStatus = httpsCallable(functions, "adminGetInvoiceEmailStatus");
type InvoiceAction = "xlsx" | "pdf" | "email";

export function InvoicePage(): JSX.Element {
  const { preferences, updatePreferences, preferencesReady, preferencesError } = useUserPreferences();
  const emailAddress = preferences.invoiceEmail ?? "";
  const emailXlsx = preferences.invoiceXlsx ?? true;
  const emailPdf = preferences.invoicePdf ?? false;
  const defaults = useMemo(() => defaultInvoiceSelections(), []);
  const [projects, setProjects] = useState<Project[]>([]);
  const [itemCosts, setItemCosts] = useState<ItemCost[]>([]);
  const [billingAddresses, setBillingAddresses] = useState<BillingAddress[]>([]);
  const [projectId, setProjectId] = useState("");
  const [chargeToId, setChargeToId] = useState("");
  const [startDate, setStartDate] = useState(defaults.startDate);
  const [endDate, setEndDate] = useState(defaults.endDate);
  const [invoiceMonth, setInvoiceMonth] = useState(defaults.month);
  const [invoiceYear, setInvoiceYear] = useState(defaults.year);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pendingEmail, setPendingEmail] = useState<{ messageId: string; address: string; summary: string } | null>(null);
  const generating = useRef(false);
  const emailInput = useRef<HTMLInputElement>(null);
  const formatInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!pendingEmail) return;
    let cancelled = false;
    let attempts = 0;
    let timer: ReturnType<typeof setTimeout>;
    async function checkDelivery() {
      attempts += 1;
      try {
        const result = await getEmailStatus({ messageId: pendingEmail!.messageId });
        if (cancelled) return;
        const state = (result.data as { state: string }).state;
        if (state === "SUCCESS") {
          setMessage(`Invoice emailed to ${pendingEmail!.address}. ${pendingEmail!.summary}`);
          setPendingEmail(null);
          return;
        }
        if (state === "ERROR") {
          setMessage(null);
          setError("The invoice email could not be sent. Check the recipient address and email service configuration, then try again.");
          setPendingEmail(null);
          return;
        }
      } catch {
        // A status lookup failure does not mean that delivery failed; keep the queued message.
      }
      if (!cancelled && attempts < 15) timer = setTimeout(() => void checkDelivery(), 2000);
    }
    timer = setTimeout(() => void checkDelivery(), 1500);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [pendingEmail]);

  useEffect(() => {
    let cancelled = false;
    async function loadAdminData() {
      const [projectSnap, costSnap, billingSnap] = await Promise.all([
        getDocs(query(projectsCollection, orderBy("projectCode"))),
        getDocs(query(itemCostsCollection, orderBy("itemName"))),
        getDocs(query(billingAddressesCollection, orderBy("displayName")))
      ]);
      if (cancelled) return;
      const loadedProjects = projectSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Project));
      setProjects(loadedProjects);
      setItemCosts(costSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as ItemCost)));
      setBillingAddresses(billingSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as BillingAddress)));
      setProjectId((current) => current || loadedProjects[0]?.id || "");
    }
    void loadAdminData().catch(() => setError("Could not load invoice setup data."));
    return () => {
      cancelled = true;
    };
  }, []);

  const selectedProject = projects.find((project) => project.id === projectId) ?? null;
  const selectedBillingAddress = billingAddresses.find((entry) => entry.id === chargeToId) ?? null;
  const years = useMemo(() => {
    const currentYear = defaults.year;
    return Array.from({ length: 5 }, (_, index) => currentYear - 2 + index);
  }, [defaults.year]);

  useEffect(() => {
    if (!selectedProject || billingAddresses.length === 0) return;
    const matched = billingAddresses.find((entry) =>
      projectCodeList(entry.projectCodes).includes(selectedProject.projectCode.trim())
    );
    setChargeToId((current) => {
      if (matched) return matched.id;
      return current && !selectedProject ? current : "";
    });
  }, [billingAddresses, selectedProject]);

  async function generateInvoice(action: InvoiceAction) {
    if (generating.current) return;
    setError(null);
    setMessage(null);
    if (action === "email") {
      const address = emailAddress.trim();
      const missingFormat = !emailXlsx && !emailPdf;
      if (!address || missingFormat) {
        setError([!address ? "Enter an email address." : "", missingFormat ? "Tick at least one invoice format: xlsx or pdf." : ""].filter(Boolean).join(" "));
        if (!address) emailInput.current?.focus(); else formatInput.current?.focus();
        return;
      }
      if (!emailInput.current?.checkValidity() || !/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(address)) {
        setError("Enter a valid email address.");
        emailInput.current?.focus();
        return;
      }
    }
    if (!selectedProject) {
      setError("Select a project before generating an invoice.");
      return;
    }
    if (!selectedBillingAddress) {
      setError("Select who to charge before generating an invoice.");
      return;
    }
    if (!startDate || !endDate || startDate > endDate) {
      setError("Choose a valid invoice date range.");
      return;
    }

    generating.current = true;
    setBusy(true);
    setPendingEmail(null);
    try {
      const result = await listTransactions({
        projectId: selectedProject.id,
        startDate,
        endDate
      });
      const transactions = (((result.data as { transactions?: unknown }).transactions ?? []) as AcquisitionTransaction[])
        .filter((tx) => tx.status === "active")
        .sort((a, b) => {
          const typeCompare = a.itemType.localeCompare(b.itemType);
          if (typeCompare !== 0) return typeCompare;
          return a.itemName.localeCompare(b.itemName);
        });
      const costsByItem = new Map(itemCosts.map((itemCost) => [itemCost.itemId, itemCost]));
      const missingCosts = new Set<string>();
      const lines = groupedInvoiceLines(transactions, costsByItem, missingCosts);
      const templateResponse = await fetch(invoiceTemplateUrl);
      if (!templateResponse.ok) throw new Error("Could not load the invoice template.");
      const options: InvoiceOptions = {
        projectCode: selectedProject.projectCode,
        projectName: selectedProject.projectName,
        billingAddress: selectedBillingAddress.address,
        invoiceMonth,
        invoiceYear,
        lines
      };
      const workbook = buildInvoiceWorkbook(await templateResponse.arrayBuffer(), options);
      const files: InvoiceFile[] = [];
      if (action === "xlsx" || (action === "email" && emailXlsx)) files.push(invoiceXlsxFile(workbook, options));
      if (action === "pdf" || (action === "email" && emailPdf)) {
        const { buildInvoicePdf } = await import("../lib/invoicePdf");
        files.push({ bytes: await buildInvoicePdf(workbook), fileName: invoiceFileName(options, "pdf"), contentType: "application/pdf" });
      }
      const warning = missingCosts.size > 0 ? ` ${missingCosts.size} item cost${missingCosts.size === 1 ? "" : "s"} missing and exported as 0.` : "";
      const summary = `Invoice generated for ${transactions.length} active transaction${transactions.length === 1 ? "" : "s"} across ${lines.length} invoice line${lines.length === 1 ? "" : "s"}.${warning}`;
      if (action === "email") {
        const result = await emailInvoice({
          requestId: crypto.randomUUID(),
          email: emailAddress.trim(),
          projectId: selectedProject.id,
          period: `${invoiceMonth} ${invoiceYear}`,
          attachments: files.map((file) => ({
            format: file.fileName.endsWith(".pdf") ? "pdf" : "xlsx",
            fileName: file.fileName,
            contentBase64: bytesToBase64(file.bytes)
          }))
        });
        const messageId = (result.data as { messageId: string }).messageId;
        setMessage(`Invoice queued for email to ${emailAddress.trim()}. Delivery has not yet been confirmed. ${summary}`);
        setPendingEmail({ messageId, address: emailAddress.trim(), summary });
      } else {
        files.forEach(downloadInvoiceFile);
        setMessage(summary);
      }
    } catch (cause) {
      const detail = cause instanceof Error ? cause.message : "";
      setError(`Could not ${action === "email" ? "email" : "generate"} the invoice.${detail ? ` ${detail}` : ""}`);
    } finally {
      generating.current = false;
      setBusy(false);
    }
  }

  return (
    <section className="content-grid">
      <form className="panel form-stack" onSubmit={(event) => event.preventDefault()}>
        <div className="form-header">
          <h2>Billing summary invoice</h2>
        </div>

        <label htmlFor="invoice-project">Project</label>
        <select id="invoice-project" value={projectId} onChange={(event) => setProjectId(event.target.value)} required>
          <option value="">Select project</option>
          {projects.map((project) => (
            <option key={project.id} value={project.id}>
              {project.projectCode} {project.projectName}{project.active ? "" : " (inactive)"}
            </option>
          ))}
        </select>

        <label htmlFor="invoice-charge-to">Charge to</label>
        <select id="invoice-charge-to" value={chargeToId} onChange={(event) => setChargeToId(event.target.value)} required>
          <option value="">Select charge recipient</option>
          {billingAddresses.map((entry) => (
            <option key={entry.id} value={entry.id}>
              {entry.displayName}
            </option>
          ))}
        </select>

        <div className="two-column">
          <div className="form-stack compact">
            <label htmlFor="invoice-start">Start date</label>
            <input id="invoice-start" type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} required />
          </div>
          <div className="form-stack compact">
            <label htmlFor="invoice-end">End date</label>
            <input id="invoice-end" type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} required />
          </div>
        </div>

        <div className="two-column">
          <div className="form-stack compact">
            <label htmlFor="invoice-month">Invoice month</label>
            <select id="invoice-month" value={invoiceMonth} onChange={(event) => setInvoiceMonth(event.target.value)}>
              {MONTHS.map((month) => <option key={month} value={month}>{month}</option>)}
            </select>
          </div>
          <div className="form-stack compact">
            <label htmlFor="invoice-year">Invoice year</label>
            <select id="invoice-year" value={invoiceYear} onChange={(event) => setInvoiceYear(Number(event.target.value))}>
              {years.map((year) => <option key={year} value={year}>{year}</option>)}
            </select>
          </div>
        </div>

        <div className="button-row">
          <button type="button" disabled={busy} onClick={() => void generateInvoice("xlsx")}>
            <FileSpreadsheet size={18} aria-hidden="true" />
            Download xlsx Invoice
          </button>
          <button type="button" disabled={busy} onClick={() => void generateInvoice("pdf")}>
            <FileDown size={18} aria-hidden="true" />
            Download pdf Invoice
          </button>
        </div>

        <fieldset className="invoice-email form-stack" disabled={busy || !preferencesReady}>
          <legend>Email Invoice</legend>
          <label htmlFor="invoice-email">Email address</label>
          <input id="invoice-email" ref={emailInput} type="email" autoComplete="email" maxLength={254} value={emailAddress}
            onChange={(event) => updatePreferences({ invoiceEmail: event.target.value })} />
          <fieldset className="checkbox-grid">
            <legend>Attachment formats</legend>
            <label><input ref={formatInput} type="checkbox" checked={emailXlsx} onChange={(event) => updatePreferences({ invoiceXlsx: event.target.checked })} />xlsx</label>
            <label><input type="checkbox" checked={emailPdf} onChange={(event) => updatePreferences({ invoicePdf: event.target.checked })} />pdf</label>
          </fieldset>
          <button type="button" onClick={() => void generateInvoice("email")}>
            <Mail size={18} aria-hidden="true" />
            Email Invoice
          </button>
        </fieldset>

        {message ? <Message kind={pendingEmail ? "info" : "success"}>{message}</Message> : null}
        {error ? <Message kind="error">{error}</Message> : null}
        {preferencesError ? <Message kind="info">{preferencesError}</Message> : null}
      </form>
    </section>
  );
}

function defaultInvoiceSelections(): {
  month: string;
  year: number;
  startDate: string;
  endDate: string;
} {
  const parts = new Intl.DateTimeFormat("en-AU", {
    timeZone: "Australia/Sydney",
    year: "numeric",
    month: "numeric"
  }).formatToParts(new Date());
  const currentYear = Number(parts.find((part) => part.type === "year")?.value);
  const currentMonth = Number(parts.find((part) => part.type === "month")?.value);
  const previousMonthIndex = currentMonth === 1 ? 11 : currentMonth - 2;
  const invoiceYear = currentMonth === 1 ? currentYear - 1 : currentYear;
  const monthNumber = previousMonthIndex + 1;
  const startDate = `${invoiceYear}-${String(monthNumber).padStart(2, "0")}-01`;
  const endDay = new Date(Date.UTC(invoiceYear, monthNumber, 0)).getUTCDate();
  const endDate = `${invoiceYear}-${String(monthNumber).padStart(2, "0")}-${String(endDay).padStart(2, "0")}`;
  return {
    month: MONTHS[previousMonthIndex],
    year: invoiceYear,
    startDate,
    endDate
  };
}

function projectCodeList(projectCodes: string): string[] {
  return projectCodes
    .split(/[,;\n]+/)
    .map((code) => code.trim())
    .filter(Boolean);
}

function groupedInvoiceLines(
  transactions: AcquisitionTransaction[],
  costsByItem: Map<string, ItemCost>,
  missingCosts: Set<string>
): InvoiceLine[] {
  const linesByKey = new Map<string, InvoiceLine>();

  transactions.forEach((tx) => {
    const cost = costForUnit(costsByItem.get(tx.itemId), tx.unitOfMeasure);
    if (typeof cost !== "number" || !Number.isFinite(cost)) missingCosts.add(tx.itemName);
    const key = `${tx.databaseCode || tx.itemId}::${tx.unitOfMeasure}`;
    const existing = linesByKey.get(key);
    if (existing) {
      existing.amount += tx.amount;
      return;
    }
    linesByKey.set(key, {
      projectCode: tx.projectCode,
      itemType: tx.itemType,
      itemName: tx.itemName,
      unitOfMeasure: tx.unitOfMeasure,
      amount: tx.amount,
      cost: typeof cost === "number" && Number.isFinite(cost) ? cost : 0
    });
  });

  return [...linesByKey.values()].sort((a, b) => {
    const typeCompare = a.itemType.localeCompare(b.itemType);
    if (typeCompare !== 0) return typeCompare;
    const nameCompare = a.itemName.localeCompare(b.itemName);
    if (nameCompare !== 0) return nameCompare;
    return a.unitOfMeasure.localeCompare(b.unitOfMeasure);
  });
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let index = 0; index < bytes.length; index += 8192) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 8192));
  }
  return btoa(binary);
}
