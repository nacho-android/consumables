import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "./useAuth";
import { db } from "../lib/firebase";

export type UserPreferences = {
  entryProjectId?: string;
  invoiceEmail?: string;
  invoiceXlsx?: boolean;
  invoicePdf?: boolean;
};

function readCache(uid: string, unsaved = false): UserPreferences {
  try {
    return validPreferences(JSON.parse(localStorage.getItem(`consumables.preferences.${uid}${unsaved ? ".pending" : ""}`) || "{}"));
  } catch {
    return {};
  }
}

function validPreferences(value: unknown): UserPreferences {
  const data = (value && typeof value === "object" ? value : {}) as UserPreferences;
  return {
    ...(typeof data.entryProjectId === "string" ? { entryProjectId: data.entryProjectId } : {}),
    ...(typeof data.invoiceEmail === "string" ? { invoiceEmail: data.invoiceEmail } : {}),
    ...(typeof data.invoiceXlsx === "boolean" ? { invoiceXlsx: data.invoiceXlsx } : {}),
    ...(typeof data.invoicePdf === "boolean" ? { invoicePdf: data.invoicePdf } : {})
  };
}

export function useUserPreferences() {
  const { user } = useAuth();
  const uid = user!.uid;
  const [preferences, setPreferences] = useState<UserPreferences>(() => readCache(uid));
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const current = useRef(preferences);
  // Keep unacknowledged changes in browser storage as well, including when a tab
  // closes before the debounce finishes or while the account write is offline.
  const dirty = useRef<UserPreferences>(readCache(uid, true));
  const pending = useRef<UserPreferences>({ ...dirty.current });
  const edited = useRef<UserPreferences>({ ...dirty.current });
  const timer = useRef<ReturnType<typeof setTimeout>>();

  function cache(value: UserPreferences) {
    current.current = value;
    setPreferences(value);
    try {
      localStorage.setItem(`consumables.preferences.${uid}`, JSON.stringify(value));
    } catch {
      // Account storage still persists preferences when browser storage is unavailable.
    }
  }

  function cachePending() {
    try {
      const key = `consumables.preferences.${uid}.pending`;
      if (Object.keys(dirty.current).length) localStorage.setItem(key, JSON.stringify(dirty.current));
      else localStorage.removeItem(key);
    } catch {
      // Account storage is still available when browser storage is blocked.
    }
  }

  async function flush() {
    const patch = pending.current;
    if (!Object.keys(patch).length) return;
    pending.current = {};
    try {
      await setDoc(doc(db, "userPreferences", uid), { ...patch, updatedAt: serverTimestamp() }, { merge: true });
      for (const key of Object.keys(patch) as (keyof UserPreferences)[]) {
        if (dirty.current[key] === patch[key]) delete dirty.current[key];
      }
      cachePending();
      setError(null);
    } catch {
      pending.current = { ...patch, ...pending.current };
      setError("Preferences are saved in this browser, but could not be saved to your account. Change a preference to retry.");
    }
  }

  useEffect(() => {
    let cancelled = false;
    void getDoc(doc(db, "userPreferences", uid)).then((snapshot) => {
      if (!cancelled) cache({ ...current.current, ...validPreferences(snapshot.data()), ...edited.current });
    }).catch(() => {
      if (!cancelled) setError("Could not load account preferences. Using preferences saved in this browser.");
    }).finally(() => {
      if (!cancelled) {
        setReady(true);
        void flush();
      }
    });
    return () => {
      cancelled = true;
      clearTimeout(timer.current);
      void flush();
    };
  }, [uid]);

  function updatePreferences(patch: UserPreferences) {
    edited.current = { ...edited.current, ...patch };
    pending.current = { ...pending.current, ...patch };
    dirty.current = { ...dirty.current, ...patch };
    cachePending();
    cache({ ...current.current, ...patch });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => void flush(), 500);
  }

  return { preferences, updatePreferences, preferencesReady: ready, preferencesError: error };
}
