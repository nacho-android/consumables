import type { ItemCost } from "../types";

export function normalizedCost(value: number | null | undefined): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

export function costEachForItem(itemCost: ItemCost | undefined): number | null {
  return normalizedCost(itemCost?.costEach) ?? normalizedCost(itemCost?.cost);
}

export function costBoxForItem(itemCost: ItemCost | undefined): number | null {
  return normalizedCost(itemCost?.costBox) ?? normalizedCost(itemCost?.cost);
}

export function costForUnit(itemCost: ItemCost | undefined, unitOfMeasure: string): number | null {
  return unitOfMeasure === "box" ? costBoxForItem(itemCost) : costEachForItem(itemCost);
}

export function formatCost(cost: number | null | undefined): string {
  const normalized = normalizedCost(cost);
  return normalized === null ? "missing" : normalized.toFixed(2);
}
