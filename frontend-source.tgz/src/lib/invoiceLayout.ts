// Shared by the XLSX print settings and the browser PDF renderer. All dimensions
// are points (1/72 inch); worksheet row numbers are one-based.
export const INVOICE_PAGE = { width: 595.28, height: 841.89 } as const;
export const INVOICE_FONT = "Arial";
const MAX_DIGIT_WIDTH_PX = 8; // Arial 11 pt at Excel's 96 dpi, rounded to a whole pixel.

export type InvoicePrintBlock = { row: number; endRow: number; height: number };

export function invoicePrintLayout(sheet: Document) {
  const find = (name: string) => Array.from(sheet.getElementsByTagNameNS("*", name));
  const margins = find("pageMargins")[0];
  const left = Number(margins?.getAttribute("left") || 0.5) * 72;
  const right = Number(margins?.getAttribute("right") || 0.5) * 72;
  const top = Number(margins?.getAttribute("top") || 1.5) * 72;
  const bottom = Number(margins?.getAttribute("bottom") || 0.75) * 72;
  const columns = find("col");
  const columnWidths = Array.from({ length: 8 }, (_, index) => {
    const definition = columns.find((column) => Number(column.getAttribute("min")) <= index + 1 && Number(column.getAttribute("max")) >= index + 1);
    const width = Number(definition?.getAttribute("width") || 8.43);
    // ISO 29500 column-width conversion: stored widths already include padding.
    const pixels = Math.floor((256 * width + Math.floor(128 / MAX_DIGIT_WIDTH_PX)) / 256 * MAX_DIGIT_WIDTH_PX);
    return pixels * 72 / 96;
  });
  const scalePercent = Math.min(100, Math.floor((INVOICE_PAGE.width - left - right) / columnWidths.reduce((sum, width) => sum + width, 0) * 100));
  const scale = scalePercent / 100;
  const rowElements = find("row");
  const rows = new Map(rowElements.map((row) => [Number(row.getAttribute("r")), row]));
  const lastRow = Math.max(...rows.keys());
  const defaultHeight = Number(find("sheetFormatPr")[0]?.getAttribute("defaultRowHeight") || 14.4);
  const rowHeight = (row: number) => Number(rows.get(row)?.getAttribute("ht") || defaultHeight);
  const merges = find("mergeCell").map((merge) => merge.getAttribute("ref")!.split(":"));
  const blocks: InvoicePrintBlock[] = [];
  for (let row = 1; row <= lastRow;) {
    const endRow = Math.max(row, ...merges.filter(([start]) => Number(start.replace(/\D/g, "")) === row)
      .map(([, end]) => Number(end.replace(/\D/g, ""))));
    const height = Array.from({ length: endRow - row + 1 }, (_, index) => rowHeight(row + index)).reduce((sum, height) => sum + height, 0) * scale;
    blocks.push({ row, endRow, height });
    row = endRow + 1;
  }
  const repeated = blocks.filter((block) => block.row >= 7 && block.row <= 11);
  const pages: InvoicePrintBlock[][] = [[]];
  const breaks: number[] = [];
  const capacity = INVOICE_PAGE.height - top - bottom;
  let used = 0;
  const totalRow = lastRow - 5;
  for (let index = 0; index < blocks.length; index += 1) {
    const block = blocks[index];
    const requiredHeight = block.row === totalRow ? blocks.slice(index).reduce((sum, block) => sum + block.height, 0) : block.height;
    if (used + requiredHeight > capacity + 0.01) {
      breaks.push(block.row - 1);
      pages.push([...repeated]);
      used = repeated.reduce((sum, block) => sum + block.height, 0);
    }
    pages[pages.length - 1].push(block);
    used += block.height;
  }
  return { ...INVOICE_PAGE, left, right, top, bottom, scale, scalePercent, columnWidths: columnWidths.map((width) => width * scale), pages, breaks, lastRow };
}
