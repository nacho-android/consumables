// SpreadsheetML tint changes HLS luminance, not each RGB channel independently.
export function applyExcelTint(hex: string, tint: number): [number, number, number] {
  const [red, green, blue] = [0, 2, 4].map((offset) => parseInt(hex.slice(offset, offset + 2), 16) / 255);
  const max = Math.max(red, green, blue);
  const min = Math.min(red, green, blue);
  const delta = max - min;
  const luminance = (max + min) / 2;
  const saturation = delta === 0 ? 0 : delta / (1 - Math.abs(2 * luminance - 1));
  const hue = delta === 0 ? 0 : (max === red ? (green - blue) / delta + (green < blue ? 6 : 0) : max === green ? (blue - red) / delta + 2 : (red - green) / delta + 4) / 6;
  const lightness = tint < 0 ? luminance * (1 + tint) : luminance * (1 - tint) + tint;
  const q = lightness < 0.5 ? lightness * (1 + saturation) : lightness + saturation - lightness * saturation;
  const p = 2 * lightness - q;
  const channel = (position: number) => {
    const value = (position + 1) % 1;
    if (value < 1 / 6) return p + (q - p) * 6 * value;
    if (value < 1 / 2) return q;
    if (value < 2 / 3) return p + (q - p) * (2 / 3 - value) * 6;
    return p;
  };
  return saturation === 0 ? [lightness, lightness, lightness] : [channel(hue + 1 / 3), channel(hue), channel(hue - 1 / 3)];
}
