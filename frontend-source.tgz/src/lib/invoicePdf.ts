import { unzipSync } from "fflate";
import { PDFDocument, rgb, type PDFFont, type RGB } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";

export type InvoicePdfFonts = { regular: Uint8Array; bold: Uint8Array };

async function loadFonts(): Promise<InvoicePdfFonts> {
  const load = async (name: string) => {
    const response = await fetch(`${import.meta.env.BASE_URL}fonts/RobotoCondensed-${name}.ttf`);
    if (!response.ok) throw new Error("Could not load the invoice PDF font.");
    return new Uint8Array(await response.arrayBuffer());
  };
  const [regular, bold] = await Promise.all([load("Regular"), load("Bold")]);
  return { regular, bold };
}

// Render the populated invoice workbook, including its template text, colours and logo.
// This is deliberately limited to the invoice's A:H layout, rather than a general Excel converter.
export async function buildInvoicePdf(workbookBytes: Uint8Array, fontBytes?: InvoicePdfFonts): Promise<Uint8Array> {
  const files = unzipSync(workbookBytes);
  const xml = (path: string) => new DOMParser().parseFromString(new TextDecoder().decode(files[path]), "application/xml");
  const sheet = xml("xl/worksheets/sheet1.xml");
  const styles = xml("xl/styles.xml");
  const theme = xml("xl/theme/theme1.xml");
  const strings = files["xl/sharedStrings.xml"] ? all(xml("xl/sharedStrings.xml"), "si").map(textContent) : [];
  const fonts = children(first(styles, "fonts"));
  const fills = children(first(styles, "fills"));
  const borders = children(first(styles, "borders"));
  const formats = children(first(styles, "cellXfs"));
  const scheme = children(first(theme, "clrScheme"));
  const themeOrder = [1, 0, 3, 2, 4, 5, 6, 7, 8, 9, 10, 11];

  function colour(element?: Element, fallback = "000000"): RGB {
    let hex = element?.getAttribute("rgb")?.slice(-6);
    const themeIndex = element?.getAttribute("theme");
    if (!hex && themeIndex) {
      const node = children(scheme[themeOrder[Number(themeIndex)]]!)[0];
      hex = node?.getAttribute("lastClr") || node?.getAttribute("val") || undefined;
    }
    hex = hex && /^[0-9a-f]{6}$/i.test(hex) ? hex : fallback;
    const tint = Number(element?.getAttribute("tint") || 0);
    const channel = (offset: number) => {
      const value = parseInt(hex!.slice(offset, offset + 2), 16) / 255;
      return tint < 0 ? value * (1 + tint) : value + (1 - value) * tint;
    };
    return rgb(channel(0), channel(2), channel(4));
  }

  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);
  const fontData = fontBytes ?? await loadFonts();
  const regular = await pdf.embedFont(fontData.regular, { subset: true });
  const bold = await pdf.embedFont(fontData.bold, { subset: true });
  const pageWidth = 595.28;
  const pageHeight = 841.89;
  const margin = first(sheet, "pageMargins");
  const left = Number(margin?.getAttribute("left") || 0.5) * 72;
  const right = Number(margin?.getAttribute("right") || 0.5) * 72;
  const top = Number(margin?.getAttribute("top") || 1.5) * 72;
  const bottom = Number(margin?.getAttribute("bottom") || 0.75) * 72;
  const availableWidth = pageWidth - left - right;
  const widths = Array.from({ length: 8 }, (_, index) => {
    const column = all(sheet, "col").find((entry) => Number(entry.getAttribute("min")) <= index + 1 && Number(entry.getAttribute("max")) >= index + 1);
    return (Number(column?.getAttribute("width") || 8.43) * 7 + 5) * 0.75;
  });
  const scale = Math.min(1, availableWidth / widths.reduce((sum, width) => sum + width, 0));
  const columnWidths = widths.map((width) => width * scale);
  const tableWidth = columnWidths.reduce((sum, width) => sum + width, 0);
  const defaultHeight = Number(first(sheet, "sheetFormatPr")?.getAttribute("defaultRowHeight") || 14.4) * scale;
  const rows = new Map(all(sheet, "row").map((row) => [Number(row.getAttribute("r")), row]));
  const cells = new Map(all(sheet, "c").map((cell) => [cell.getAttribute("r"), cell]));
  const merges = all(sheet, "mergeCell").map((merge) => {
    const [start, end] = merge.getAttribute("ref")!.split(":").map(cellPosition);
    return { start, end: end || start };
  });
  const lastRow = Math.max(...rows.keys());

  function cellText(cell?: Element): string {
    if (!cell) return "";
    if (cell.getAttribute("t") === "s") return strings[Number(first(cell, "v")?.textContent)] || "";
    if (cell.getAttribute("t") === "inlineStr") return textContent(first(cell, "is"));
    const value = first(cell, "v")?.textContent || "";
    if (!value) return "";
    const format = formats[Number(cell.getAttribute("s") || 0)];
    const money = [44, 164].includes(Number(format?.getAttribute("numFmtId")));
    return money ? Number(value).toLocaleString("en-AU", { style: "currency", currency: "AUD" }) : value;
  }

  function appearance(cell?: Element) {
    const format = formats[Number(cell?.getAttribute("s") || 0)];
    const font = fonts[Number(format?.getAttribute("fontId") || 0)];
    const fill = fills[Number(format?.getAttribute("fillId") || 0)];
    const pattern = first(fill, "patternFill");
    return {
      font: first(font, "b") ? bold : regular,
      size: Number(first(font, "sz")?.getAttribute("val") || 11) * scale,
      color: colour(first(font, "color")),
      fill: pattern?.getAttribute("patternType") === "solid" ? colour(first(pattern, "fgColor"), "FFFFFF") : undefined,
      alignment: first(format, "alignment")?.getAttribute("horizontal") || (cell && first(cell, "v") && !cell.getAttribute("t") ? "right" : "left"),
      border: borders[Number(format?.getAttribute("borderId") || 0)]
    };
  }

  function block(rowNumber: number) {
    let span = 1;
    const entries = [];
    for (let column = 0; column < 8; column += 1) {
      const merged = merges.find((merge) => merge.start.row === rowNumber && merge.start.col === column);
      const endCol = merged?.end.col ?? column;
      const endRow = merged?.end.row ?? rowNumber;
      span = Math.max(span, endRow - rowNumber + 1);
      const cell = cells.get(`${String.fromCharCode(65 + column)}${rowNumber}`);
      const style = appearance(cell);
      const width = columnWidths.slice(column, endCol + 1).reduce((sum, value) => sum + value, 0);
      const value = cellText(cell);
      const padding = width < 30 ? 2 : 4;
      // Keep quantities and money on one line, including larger invoice totals.
      if (value && cell && first(cell, "v") && !cell.getAttribute("t")) {
        style.size = Math.min(style.size, (width - padding * 2) / style.font.widthOfTextAtSize(value, style.size) * style.size);
      }
      const text = wrap(value, style.font, style.size, width - padding * 2);
      entries.push({ column, endCol, endRow, style, width, text });
      column = endCol;
    }
    const baseHeight = Array.from({ length: span }, (_, offset) => Number(rows.get(rowNumber + offset)?.getAttribute("ht") || defaultHeight / scale) * scale).reduce((sum, value) => sum + value, 0);
    const height = Math.max(baseHeight, ...entries.map((entry) => entry.text.every((line) => !line) ? 0 : entry.text.length * entry.style.size * 1.2 + 7));
    if (height > pageHeight - top - bottom - 55) throw new Error("An invoice row is too long to fit on a PDF page. Shorten the item description or billing address.");
    return { rowNumber, span, entries, height };
  }

  const blocks = [];
  for (let rowNumber = 1; rowNumber <= lastRow;) {
    const entry = block(rowNumber);
    blocks.push(entry);
    rowNumber += entry.span;
  }
  const tableHeader = blocks.find((entry) => entry.rowNumber === 9)!;
  const title = cellText(cells.get("A7"));
  pdf.setTitle(title);
  pdf.setAuthor("Department of Animal Care");

  const header = (first(sheet, "oddHeader")?.textContent || "").split("&R")[0]
    .replace(/&"[^"]*"|&\d+|&[LCGRBUI]/g, "").trim();
  // The invoice's right header logo is held in its VML header drawing.
  const logoRelationship = Object.keys(files).find((path) => /drawings\/_rels\/vmlDrawing.*\.rels$/.test(path));
  const logoTarget = logoRelationship ? first(xml(logoRelationship), "Relationship")?.getAttribute("Target") : null;
  const logoBytes = logoTarget ? files[`xl/${logoTarget.replace(/^\.\.\//, "")}`] : undefined;
  const logo = logoBytes ? (logoTarget!.endsWith(".png") ? await pdf.embedPng(logoBytes) : await pdf.embedJpg(logoBytes)) : null;
  let page = pdf.addPage([pageWidth, pageHeight]);
  let y = pageHeight - top;

  function drawHeader() {
    header.split("\n").forEach((line, index) => page.drawText(line, { x: left, y: pageHeight - 31 - index * 11, font: regular, size: 9 }));
    if (logo) {
      const width = Math.min(207, tableWidth * 0.43);
      const height = width * logo.height / logo.width;
      page.drawImage(logo, { x: pageWidth - right - width, y: pageHeight - 23 - height, width, height });
    }
  }

  function drawBlock(entry: ReturnType<typeof block>) {
    let x = left;
    for (const cell of entry.entries) {
      const { style, width } = cell;
      if (style.fill) page.drawRectangle({ x, y: y - entry.height, width, height: entry.height, color: style.fill });
      const textHeight = cell.text.length * style.size * 1.2;
      cell.text.forEach((line, index) => {
        const textWidth = style.font.widthOfTextAtSize(line, style.size);
        const textX = style.alignment === "center" ? x + (width - textWidth) / 2 : style.alignment === "right" ? x + width - textWidth - 4 : x + 4;
        page.drawText(line, { x: textX, y: y - (entry.height - textHeight) / 2 - style.size - index * style.size * 1.2, font: style.font, size: style.size, color: style.color });
      });
      const bottomRight = cells.get(`${String.fromCharCode(65 + cell.endCol)}${cell.endRow}`);
      const endBorder = appearance(bottomRight).border;
      for (const edge of ["left", "right", "top", "bottom"] as const) {
        const border = first(edge === "right" || edge === "bottom" ? endBorder : style.border, edge);
        const weight = border?.getAttribute("style");
        if (!weight) continue;
        const startX = edge === "right" ? x + width : x;
        const endX = edge === "left" ? x : x + width;
        const startY = edge === "bottom" ? y - entry.height : y;
        const endY = edge === "top" ? y : y - entry.height;
        page.drawLine({ start: { x: startX, y: startY }, end: { x: endX, y: endY }, thickness: weight === "medium" ? 1.2 : 0.3, color: colour(first(border, "color"), "CCCCCC") });
      }
      x += width;
    }
    y -= entry.height;
  }

  function nextPage() {
    page = pdf.addPage([pageWidth, pageHeight]);
    y = pageHeight - top;
    drawHeader();
    page.drawText(title, { x: left, y: y - 15, font: bold, size: 13 });
    y -= 28;
    drawBlock(tableHeader);
  }

  drawHeader();
  for (let index = 0; index < blocks.length; index += 1) {
    const entry = blocks[index];
    // Keep the total and payment instructions together on the final page.
    const remainingHeight = cellText(cells.get(`A${entry.rowNumber}`)).startsWith("TOTAL AMOUNT")
      ? blocks.slice(index).reduce((sum, value) => sum + value.height, 0) : entry.height;
    if (y - remainingHeight < bottom) nextPage();
    drawBlock(entry);
  }
  pdf.getPages().forEach((entry, index, pages) => entry.drawText(`Page ${index + 1} of ${pages.length}`, { x: left, y: 24, font: regular, size: 8, color: rgb(0.4, 0.4, 0.4) }));
  return pdf.save();
}

function all(root: ParentNode | undefined, name: string): Element[] {
  if (!root) return [];
  return Array.from(root.childNodes).flatMap((node) => node.nodeType === 1 ? [
    ...((node as Element).localName === name ? [node as Element] : []),
    ...all(node as Element, name)
  ] : []);
}

function first(root: ParentNode | undefined, name: string): Element | undefined {
  return all(root, name)[0];
}

function children(root?: Element): Element[] {
  return root ? Array.from(root.childNodes).filter((node): node is Element => node.nodeType === 1) : [];
}

function textContent(root?: Element): string {
  return all(root, "t").map((entry) => entry.textContent || "").join("");
}

function cellPosition(ref: string) {
  return { col: ref.charCodeAt(0) - 65, row: Number(ref.replace(/\D/g, "")) };
}

function wrap(text: string, font: PDFFont, size: number, width: number): string[] {
  const lines: string[] = [];
  for (const paragraph of text.replace(/\r/g, "").split("\n")) {
    let line = "";
    for (const word of paragraph.split(/\s+/).filter(Boolean)) {
      if (line && font.widthOfTextAtSize(`${line} ${word}`, size) > width) {
        lines.push(line);
        line = "";
      }
      // Break long identifiers too, so text never crosses a neighbouring column.
      for (const character of (line ? " " : "") + word) {
        if (line && font.widthOfTextAtSize(line + character, size) > width) {
          lines.push(line);
          line = "";
        }
        line += character;
      }
    }
    lines.push(line);
  }
  return lines;
}
